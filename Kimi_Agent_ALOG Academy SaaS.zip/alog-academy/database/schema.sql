-- =====================================================================
-- ALOG ACADEMY (MAROC) - Schéma Base de Données Complet
-- MySQL 8+ optimisé pour hébergement gratuit
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- -------------------------------------------------------------------
-- Table: roles
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL,
    `label` VARCHAR(100) NOT NULL,
    `permissions` JSON,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_roles_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`name`, `label`) VALUES
('student', 'Étudiant'),
('admin', 'Administrateur'),
('super_admin', 'Super Administrateur');

-- -------------------------------------------------------------------
-- Table: users
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `fullname` VARCHAR(200) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `role` VARCHAR(50) NOT NULL DEFAULT 'student',
    `plan` ENUM('FREE','PRO','ULTRA') NOT NULL DEFAULT 'FREE',
    `plan_expires_at` DATETIME DEFAULT NULL,
    `xp_total` INT UNSIGNED NOT NULL DEFAULT 0,
    `level` INT UNSIGNED NOT NULL DEFAULT 1,
    `region` VARCHAR(100) DEFAULT 'inconnu',
    `city` VARCHAR(100) DEFAULT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    `avatar` VARCHAR(255) DEFAULT NULL,
    `bio` TEXT,
    `school` VARCHAR(200) DEFAULT NULL,
    `grade` VARCHAR(50) DEFAULT NULL,
    `birth_date` DATE DEFAULT NULL,
    `gender` ENUM('male','female','other') DEFAULT NULL,
    `email_verified` TINYINT(1) NOT NULL DEFAULT 0,
    `status` ENUM('active','suspended','banned') NOT NULL DEFAULT 'active',
    `last_login` DATETIME DEFAULT NULL,
    `login_streak` INT UNSIGNED NOT NULL DEFAULT 0,
    `last_daily_login` DATE DEFAULT NULL,
    `remember_token` VARCHAR(255) DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_users_email` (`email`),
    KEY `idx_users_role` (`role`),
    KEY `idx_users_plan` (`plan`),
    KEY `idx_users_status` (`status`),
    KEY `idx_users_xp` (`xp_total`),
    KEY `idx_users_level` (`level`),
    KEY `idx_users_region` (`region`),
    CONSTRAINT `fk_users_role` FOREIGN KEY (`role`) REFERENCES `roles`(`name`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: password_resets
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(255) NOT NULL,
    `token` VARCHAR(255) NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_pr_email` (`email`),
    KEY `idx_pr_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: remember_tokens
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `remember_tokens`;
CREATE TABLE `remember_tokens` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `token` VARCHAR(255) NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_rt_user` (`user_id`),
    KEY `idx_rt_token` (`token`),
    CONSTRAINT `fk_rt_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: login_attempts
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `identifier` VARCHAR(255) NOT NULL,
    `attempts` INT UNSIGNED NOT NULL DEFAULT 1,
    `expires_at` DATETIME NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_la_identifier` (`identifier`),
    KEY `idx_la_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: levels (Niveaux éducatifs: Collège, Lycée, etc.)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `levels`;
CREATE TABLE `levels` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL,
    `slug` VARCHAR(200) NOT NULL,
    `description` TEXT,
    `icon` VARCHAR(100) DEFAULT 'book',
    `color` VARCHAR(50) DEFAULT 'primary',
    `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_levels_slug` (`slug`),
    KEY `idx_levels_sort` (`sort_order`),
    KEY `idx_levels_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `levels` (`name`, `slug`, `description`, `icon`, `color`, `sort_order`) VALUES
('Collège', 'college', 'Programme du collège marocain (1ère année à 3ème année)', 'school', 'info', 1),
('Tronc Commun', 'tronc-commun', 'Tronc Commun Scientifique et Technologique', 'flask', 'success', 2),
('1ère Bac', '1ere-bac', 'Première année Baccalauréat', 'award', 'warning', 3),
('2ème Bac', '2eme-bac', 'Deuxième année Baccalauréat', 'graduation-cap', 'danger', 4),
('Supérieur', 'superieur', 'Études supérieures et concours', 'university', 'primary', 5);

-- -------------------------------------------------------------------
-- Table: subjects (Matières)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `level_id` INT UNSIGNED NOT NULL,
    `name` VARCHAR(200) NOT NULL,
    `slug` VARCHAR(200) NOT NULL,
    `description` TEXT,
    `icon` VARCHAR(100) DEFAULT 'book',
    `color` VARCHAR(50) DEFAULT 'primary',
    `image` VARCHAR(255) DEFAULT NULL,
    `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_subjects_slug` (`slug`),
    KEY `idx_subjects_level` (`level_id`),
    KEY `idx_subjects_active` (`is_active`),
    CONSTRAINT `fk_subjects_level` FOREIGN KEY (`level_id`) REFERENCES `levels`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: lessons (Leçons)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `lessons`;
CREATE TABLE `lessons` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `subject_id` INT UNSIGNED NOT NULL,
    `level_id` INT UNSIGNED NOT NULL,
    `title` VARCHAR(300) NOT NULL,
    `slug` VARCHAR(300) NOT NULL,
    `description` TEXT,
    `content` LONGTEXT,
    `youtube_url` VARCHAR(500) DEFAULT NULL,
    `pdf_url` VARCHAR(500) DEFAULT NULL,
    `exercise_pdf_url` VARCHAR(500) DEFAULT NULL,
    `image_url` VARCHAR(500) DEFAULT NULL,
    `xp_reward` INT UNSIGNED NOT NULL DEFAULT 10,
    `access_type` ENUM('FREE','PRO','ULTRA','XP') NOT NULL DEFAULT 'FREE',
    `duration_minutes` INT UNSIGNED DEFAULT 0,
    `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,
    `views_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `completions_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_lessons_slug` (`slug`),
    KEY `idx_lessons_subject` (`subject_id`),
    KEY `idx_lessons_level` (`level_id`),
    KEY `idx_lessons_access` (`access_type`),
    KEY `idx_lessons_active` (`is_active`),
    FULLTEXT KEY `ft_lessons_title` (`title`, `description`),
    CONSTRAINT `fk_lessons_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_lessons_level` FOREIGN KEY (`level_id`) REFERENCES `levels`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: lesson_progressions
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `lesson_progressions`;
CREATE TABLE `lesson_progressions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `lesson_id` INT UNSIGNED NOT NULL,
    `progress_percent` INT UNSIGNED NOT NULL DEFAULT 0,
    `is_completed` TINYINT(1) NOT NULL DEFAULT 0,
    `is_skipped` TINYINT(1) NOT NULL DEFAULT 0,
    `xp_earned` INT UNSIGNED NOT NULL DEFAULT 0,
    `started_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `completed_at` DATETIME DEFAULT NULL,
    `last_accessed_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_progress_user_lesson` (`user_id`, `lesson_id`),
    KEY `idx_progress_user` (`user_id`),
    KEY `idx_progress_lesson` (`lesson_id`),
    KEY `idx_progress_completed` (`is_completed`),
    CONSTRAINT `fk_progress_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_progress_lesson` FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: quizzes
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `quizzes`;
CREATE TABLE `quizzes` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `lesson_id` INT UNSIGNED DEFAULT NULL,
    `subject_id` INT UNSIGNED DEFAULT NULL,
    `level_id` INT UNSIGNED DEFAULT NULL,
    `title` VARCHAR(300) NOT NULL,
    `slug` VARCHAR(300) NOT NULL,
    `description` TEXT,
    `time_limit` INT UNSIGNED DEFAULT NULL,
    `passing_score` INT UNSIGNED NOT NULL DEFAULT 60,
    `xp_reward` INT UNSIGNED NOT NULL DEFAULT 20,
    `xp_perfect_bonus` INT UNSIGNED NOT NULL DEFAULT 50,
    `shuffle_questions` TINYINT(1) NOT NULL DEFAULT 1,
    `max_attempts` INT UNSIGNED DEFAULT NULL,
    `cooldown_hours` INT UNSIGNED DEFAULT 0,
    `access_type` ENUM('FREE','PRO','ULTRA','XP') NOT NULL DEFAULT 'FREE',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_quizzes_slug` (`slug`),
    KEY `idx_quizzes_lesson` (`lesson_id`),
    KEY `idx_quizzes_active` (`is_active`),
    FULLTEXT KEY `ft_quizzes_title` (`title`, `description`),
    CONSTRAINT `fk_quizzes_lesson` FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_quizzes_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_quizzes_level` FOREIGN KEY (`level_id`) REFERENCES `levels`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: quiz_questions
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `quiz_questions`;
CREATE TABLE `quiz_questions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `quiz_id` INT UNSIGNED NOT NULL,
    `question` TEXT NOT NULL,
    `question_type` ENUM('mcq','true_false') NOT NULL DEFAULT 'mcq',
    `options` JSON NOT NULL,
    `correct_answer` VARCHAR(500) NOT NULL,
    `explanation` TEXT,
    `points` INT UNSIGNED NOT NULL DEFAULT 1,
    `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_questions_quiz` (`quiz_id`),
    CONSTRAINT `fk_questions_quiz` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: quiz_results
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `quiz_results`;
CREATE TABLE `quiz_results` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `quiz_id` INT UNSIGNED NOT NULL,
    `score` INT UNSIGNED NOT NULL DEFAULT 0,
    `max_score` INT UNSIGNED NOT NULL DEFAULT 0,
    `percentage` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `is_passed` TINYINT(1) NOT NULL DEFAULT 0,
    `answers` JSON,
    `time_taken` INT UNSIGNED DEFAULT NULL,
    `xp_earned` INT UNSIGNED NOT NULL DEFAULT 0,
    `attempt_number` INT UNSIGNED NOT NULL DEFAULT 1,
    `completed_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_results_user` (`user_id`),
    KEY `idx_results_quiz` (`quiz_id`),
    KEY `idx_results_score` (`score`),
    CONSTRAINT `fk_results_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_results_quiz` FOREIGN KEY (`quiz_id`) REFERENCES `quizzes`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: xp_logs
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `xp_logs`;
CREATE TABLE `xp_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `amount` INT NOT NULL,
    `source` VARCHAR(100) NOT NULL,
    `source_id` INT UNSIGNED DEFAULT NULL,
    `description` VARCHAR(500) DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_xp_user` (`user_id`),
    KEY `idx_xp_source` (`source`),
    KEY `idx_xp_created` (`created_at`),
    CONSTRAINT `fk_xp_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: badges
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `badges`;
CREATE TABLE `badges` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL,
    `slug` VARCHAR(200) NOT NULL,
    `description` TEXT,
    `icon` VARCHAR(100) DEFAULT 'trophy',
    `color` VARCHAR(50) DEFAULT 'warning',
    `requirement_type` VARCHAR(100) NOT NULL,
    `requirement_value` INT UNSIGNED NOT NULL DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_badges_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `badges` (`name`, `slug`, `description`, `icon`, `color`, `requirement_type`, `requirement_value`) VALUES
('Première Leçon', 'first-lesson', 'Terminer votre première leçon', 'book-open', 'primary', 'lessons_completed', 1),
('Dix Leçons', 'ten-lessons', 'Terminer 10 leçons', 'book-open', 'success', 'lessons_completed', 10),
('Premier Quiz', 'first-quiz', 'Réussir votre premier quiz', 'check-circle', 'info', 'quizzes_passed', 1),
('Score Parfait', 'perfect-score', 'Obtenir un score parfait à un quiz', 'star', 'warning', 'perfect_scores', 1),
('Connexion Quotidienne', 'daily-streak-7', 'Se connecter 7 jours de suite', 'fire', 'danger', 'login_streak', 7),
('Niveau 5', 'level-5', 'Atteindre le niveau 5', 'award', 'primary', 'level', 5),
('Niveau 10', 'level-10', 'Atteindre le niveau 10', 'crown', 'warning', 'level', 10),
('1000 XP', 'xp-1000', 'Cumuler 1000 points d\'expérience', 'zap', 'success', 'xp_total', 1000);

-- -------------------------------------------------------------------
-- Table: user_badges
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `user_badges`;
CREATE TABLE `user_badges` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `badge_id` INT UNSIGNED NOT NULL,
    `earned_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_user_badge` (`user_id`, `badge_id`),
    CONSTRAINT `fk_ub_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_ub_badge` FOREIGN KEY (`badge_id`) REFERENCES `badges`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: subscriptions
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE `subscriptions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `plan` ENUM('FREE','PRO','ULTRA') NOT NULL DEFAULT 'FREE',
    `status` ENUM('active','expired','cancelled') NOT NULL DEFAULT 'active',
    `starts_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `expires_at` DATETIME DEFAULT NULL,
    `auto_renew` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_sub_user` (`user_id`),
    KEY `idx_sub_status` (`status`),
    KEY `idx_sub_expires` (`expires_at`),
    CONSTRAINT `fk_sub_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: payments
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `subscription_id` INT UNSIGNED DEFAULT NULL,
    `plan` ENUM('PRO','ULTRA') NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `payment_method` VARCHAR(50) DEFAULT 'whatsapp',
    `proof_image` VARCHAR(255) DEFAULT NULL,
    `whatsapp_number` VARCHAR(20) DEFAULT NULL,
    `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    `admin_notes` TEXT,
    `validated_by` INT UNSIGNED DEFAULT NULL,
    `validated_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_pay_user` (`user_id`),
    KEY `idx_pay_status` (`status`),
    KEY `idx_pay_created` (`created_at`),
    CONSTRAINT `fk_pay_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_pay_sub` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_pay_admin` FOREIGN KEY (`validated_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: rankings
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `rankings`;
CREATE TABLE `rankings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `global_rank` INT UNSIGNED DEFAULT NULL,
    `regional_rank` INT UNSIGNED DEFAULT NULL,
    `region` VARCHAR(100) DEFAULT NULL,
    `total_xp` INT UNSIGNED NOT NULL DEFAULT 0,
    `lessons_completed` INT UNSIGNED NOT NULL DEFAULT 0,
    `quizzes_passed` INT UNSIGNED NOT NULL DEFAULT 0,
    `perfect_scores` INT UNSIGNED NOT NULL DEFAULT 0,
    `weekly_xp` INT UNSIGNED NOT NULL DEFAULT 0,
    `monthly_xp` INT UNSIGNED NOT NULL DEFAULT 0,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_rank_user` (`user_id`),
    KEY `idx_rank_global` (`global_rank`),
    KEY `idx_rank_regional` (`regional_rank`),
    KEY `idx_rank_region` (`region`),
    CONSTRAINT `fk_rank_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: blog_categories
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `blog_categories`;
CREATE TABLE `blog_categories` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL,
    `slug` VARCHAR(200) NOT NULL,
    `description` TEXT,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_blogcat_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `blog_categories` (`name`, `slug`, `description`) VALUES
('Conseils Bac', 'bac-tips', 'Astuces et stratégies pour réussir le Baccalauréat'),
('Méthodes de Révision', 'revision-methods', 'Techniques efficaces pour réviser'),
('Motivation', 'motivation', 'Restez motivé tout au long de l\'année'),
('Orientation', 'orientation', 'Guide d\'orientation post-bac'),
('Productivité', 'productivity', 'Devenez plus productif dans vos études');

-- -------------------------------------------------------------------
-- Table: blog_posts
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `blog_posts`;
CREATE TABLE `blog_posts` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `category_id` INT UNSIGNED DEFAULT NULL,
    `author_id` INT UNSIGNED DEFAULT NULL,
    `title` VARCHAR(300) NOT NULL,
    `slug` VARCHAR(300) NOT NULL,
    `excerpt` TEXT,
    `content` LONGTEXT NOT NULL,
    `featured_image` VARCHAR(500) DEFAULT NULL,
    `meta_title` VARCHAR(300) DEFAULT NULL,
    `meta_description` VARCHAR(500) DEFAULT NULL,
    `views_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `is_published` TINYINT(1) NOT NULL DEFAULT 0,
    `published_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_blog_slug` (`slug`),
    KEY `idx_blog_category` (`category_id`),
    KEY `idx_blog_author` (`author_id`),
    KEY `idx_blog_published` (`is_published`),
    FULLTEXT KEY `ft_blog_content` (`title`, `content`),
    CONSTRAINT `fk_blog_category` FOREIGN KEY (`category_id`) REFERENCES `blog_categories`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_blog_author` FOREIGN KEY (`author_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: bookings (Réservations)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `bookings`;
CREATE TABLE `bookings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `booking_type` ENUM('tutoring','coaching') NOT NULL DEFAULT 'tutoring',
    `subject` VARCHAR(200) NOT NULL,
    `message` TEXT,
    `preferred_date` DATE DEFAULT NULL,
    `preferred_time` VARCHAR(50) DEFAULT NULL,
    `status` ENUM('pending','approved','rejected','completed','cancelled') NOT NULL DEFAULT 'pending',
    `admin_response` TEXT,
    `admin_id` INT UNSIGNED DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_book_user` (`user_id`),
    KEY `idx_book_status` (`status`),
    KEY `idx_book_type` (`booking_type`),
    CONSTRAINT `fk_book_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_book_admin` FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: notifications
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `type` VARCHAR(100) NOT NULL,
    `title` VARCHAR(300) NOT NULL,
    `message` TEXT,
    `link` VARCHAR(500) DEFAULT NULL,
    `is_read` TINYINT(1) NOT NULL DEFAULT 0,
    `read_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_notif_user` (`user_id`),
    KEY `idx_notif_read` (`is_read`),
    KEY `idx_notif_type` (`type`),
    CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: comments
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `lesson_id` INT UNSIGNED DEFAULT NULL,
    `blog_post_id` INT UNSIGNED DEFAULT NULL,
    `parent_id` INT UNSIGNED DEFAULT NULL,
    `content` TEXT NOT NULL,
    `is_approved` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_comments_user` (`user_id`),
    KEY `idx_comments_lesson` (`lesson_id`),
    KEY `idx_comments_blog` (`blog_post_id`),
    KEY `idx_comments_parent` (`parent_id`),
    CONSTRAINT `fk_comments_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_comments_lesson` FOREIGN KEY (`lesson_id`) REFERENCES `lessons`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_comments_blog` FOREIGN KEY (`blog_post_id`) REFERENCES `blog_posts`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_comments_parent` FOREIGN KEY (`parent_id`) REFERENCES `comments`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Table: settings
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(200) NOT NULL,
    `setting_value` TEXT,
    `setting_group` VARCHAR(100) DEFAULT 'general',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_settings_key` (`setting_key`),
    KEY `idx_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`) VALUES
('site_name', 'ALOG Academy', 'general'),
('site_description', 'Plateforme éducative gamifiée pour étudiants marocains', 'general'),
('site_logo', NULL, 'general'),
('contact_email', 'contact@alogacademy.ma', 'general'),
('contact_phone', '+212612345678', 'general'),
('whatsapp_number', '+212612345678', 'payment'),
('pro_plan_price', '49', 'payment'),
('ultra_plan_price', '99', 'payment'),
('currency', 'MAD', 'payment'),
('maintenance_mode', '0', 'system'),
('registration_enabled', '1', 'system'),
('default_theme', 'light', 'appearance');

-- -------------------------------------------------------------------
-- Table: announcements
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(300) NOT NULL,
    `content` TEXT NOT NULL,
    `type` ENUM('info','warning','success','danger') DEFAULT 'info',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `starts_at` DATETIME DEFAULT NULL,
    `expires_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_announce_active` (`is_active`),
    KEY `idx_announce_dates` (`starts_at`, `expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- Vues pour les statistiques
-- -------------------------------------------------------------------

DROP VIEW IF EXISTS `v_user_stats`;
CREATE VIEW `v_user_stats` AS
SELECT
    u.id,
    u.fullname,
    u.email,
    u.role,
    u.plan,
    u.xp_total,
    u.level,
    u.region,
    u.status,
    u.created_at,
    COUNT(DISTINCT lp.lesson_id) as lessons_completed,
    COUNT(DISTINCT qr.quiz_id) as quizzes_taken,
    AVG(qr.percentage) as avg_quiz_score,
    COUNT(DISTINCT ub.badge_id) as badges_count
FROM users u
LEFT JOIN lesson_progressions lp ON u.id = lp.user_id AND lp.is_completed = 1
LEFT JOIN quiz_results qr ON u.id = qr.user_id
LEFT JOIN user_badges ub ON u.id = ub.user_id
GROUP BY u.id;

DROP VIEW IF EXISTS `v_leaderboard`;
CREATE VIEW `v_leaderboard` AS
SELECT
    u.id,
    u.fullname,
    u.avatar,
    u.xp_total,
    u.level,
    u.region,
    COUNT(DISTINCT lp.lesson_id) as lessons_completed,
    COUNT(DISTINCT qr.quiz_id) as quizzes_passed,
    RANK() OVER (ORDER BY u.xp_total DESC) as global_rank,
    RANK() OVER (PARTITION BY u.region ORDER BY u.xp_total DESC) as regional_rank
FROM users u
LEFT JOIN lesson_progressions lp ON u.id = lp.user_id AND lp.is_completed = 1
LEFT JOIN quiz_results qr ON u.id = qr.user_id AND qr.is_passed = 1
WHERE u.role = 'student' AND u.status = 'active'
GROUP BY u.id
ORDER BY u.xp_total DESC;

DROP VIEW IF EXISTS `v_daily_stats`;
CREATE VIEW `v_daily_stats` AS
SELECT
    DATE(created_at) as date,
    COUNT(DISTINCT CASE WHEN source = 'daily_login' THEN user_id END) as daily_active_users,
    COUNT(CASE WHEN source = 'lesson_complete' THEN 1 END) as lessons_completed_today,
    COUNT(CASE WHEN source = 'quiz_pass' THEN 1 END) as quizzes_passed_today,
    SUM(CASE WHEN source = 'daily_login' THEN amount ELSE 0 END) as daily_login_xp,
    SUM(CASE WHEN source = 'lesson_complete' THEN amount ELSE 0 END) as lessons_xp,
    SUM(CASE WHEN source = 'quiz_pass' THEN amount ELSE 0 END) as quiz_xp
FROM xp_logs
GROUP BY DATE(created_at)
ORDER BY date DESC;

SET FOREIGN_KEY_CHECKS = 1;

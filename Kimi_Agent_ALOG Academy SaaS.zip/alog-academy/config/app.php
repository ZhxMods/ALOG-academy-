<?php
/**
 * ALOG ACADEMY - Configuration Application
 */

if (!defined('BASE_URL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
    $basePath = dirname(dirname($scriptName));
    $basePath = $basePath === '/' || $basePath === '\\' ? '' : $basePath;
    define('BASE_URL', rtrim($protocol . '://' . $host . $basePath, '/'));
}

if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}

if (!defined('APP_PATH')) {
    define('APP_PATH', ROOT_PATH . '/app');
}

if (!defined('PUBLIC_PATH')) {
    define('PUBLIC_PATH', ROOT_PATH . '/public');
}

if (!defined('UPLOAD_PATH')) {
    define('UPLOAD_PATH', PUBLIC_PATH . '/assets/uploads');
}

if (!defined('STORAGE_PATH')) {
    define('STORAGE_PATH', ROOT_PATH . '/storage');
}

// Session config
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 1 : 0);
    ini_set('session.gc_maxlifetime', 3600);
    ini_set('session.cookie_lifetime', 0);
    session_start();
}

// Timezone
if (!defined('APP_TIMEZONE')) {
    date_default_timezone_set('Africa/Casablanca');
    define('APP_TIMEZONE', 'Africa/Casablanca');
}

// Security
if (!defined('CSRF_TOKEN_NAME')) {
    define('CSRF_TOKEN_NAME', 'alog_csrf_token');
}

if (!defined('MAX_LOGIN_ATTEMPTS')) {
    define('MAX_LOGIN_ATTEMPTS', 5);
}

if (!defined('LOGIN_COOLDOWN')) {
    define('LOGIN_COOLDOWN', 900); // 15 minutes
}

// Subscription Plans
if (!defined('PLAN_FREE')) {
    define('PLAN_FREE', 'FREE');
    define('PLAN_PRO', 'PRO');
    define('PLAN_ULTRA', 'ULTRA');
    define('PRICE_PRO', 49);
    define('PRICE_ULTRA', 99);
    define('WHATSAPP_NUMBER', '+212612345678');
}

// XP Config
if (!defined('XP_LESSON_COMPLETE')) {
    define('XP_LESSON_COMPLETE', 10);
    define('XP_QUIZ_PASS', 20);
    define('XP_QUIZ_PERFECT', 50);
    define('XP_DAILY_LOGIN', 5);
    define('XP_LEVEL_BASE', 100);
    define('XP_LEVEL_MULTIPLIER', 1.5);
}

// Roles
if (!defined('ROLE_STUDENT')) {
    define('ROLE_STUDENT', 'student');
    define('ROLE_ADMIN', 'admin');
    define('ROLE_SUPER_ADMIN', 'super_admin');
}

<?php
namespace App\Models;

use App\Core\Model;

class Payment extends Model {
    protected string $table = 'payments';
    protected string $primaryKey = 'id';
    protected array $fillable = [
        'user_id', 'subscription_id', 'plan', 'amount', 'payment_method',
        'proof_image', 'whatsapp_number', 'status', 'admin_notes', 'validated_by', 'validated_at'
    ];

    public function getByUser(int $userId): array {
        return $this->db->fetchAll(
            "SELECT * FROM payments WHERE user_id = :uid ORDER BY created_at DESC",
            ['uid' => $userId]
        );
    }

    public function getPending(): array {
        return $this->db->fetchAll(
            "SELECT p.*, u.fullname, u.email FROM payments p
             JOIN users u ON p.user_id = u.id
             WHERE p.status = 'pending' ORDER BY p.created_at DESC"
        );
    }

    public function getAll(int $page = 1, int $perPage = 20): array {
        $total = $this->count();
        $pag = \paginate($total, $page, $perPage);
        $items = $this->db->fetchAll(
            "SELECT p.*, u.fullname, u.email, val.fullname as validator_name
             FROM payments p
             JOIN users u ON p.user_id = u.id
             LEFT JOIN users val ON p.validated_by = val.id
             ORDER BY p.created_at DESC LIMIT {$pag['per_page']} OFFSET {$pag['offset']}"
        );
        return ['items' => $items, 'pagination' => $pag];
    }

    public function approve(int $paymentId, int $adminId): bool {
        $payment = $this->find($paymentId);
        if (!$payment || $payment['status'] !== 'pending') return false;

        $this->db->beginTransaction();
        try {
            // Approuver le paiement
            $this->db->update($this->table, [
                'status' => 'approved',
                'validated_by' => $adminId,
                'validated_at' => date('Y-m-d H:i:s'),
            ], 'id = :id', ['id' => $paymentId]);

            // Créer l'abonnement
            $subModel = new Subscription();
            $subModel->createSubscription($payment['user_id'], $payment['plan'], 30);

            // Notification
            notify($payment['user_id'], 'payment_status', 'Paiement approuvé',
                "Votre abonnement {$payment['plan']} a été activé avec succès !");

            $this->db->commit();
            return true;
        } catch (\Exception $e) {
            $this->db->rollback();
            log_error('Payment approval error: ' . $e->getMessage());
            return false;
        }
    }

    public function reject(int $paymentId, int $adminId, string $reason = ''): bool {
        $payment = $this->find($paymentId);
        if (!$payment || $payment['status'] !== 'pending') return false;

        $this->db->update($this->table, [
            'status' => 'rejected',
            'admin_notes' => $reason,
            'validated_by' => $adminId,
            'validated_at' => date('Y-m-d H:i:s'),
        ], 'id = :id', ['id' => $paymentId]);

        notify($payment['user_id'], 'payment_status', 'Paiement rejeté',
            "Votre paiement a été rejeté. Raison: {$reason}");

        return true;
    }

    public function submit(int $userId, string $plan, string $whatsapp, ?string $proofImage = null): int {
        $amount = $plan === 'ULTRA' ? PRICE_ULTRA : PRICE_PRO;

        return $this->db->insert($this->table, [
            'user_id' => $userId,
            'plan' => $plan,
            'amount' => $amount,
            'payment_method' => 'whatsapp',
            'proof_image' => $proofImage,
            'whatsapp_number' => $whatsapp,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function getStats(): array {
        return [
            'total' => $this->count(),
            'pending' => $this->count("status = 'pending'"),
            'approved' => $this->count("status = 'approved'"),
            'rejected' => $this->count("status = 'rejected'"),
            'total_revenue' => $this->db->fetchColumn("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = 'approved'"),
        ];
    }
}

<?php
namespace App\Models;

use App\Core\Model;

class User extends Model {
    protected string $table = 'users';
    protected string $primaryKey = 'id';
    protected array $fillable = [
        'fullname', 'email', 'password', 'role', 'plan', 'plan_expires_at',
        'xp_total', 'level', 'region', 'city', 'phone', 'avatar', 'bio',
        'school', 'grade', 'birth_date', 'gender', 'email_verified',
        'status', 'last_login', 'login_streak', 'last_daily_login'
    ];

    public function findByEmail(string $email): ?array {
        return $this->findWhere('email', strtolower(trim($email)));
    }

    public function updateXp(int $userId, int $amount): void {
        $this->db->query(
            "UPDATE users SET xp_total = xp_total + :amount WHERE id = :id",
            ['amount' => $amount, 'id' => $userId]
        );
    }

    public function updateLevel(int $userId, int $level): void {
        $this->db->update($this->table, ['level' => $level], 'id = :id', ['id' => $userId]);
    }

    public function getStats(int $userId): array {
        return $this->db->fetch(
            "SELECT * FROM v_user_stats WHERE id = :id LIMIT 1",
            ['id' => $userId]
        ) ?: [];
    }

    public function getUnreadNotificationsCount(int $userId): int {
        return $this->db->fetchColumn(
            "SELECT COUNT(*) FROM notifications WHERE user_id = :uid AND is_read = 0",
            ['uid' => $userId]
        );
    }

    public function getStudents(int $page = 1, int $perPage = 20): array {
        $total = $this->count("role = 'student'");
        $pag = \paginate($total, $page, $perPage);
        $items = $this->db->fetchAll(
            "SELECT id, fullname, email, plan, xp_total, level, region, status, last_login, created_at
             FROM users WHERE role = 'student'
             ORDER BY created_at DESC LIMIT {$pag['per_page']} OFFSET {$pag['offset']}",
        );
        return ['items' => $items, 'pagination' => $pag];
    }

    public function search(string $query): array {
        return $this->db->fetchAll(
            "SELECT id, fullname, email, role, plan, status FROM users
             WHERE fullname LIKE :q OR email LIKE :q LIMIT 20",
            ['q' => '%' . $query . '%']
        );
    }

    public function countByRole(string $role): int {
        return $this->count('role = :role', ['role' => $role]);
    }

    public function countByPlan(string $plan): int {
        return $this->count('plan = :plan', ['plan' => $plan]);
    }

    public function countActiveToday(): int {
        return $this->db->fetchColumn(
            "SELECT COUNT(DISTINCT user_id) FROM xp_logs WHERE source = 'daily_login' AND DATE(created_at) = CURDATE()"
        );
    }
}

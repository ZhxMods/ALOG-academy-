<?php
namespace App\Models;

use App\Core\Model;

class Notification extends Model {
    protected string $table = 'notifications';
    protected string $primaryKey = 'id';
    protected array $fillable = [
        'user_id', 'type', 'title', 'message', 'link', 'is_read', 'read_at'
    ];

    public function getByUser(int $userId, int $limit = 20): array {
        return $this->db->fetchAll(
            "SELECT * FROM notifications WHERE user_id = :uid ORDER BY created_at DESC LIMIT {$limit}",
            ['uid' => $userId]
        );
    }

    public function getUnread(int $userId): array {
        return $this->db->fetchAll(
            "SELECT * FROM notifications WHERE user_id = :uid AND is_read = 0 ORDER BY created_at DESC LIMIT 10",
            ['uid' => $userId]
        );
    }

    public function countUnread(int $userId): int {
        return $this->db->fetchColumn(
            "SELECT COUNT(*) FROM notifications WHERE user_id = :uid AND is_read = 0",
            ['uid' => $userId]
        );
    }

    public function markAsRead(int $notificationId): void {
        $this->db->update($this->table, [
            'is_read' => 1,
            'read_at' => date('Y-m-d H:i:s'),
        ], 'id = :id', ['id' => $notificationId]);
    }

    public function markAllAsRead(int $userId): void {
        $this->db->query(
            "UPDATE notifications SET is_read = 1, read_at = NOW() WHERE user_id = :uid AND is_read = 0",
            ['uid' => $userId]
        );
    }

    public function create(int $userId, string $type, string $title, string $message, ?string $link = null): int {
        return $this->db->insert($this->table, [
            'user_id' => $userId,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'link' => $link,
            'is_read' => 0,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function deleteOld(int $days = 30): int {
        return $this->db->query(
            "DELETE FROM notifications WHERE created_at < DATE_SUB(NOW(), INTERVAL :days DAY)",
            ['days' => $days]
        )->rowCount();
    }

    public function getRecent(int $userId, int $limit = 5): array {
        return $this->getByUser($userId, $limit);
    }
}

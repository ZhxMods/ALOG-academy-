<?php
namespace App\Models;

use App\Core\Model;

class Booking extends Model {
    protected string $table = 'bookings';
    protected string $primaryKey = 'id';
    protected array $fillable = [
        'user_id', 'booking_type', 'subject', 'message',
        'preferred_date', 'preferred_time', 'status', 'admin_response', 'admin_id'
    ];

    public function getByUser(int $userId): array {
        return $this->db->fetchAll(
            "SELECT b.*, u.fullname as admin_name FROM bookings b
             LEFT JOIN users u ON b.admin_id = u.id
             WHERE b.user_id = :uid ORDER BY b.created_at DESC",
            ['uid' => $userId]
        );
    }

    public function getPending(): array {
        return $this->db->fetchAll(
            "SELECT b.*, u.fullname, u.email, u.phone FROM bookings b
             JOIN users u ON b.user_id = u.id
             WHERE b.status = 'pending' ORDER BY b.created_at DESC"
        );
    }

    public function getAll(int $page = 1, int $perPage = 20): array {
        $total = $this->count();
        $pag = \paginate($total, $page, $perPage);
        $items = $this->db->fetchAll(
            "SELECT b.*, u.fullname, u.email, u.phone, adm.fullname as admin_name
             FROM bookings b
             JOIN users u ON b.user_id = u.id
             LEFT JOIN users adm ON b.admin_id = adm.id
             ORDER BY b.created_at DESC LIMIT {$pag['per_page']} OFFSET {$pag['offset']}"
        );
        return ['items' => $items, 'pagination' => $pag];
    }

    public function createBooking(int $userId, array $data): int {
        return $this->db->insert($this->table, [
            'user_id' => $userId,
            'booking_type' => $data['booking_type'],
            'subject' => $data['subject'],
            'message' => $data['message'] ?? null,
            'preferred_date' => $data['preferred_date'] ?? null,
            'preferred_time' => $data['preferred_time'] ?? null,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function approve(int $bookingId, int $adminId, string $response = ''): void {
        $this->db->update($this->table, [
            'status' => 'approved',
            'admin_response' => $response,
            'admin_id' => $adminId,
            'updated_at' => date('Y-m-d H:i:s'),
        ], 'id = :id', ['id' => $bookingId]);

        $booking = $this->find($bookingId);
        if ($booking) {
            notify($booking['user_id'], 'booking', 'Réservation approuvée',
                "Votre demande de {$booking['booking_type']} a été approuvée.");
        }
    }

    public function reject(int $bookingId, int $adminId, string $response = ''): void {
        $this->db->update($this->table, [
            'status' => 'rejected',
            'admin_response' => $response,
            'admin_id' => $adminId,
            'updated_at' => date('Y-m-d H:i:s'),
        ], 'id = :id', ['id' => $bookingId]);

        $booking = $this->find($bookingId);
        if ($booking) {
            notify($booking['user_id'], 'booking', 'Réservation rejetée',
                "Votre demande de {$booking['booking_type']} a été rejetée.");
        }
    }

    public function complete(int $bookingId, int $adminId): void {
        $this->db->update($this->table, [
            'status' => 'completed',
            'admin_id' => $adminId,
            'updated_at' => date('Y-m-d H:i:s'),
        ], 'id = :id', ['id' => $bookingId]);
    }

    public function cancel(int $bookingId): void {
        $this->db->update($this->table, [
            'status' => 'cancelled',
            'updated_at' => date('Y-m-d H:i:s'),
        ], 'id = :id', ['id' => $bookingId]);
    }

    public function getStats(): array {
        return [
            'total' => $this->count(),
            'pending' => $this->count("status = 'pending'"),
            'approved' => $this->count("status = 'approved'"),
            'completed' => $this->count("status = 'completed'"),
        ];
    }

    public function getRecent(int $limit = 10): array {
        return $this->db->fetchAll(
            "SELECT b.*, u.fullname, u.email FROM bookings b
             JOIN users u ON b.user_id = u.id
             ORDER BY b.created_at DESC LIMIT {$limit}"
        );
    }
}

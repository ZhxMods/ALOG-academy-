<?php
namespace App\Models;

use App\Core\Model;

class Subscription extends Model {
    protected string $table = 'subscriptions';
    protected string $primaryKey = 'id';
    protected array $fillable = ['user_id', 'plan', 'status', 'starts_at', 'expires_at', 'auto_renew'];

    public function getActive(int $userId): ?array {
        return $this->db->fetch(
            "SELECT * FROM subscriptions WHERE user_id = :uid AND status = 'active'
             AND (expires_at IS NULL OR expires_at > NOW())
             ORDER BY created_at DESC LIMIT 1",
            ['uid' => $userId]
        );
    }

    public function getHistory(int $userId): array {
        return $this->db->fetchAll(
            "SELECT s.*, p.status as payment_status, p.proof_image
             FROM subscriptions s
             LEFT JOIN payments p ON s.id = p.subscription_id
             WHERE s.user_id = :uid ORDER BY s.created_at DESC",
            ['uid' => $userId]
        );
    }

    public function createSubscription(int $userId, string $plan, ?int $days = null): int {
        $expires = $days ? date('Y-m-d H:i:s', strtotime("+{$days} days")) : null;

        // Désactiver les anciens abonnements
        $this->db->query(
            "UPDATE subscriptions SET status = 'expired' WHERE user_id = :uid AND status = 'active'",
            ['uid' => $userId]
        );

        // Mettre à jour le plan de l'utilisateur
        $this->db->update('users', ['plan' => $plan, 'plan_expires_at' => $expires], 'id = :id', ['id' => $userId]);

        return $this->db->insert('subscriptions', [
            'user_id' => $userId,
            'plan' => $plan,
            'status' => 'active',
            'starts_at' => date('Y-m-d H:i:s'),
            'expires_at' => $expires,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function isActive(int $userId, string $requiredPlan = 'FREE'): bool {
        if ($requiredPlan === 'FREE') return true;

        $sub = $this->getActive($userId);
        if (!$sub) return false;

        $plans = ['FREE' => 0, 'PRO' => 1, 'ULTRA' => 2];
        $userPlanLevel = $plans[$sub['plan']] ?? 0;
        $requiredPlanLevel = $plans[$requiredPlan] ?? 0;

        return $userPlanLevel >= $requiredPlanLevel;
    }

    public function cancel(int $subscriptionId): void {
        $this->db->update($this->table, ['status' => 'cancelled'], 'id = :id', ['id' => $subscriptionId]);
    }

    public function getPending(): array {
        return $this->db->fetchAll(
            "SELECT s.*, u.fullname, u.email FROM subscriptions s
             JOIN users u ON s.user_id = u.id
             WHERE s.status = 'pending' ORDER BY s.created_at DESC"
        );
    }

    public function expireOldSubscriptions(): int {
        return $this->db->query(
            "UPDATE subscriptions SET status = 'expired'
             WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at < NOW()"
        )->rowCount();
    }
}

<?php
namespace App\Models;

use App\Core\Model;

class Lesson extends Model {
    protected string $table = 'lessons';
    protected string $primaryKey = 'id';
    protected array $fillable = [
        'subject_id', 'level_id', 'title', 'slug', 'description', 'content',
        'youtube_url', 'pdf_url', 'exercise_pdf_url', 'image_url',
        'xp_reward', 'access_type', 'duration_minutes', 'sort_order',
        'views_count', 'completions_count', 'is_active'
    ];

    public function getBySubject(int $subjectId): array {
        return $this->db->fetchAll(
            "SELECT * FROM lessons WHERE subject_id = :sid AND is_active = 1 ORDER BY sort_order ASC",
            ['sid' => $subjectId]
        );
    }

    public function getBySlug(string $slug): ?array {
        return $this->db->fetch(
            "SELECT l.*, s.name as subject_name, s.slug as subject_slug, lv.name as level_name, lv.slug as level_slug
             FROM lessons l
             JOIN subjects s ON l.subject_id = s.id
             JOIN levels lv ON l.level_id = lv.id
             WHERE l.slug = :slug AND l.is_active = 1 LIMIT 1",
            ['slug' => $slug]
        );
    }

    public function getAccessibleLessons(int $subjectId, string $userPlan = 'FREE', int $userXp = 0): array {
        $lessons = $this->getBySubject($subjectId);
        foreach ($lessons as &$lesson) {
            $lesson['is_accessible'] = \can_access_lesson($lesson['access_type'], $userPlan, $userXp);
        }
        return $lessons;
    }

    public function getProgress(int $userId, int $lessonId): ?array {
        return $this->db->fetch(
            "SELECT * FROM lesson_progressions WHERE user_id = :uid AND lesson_id = :lid LIMIT 1",
            ['uid' => $userId, 'lid' => $lessonId]
        );
    }

    public function getOrCreateProgress(int $userId, int $lessonId): array {
        $progress = $this->getProgress($userId, $lessonId);
        if (!$progress) {
            $this->db->insert('lesson_progressions', [
                'user_id' => $userId,
                'lesson_id' => $lessonId,
                'progress_percent' => 0,
                'is_completed' => 0,
                'started_at' => date('Y-m-d H:i:s'),
            ]);
            return $this->getProgress($userId, $lessonId);
        }
        return $progress;
    }

    public function markComplete(int $userId, int $lessonId, bool $skipped = false): array {
        $progress = $this->getOrCreateProgress($userId, $lessonId);
        $lesson = $this->find($lessonId);
        $xpEarned = 0;

        if (!$progress['is_completed']) {
            $xpEarned = $skipped ? 0 : ($lesson['xp_reward'] ?? XP_LESSON_COMPLETE);

            $this->db->update('lesson_progressions', [
                'is_completed' => 1,
                'is_skipped' => $skipped ? 1 : 0,
                'progress_percent' => 100,
                'xp_earned' => $xpEarned,
                'completed_at' => date('Y-m-d H:i:s'),
            ], 'id = :id', ['id' => $progress['id']]);

            if ($xpEarned > 0) {
                // Ajouter XP
                $this->db->query(
                    "UPDATE users SET xp_total = xp_total + :xp WHERE id = :uid",
                    ['xp' => $xpEarned, 'uid' => $userId]
                );

                // Logger XP
                $this->db->insert('xp_logs', [
                    'user_id' => $userId,
                    'amount' => $xpEarned,
                    'source' => 'lesson_complete',
                    'source_id' => $lessonId,
                    'description' => 'Leçon terminée: ' . ($lesson['title'] ?? ''),
                    'created_at' => date('Y-m-d H:i:s'),
                ]);

                // Recalculer niveau
                $this->recalculateLevel($userId);
            }

            // Incrémenter completions_count
            $this->db->query(
                "UPDATE lessons SET completions_count = completions_count + 1 WHERE id = :id",
                ['id' => $lessonId]
            );
        }

        return ['success' => true, 'xp_earned' => $xpEarned];
    }

    public function incrementViews(int $lessonId): void {
        $this->db->query(
            "UPDATE lessons SET views_count = views_count + 1 WHERE id = :id",
            ['id' => $lessonId]
        );
    }

    public function getRecent(int $limit = 10): array {
        return $this->db->fetchAll(
            "SELECT l.*, s.name as subject_name FROM lessons l
             JOIN subjects s ON l.subject_id = s.id
             WHERE l.is_active = 1 ORDER BY l.created_at DESC LIMIT {$limit}"
        );
    }

    public function getPopular(int $limit = 10): array {
        return $this->db->fetchAll(
            "SELECT l.*, s.name as subject_name FROM lessons l
             JOIN subjects s ON l.subject_id = s.id
             WHERE l.is_active = 1 ORDER BY l.views_count DESC LIMIT {$limit}"
        );
    }

    public function search(string $query): array {
        return $this->db->fetchAll(
            "SELECT l.*, s.name as subject_name, lv.name as level_name
             FROM lessons l
             JOIN subjects s ON l.subject_id = s.id
             JOIN levels lv ON l.level_id = lv.id
             WHERE l.is_active = 1 AND (l.title LIKE :q OR l.description LIKE :q)
             LIMIT 20",
            ['q' => '%' . $query . '%']
        );
    }

    private function recalculateLevel(int $userId): void {
        $xp = $this->db->fetchColumn("SELECT xp_total FROM users WHERE id = :id", ['id' => $userId]);
        $newLevel = \xp_to_level((int)$xp);
        $oldLevel = $this->db->fetchColumn("SELECT level FROM users WHERE id = :id", ['id' => $userId]);

        if ($newLevel > $oldLevel) {
            $this->db->update('users', ['level' => $newLevel], 'id = :id', ['id' => $userId]);
            notify($userId, 'level_up', 'Niveau supérieur !', "Félicitations ! Vous êtes maintenant niveau {$newLevel} : " . \level_name($newLevel));
        }
    }

    public function getComments(int $lessonId): array {
        return $this->db->fetchAll(
            "SELECT c.*, u.fullname, u.avatar FROM comments c
             JOIN users u ON c.user_id = u.id
             WHERE c.lesson_id = :lid AND c.is_approved = 1 AND c.parent_id IS NULL
             ORDER BY c.created_at DESC",
            ['lid' => $lessonId]
        );
    }

    public function addComment(int $userId, int $lessonId, string $content): void {
        $this->db->insert('comments', [
            'user_id' => $userId,
            'lesson_id' => $lessonId,
            'content' => htmlspecialchars(trim($content)),
            'is_approved' => 1,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}

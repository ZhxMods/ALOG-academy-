<?php
namespace App\Models;

use App\Core\Model;

class Subject extends Model {
    protected string $table = 'subjects';
    protected string $primaryKey = 'id';
    protected array $fillable = ['level_id', 'name', 'slug', 'description', 'icon', 'color', 'image', 'sort_order', 'is_active'];

    public function getByLevel(int $levelId): array {
        return $this->where('level_id', $levelId, 'sort_order', 'ASC');
    }

    public function getBySlug(string $slug): ?array {
        return $this->findWhere('slug', $slug);
    }

    public function getActive(): array {
        return $this->where('is_active', 1, 'sort_order', 'ASC');
    }

    public function getWithLevel(int $id): ?array {
        $subject = $this->find($id);
        if ($subject) {
            $subject['level'] = $this->db->fetch(
                "SELECT * FROM levels WHERE id = :id LIMIT 1",
                ['id' => $subject['level_id']]
            );
            $subject['lessons_count'] = $this->db->fetchColumn(
                "SELECT COUNT(*) FROM lessons WHERE subject_id = :sid AND is_active = 1",
                ['sid' => $id]
            );
        }
        return $subject;
    }
}

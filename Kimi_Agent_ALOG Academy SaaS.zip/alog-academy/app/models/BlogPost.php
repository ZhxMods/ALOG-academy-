<?php
namespace App\Models;

use App\Core\Model;

class BlogPost extends Model {
    protected string $table = 'blog_posts';
    protected string $primaryKey = 'id';
    protected array $fillable = [
        'category_id', 'author_id', 'title', 'slug', 'excerpt', 'content',
        'featured_image', 'meta_title', 'meta_description',
        'views_count', 'is_published', 'published_at'
    ];

    public function getPublished(int $page = 1, int $perPage = 10, ?int $categoryId = null): array {
        $where = "is_published = 1 AND published_at <= NOW()";
        $params = [];
        if ($categoryId) {
            $where .= " AND category_id = :cat";
            $params['cat'] = $categoryId;
        }
        $total = $this->count($where, $params);
        $pag = \paginate($total, $page, $perPage);
        $items = $this->db->fetchAll(
            "SELECT bp.*, bc.name as category_name, bc.slug as category_slug, u.fullname as author_name
             FROM blog_posts bp
             LEFT JOIN blog_categories bc ON bp.category_id = bc.id
             LEFT JOIN users u ON bp.author_id = u.id
             WHERE {$where}
             ORDER BY bp.published_at DESC
             LIMIT {$pag['per_page']} OFFSET {$pag['offset']}",
            $params
        );
        return ['items' => $items, 'pagination' => $pag];
    }

    public function getBySlug(string $slug): ?array {
        return $this->db->fetch(
            "SELECT bp.*, bc.name as category_name, bc.slug as category_slug, u.fullname as author_name
             FROM blog_posts bp
             LEFT JOIN blog_categories bc ON bp.category_id = bc.id
             LEFT JOIN users u ON bp.author_id = u.id
             WHERE bp.slug = :slug AND bp.is_published = 1 LIMIT 1",
            ['slug' => $slug]
        );
    }

    public function getRecent(int $limit = 5): array {
        return $this->db->fetchAll(
            "SELECT bp.*, bc.name as category_name FROM blog_posts bp
             LEFT JOIN blog_categories bc ON bp.category_id = bc.id
             WHERE bp.is_published = 1 ORDER BY bp.published_at DESC LIMIT {$limit}"
        );
    }

    public function getByCategory(int $categoryId, int $limit = 10): array {
        return $this->db->fetchAll(
            "SELECT bp.*, bc.name as category_name, u.fullname as author_name
             FROM blog_posts bp
             LEFT JOIN blog_categories bc ON bp.category_id = bc.id
             LEFT JOIN users u ON bp.author_id = u.id
             WHERE bp.category_id = :cat AND bp.is_published = 1
             ORDER BY bp.published_at DESC LIMIT {$limit}",
            ['cat' => $categoryId]
        );
    }

    public function incrementViews(int $postId): void {
        $this->db->query(
            "UPDATE blog_posts SET views_count = views_count + 1 WHERE id = :id",
            ['id' => $postId]
        );
    }

    public function getCategories(): array {
        return $this->db->fetchAll("SELECT * FROM blog_categories ORDER BY name");
    }

    public function getCategoryBySlug(string $slug): ?array {
        return $this->db->fetch(
            "SELECT * FROM blog_categories WHERE slug = :slug LIMIT 1",
            ['slug' => $slug]
        );
    }

    public function search(string $query): array {
        return $this->db->fetchAll(
            "SELECT bp.*, bc.name as category_name FROM blog_posts bp
             LEFT JOIN blog_categories bc ON bp.category_id = bc.id
             WHERE bp.is_published = 1 AND (bp.title LIKE :q OR bp.content LIKE :q)
             LIMIT 20",
            ['q' => '%' . $query . '%']
        );
    }

    public function getPopular(int $limit = 5): array {
        return $this->db->fetchAll(
            "SELECT bp.*, bc.name as category_name FROM blog_posts bp
             LEFT JOIN blog_categories bc ON bp.category_id = bc.id
             WHERE bp.is_published = 1 ORDER BY bp.views_count DESC LIMIT {$limit}"
        );
    }

    public function countPublished(): int {
        return $this->count("is_published = 1");
    }

    public function publish(int $postId): void {
        $this->db->update($this->table, [
            'is_published' => 1,
            'published_at' => date('Y-m-d H:i:s'),
        ], 'id = :id', ['id' => $postId]);
    }

    public function unpublish(int $postId): void {
        $this->db->update($this->table, ['is_published' => 0], 'id = :id', ['id' => $postId]);
    }
}

<?php
namespace App\Models;

use App\Core\Model;

class Ranking extends Model {
    protected string $table = 'rankings';
    protected string $primaryKey = 'id';
    protected array $fillable = [
        'user_id', 'global_rank', 'regional_rank', 'region',
        'total_xp', 'lessons_completed', 'quizzes_passed',
        'perfect_scores', 'weekly_xp', 'monthly_xp'
    ];

    public function getGlobalLeaderboard(int $limit = 50): array {
        return $this->db->fetchAll(
            "SELECT u.id, u.fullname, u.avatar, u.xp_total, u.level, u.region,
                    COUNT(DISTINCT lp.lesson_id) as lessons_completed,
                    COUNT(DISTINCT qr.quiz_id) as quizzes_passed
             FROM users u
             LEFT JOIN lesson_progressions lp ON u.id = lp.user_id AND lp.is_completed = 1
             LEFT JOIN quiz_results qr ON u.id = qr.user_id AND qr.is_passed = 1
             WHERE u.role = 'student' AND u.status = 'active'
             GROUP BY u.id
             ORDER BY u.xp_total DESC
             LIMIT {$limit}"
        );
    }

    public function getRegionalLeaderboard(string $region, int $limit = 50): array {
        return $this->db->fetchAll(
            "SELECT u.id, u.fullname, u.avatar, u.xp_total, u.level, u.region,
                    COUNT(DISTINCT lp.lesson_id) as lessons_completed
             FROM users u
             LEFT JOIN lesson_progressions lp ON u.id = lp.user_id AND lp.is_completed = 1
             WHERE u.role = 'student' AND u.status = 'active' AND u.region = :region
             GROUP BY u.id
             ORDER BY u.xp_total DESC
             LIMIT {$limit}",
            ['region' => $region]
        );
    }

    public function getUserRank(int $userId): ?array {
        return $this->db->fetch(
            "SELECT * FROM v_leaderboard WHERE id = :id LIMIT 1",
            ['id' => $userId]
        );
    }

    public function getWeeklyLeaderboard(int $limit = 20): array {
        return $this->db->fetchAll(
            "SELECT u.id, u.fullname, u.avatar, u.level, u.region,
                    SUM(xl.amount) as weekly_xp
             FROM users u
             JOIN xp_logs xl ON u.id = xl.user_id
             WHERE u.role = 'student' AND u.status = 'active'
             AND xl.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY u.id
             ORDER BY weekly_xp DESC
             LIMIT {$limit}"
        );
    }

    public function getMonthlyLeaderboard(int $limit = 20): array {
        return $this->db->fetchAll(
            "SELECT u.id, u.fullname, u.avatar, u.level, u.region,
                    SUM(xl.amount) as monthly_xp
             FROM users u
             JOIN xp_logs xl ON u.id = xl.user_id
             WHERE u.role = 'student' AND u.status = 'active'
             AND xl.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY u.id
             ORDER BY monthly_xp DESC
             LIMIT {$limit}"
        );
    }

    public function getRegions(): array {
        return $this->db->fetchAll(
            "SELECT DISTINCT region FROM users WHERE role = 'student' AND region IS NOT NULL ORDER BY region"
        );
    }

    public function recalculate(int $userId): void {
        $stats = $this->db->fetch(
            "SELECT
                u.xp_total,
                u.region,
                COUNT(DISTINCT lp.lesson_id) as lessons_completed,
                COUNT(DISTINCT qr.quiz_id) as quizzes_passed,
                COUNT(DISTINCT CASE WHEN qr.percentage = 100 THEN qr.quiz_id END) as perfect_scores
             FROM users u
             LEFT JOIN lesson_progressions lp ON u.id = lp.user_id AND lp.is_completed = 1
             LEFT JOIN quiz_results qr ON u.id = qr.user_id AND qr.is_passed = 1
             WHERE u.id = :id
             GROUP BY u.id",
            ['id' => $userId]
        );

        if ($stats) {
            $this->db->query(
                "INSERT INTO rankings (user_id, total_xp, region, lessons_completed, quizzes_passed, perfect_scores, updated_at)
                 VALUES (:uid, :xp, :region, :lc, :qp, :ps, NOW())
                 ON DUPLICATE KEY UPDATE
                 total_xp = :xp, region = :region, lessons_completed = :lc,
                 quizzes_passed = :qp, perfect_scores = :ps, updated_at = NOW()",
                [
                    'uid' => $userId,
                    'xp' => $stats['xp_total'],
                    'region' => $stats['region'],
                    'lc' => $stats['lessons_completed'] ?? 0,
                    'qp' => $stats['quizzes_passed'] ?? 0,
                    'ps' => $stats['perfect_scores'] ?? 0,
                ]
            );
        }
    }

    public function getBadges(int $userId): array {
        return $this->db->fetchAll(
            "SELECT b.*, ub.earned_at FROM badges b
             JOIN user_badges ub ON b.id = ub.badge_id
             WHERE ub.user_id = :uid ORDER BY ub.earned_at DESC",
            ['uid' => $userId]
        );
    }

    public function checkAndAwardBadges(int $userId): void {
        $stats = $this->db->fetch(
            "SELECT
                u.level,
                u.xp_total,
                COUNT(DISTINCT lp.lesson_id) as lessons_completed,
                COUNT(DISTINCT qr.quiz_id) as quizzes_passed,
                COUNT(DISTINCT CASE WHEN qr.percentage = 100 THEN qr.quiz_id END) as perfect_scores,
                u.login_streak
             FROM users u
             LEFT JOIN lesson_progressions lp ON u.id = lp.user_id AND lp.is_completed = 1
             LEFT JOIN quiz_results qr ON u.id = qr.user_id
             WHERE u.id = :id
             GROUP BY u.id",
            ['id' => $userId]
        );

        if (!$stats) return;

        $badges = $this->db->fetchAll("SELECT * FROM badges");
        foreach ($badges as $badge) {
            $earned = false;
            switch ($badge['requirement_type']) {
                case 'lessons_completed':
                    $earned = ($stats['lessons_completed'] ?? 0) >= $badge['requirement_value'];
                    break;
                case 'quizzes_passed':
                    $earned = ($stats['quizzes_passed'] ?? 0) >= $badge['requirement_value'];
                    break;
                case 'perfect_scores':
                    $earned = ($stats['perfect_scores'] ?? 0) >= $badge['requirement_value'];
                    break;
                case 'login_streak':
                    $earned = ($stats['login_streak'] ?? 0) >= $badge['requirement_value'];
                    break;
                case 'level':
                    $earned = ($stats['level'] ?? 0) >= $badge['requirement_value'];
                    break;
                case 'xp_total':
                    $earned = ($stats['xp_total'] ?? 0) >= $badge['requirement_value'];
                    break;
            }

            if ($earned) {
                $exists = $this->db->fetch(
                    "SELECT id FROM user_badges WHERE user_id = :uid AND badge_id = :bid LIMIT 1",
                    ['uid' => $userId, 'bid' => $badge['id']]
                );
                if (!$exists) {
                    $this->db->insert('user_badges', [
                        'user_id' => $userId,
                        'badge_id' => $badge['id'],
                        'earned_at' => date('Y-m-d H:i:s'),
                    ]);
                    notify($userId, 'badge', 'Nouveau badge !', "Vous avez débloqué le badge : {$badge['name']}");
                }
            }
        }
    }
}

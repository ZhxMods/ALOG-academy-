<?php
namespace App\Models;

use App\Core\Model;

class Quiz extends Model {
    protected string $table = 'quizzes';
    protected string $primaryKey = 'id';
    protected array $fillable = [
        'lesson_id', 'subject_id', 'level_id', 'title', 'slug', 'description',
        'time_limit', 'passing_score', 'xp_reward', 'xp_perfect_bonus',
        'shuffle_questions', 'max_attempts', 'cooldown_hours', 'access_type', 'is_active'
    ];

    public function getActive(): array {
        return $this->where('is_active', 1, 'created_at', 'DESC');
    }

    public function getBySlug(string $slug): ?array {
        return $this->db->fetch(
            "SELECT q.*, s.name as subject_name, l.title as lesson_title
             FROM quizzes q
             LEFT JOIN subjects s ON q.subject_id = s.id
             LEFT JOIN lessons l ON q.lesson_id = l.id
             WHERE q.slug = :slug AND q.is_active = 1 LIMIT 1",
            ['slug' => $slug]
        );
    }

    public function getQuestions(int $quizId, bool $shuffle = true): array {
        $order = $shuffle ? 'RAND()' : 'sort_order ASC';
        return $this->db->fetchAll(
            "SELECT id, question, question_type, options, correct_answer, explanation, points, sort_order
             FROM quiz_questions WHERE quiz_id = :qid ORDER BY {$order}",
            ['qid' => $quizId]
        );
    }

    public function getQuestionsForStudent(int $quizId): array {
        $questions = $this->getQuestions($quizId);
        // Ne pas inclure la réponse correcte pour l'étudiant
        foreach ($questions as &$q) {
            unset($q['correct_answer']);
            unset($q['explanation']);
        }
        return $questions;
    }

    public function getAttemptsCount(int $userId, int $quizId): int {
        return $this->db->fetchColumn(
            "SELECT COUNT(*) FROM quiz_results WHERE user_id = :uid AND quiz_id = :qid",
            ['uid' => $userId, 'qid' => $quizId]
        );
    }

    public function getLastAttempt(int $userId, int $quizId): ?array {
        return $this->db->fetch(
            "SELECT * FROM quiz_results WHERE user_id = :uid AND quiz_id = :qid
             ORDER BY completed_at DESC LIMIT 1",
            ['uid' => $userId, 'qid' => $quizId]
        );
    }

    public function canRetake(int $userId, int $quizId): bool {
        $quiz = $this->find($quizId);
        if (!$quiz || !$quiz['cooldown_hours']) return true;

        $lastAttempt = $this->getLastAttempt($userId, $quizId);
        if (!$lastAttempt) return true;

        $cooldownEnd = strtotime($lastAttempt['completed_at'] . ' + ' . $quiz['cooldown_hours'] . ' hours');
        return time() >= $cooldownEnd;
    }

    public function getCooldownRemaining(int $userId, int $quizId): int {
        $quiz = $this->find($quizId);
        if (!$quiz || !$quiz['cooldown_hours']) return 0;

        $lastAttempt = $this->getLastAttempt($userId, $quizId);
        if (!$lastAttempt) return 0;

        $cooldownEnd = strtotime($lastAttempt['completed_at'] . ' + ' . $quiz['cooldown_hours'] . ' hours');
        return max(0, $cooldownEnd - time());
    }

    public function submit(int $userId, int $quizId, array $answers, ?int $timeTaken = null): array {
        $quiz = $this->find($quizId);
        if (!$quiz) return ['success' => false, 'error' => 'Quiz introuvable'];

        $questions = $this->getQuestions($quizId, false);
        $score = 0;
        $maxScore = 0;
        $correctCount = 0;
        $details = [];

        foreach ($questions as $q) {
            $maxScore += $q['points'];
            $userAnswer = $answers[$q['id']] ?? null;
            $isCorrect = $userAnswer !== null && strval($userAnswer) === strval($q['correct_answer']);

            if ($isCorrect) {
                $score += $q['points'];
                $correctCount++;
            }

            $details[] = [
                'question_id' => $q['id'],
                'user_answer' => $userAnswer,
                'correct_answer' => $q['correct_answer'],
                'is_correct' => $isCorrect,
                'explanation' => $q['explanation'],
                'points' => $isCorrect ? $q['points'] : 0,
            ];
        }

        $percentage = $maxScore > 0 ? round(($score / $maxScore) * 100, 2) : 0;
        $isPassed = $percentage >= $quiz['passing_score'];
        $isPerfect = $percentage === 100;

        // Calculer l'XP
        $xpEarned = 0;
        if ($isPassed) {
            $xpEarned = $quiz['xp_reward'];
            if ($isPerfect) {
                $xpEarned += $quiz['xp_perfect_bonus'];
            }

            // Vérifier si déjà passé (pas de double XP)
            $alreadyPassed = $this->db->fetch(
                "SELECT id FROM quiz_results WHERE user_id = :uid AND quiz_id = :qid AND is_passed = 1 LIMIT 1",
                ['uid' => $userId, 'qid' => $quizId]
            );

            if ($alreadyPassed) {
                $xpEarned = 0; // Pas d'XP si déjà réussi
            }
        }

        $attemptNumber = $this->getAttemptsCount($userId, $quizId) + 1;

        // Sauvegarder le résultat
        $this->db->insert('quiz_results', [
            'user_id' => $userId,
            'quiz_id' => $quizId,
            'score' => $score,
            'max_score' => $maxScore,
            'percentage' => $percentage,
            'is_passed' => $isPassed ? 1 : 0,
            'answers' => json_encode($answers),
            'time_taken' => $timeTaken,
            'xp_earned' => $xpEarned,
            'attempt_number' => $attemptNumber,
            'completed_at' => date('Y-m-d H:i:s'),
        ]);

        // Ajouter XP si gagné
        if ($xpEarned > 0) {
            $this->db->query(
                "UPDATE users SET xp_total = xp_total + :xp WHERE id = :uid",
                ['xp' => $xpEarned, 'uid' => $userId]
            );

            $this->db->insert('xp_logs', [
                'user_id' => $userId,
                'amount' => $xpEarned,
                'source' => 'quiz_pass',
                'source_id' => $quizId,
                'description' => 'Quiz réussi: ' . $quiz['title'] . ($isPerfect ? ' (Score parfait!)' : ''),
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            // Recalculer le niveau
            $this->recalculateLevel($userId);

            // Notification
            notify($userId, 'quiz_result', $isPerfect ? 'Score parfait!' : 'Quiz réussi',
                "Vous avez obtenu {$percentage}% au quiz '{$quiz['title']}' (+{$xpEarned} XP)");
        }

        return [
            'success' => true,
            'score' => $score,
            'max_score' => $maxScore,
            'percentage' => $percentage,
            'is_passed' => $isPassed,
            'is_perfect' => $isPerfect,
            'xp_earned' => $xpEarned,
            'details' => $details,
            'attempt_number' => $attemptNumber,
        ];
    }

    public function getBySubject(int $subjectId): array {
        return $this->db->fetchAll(
            "SELECT * FROM quizzes WHERE subject_id = :sid AND is_active = 1 ORDER BY created_at DESC",
            ['sid' => $subjectId]
        );
    }

    public function getByLesson(int $lessonId): array {
        return $this->db->fetchAll(
            "SELECT * FROM quizzes WHERE lesson_id = :lid AND is_active = 1 ORDER BY created_at DESC",
            ['lid' => $lessonId]
        );
    }

    public function getResults(int $userId, int $quizId): array {
        return $this->db->fetchAll(
            "SELECT * FROM quiz_results WHERE user_id = :uid AND quiz_id = :qid ORDER BY completed_at DESC",
            ['uid' => $userId, 'qid' => $quizId]
        );
    }

    private function recalculateLevel(int $userId): void {
        $xp = $this->db->fetchColumn("SELECT xp_total FROM users WHERE id = :id", ['id' => $userId]);
        $newLevel = \xp_to_level((int)$xp);
        $oldLevel = $this->db->fetchColumn("SELECT level FROM users WHERE id = :id", ['id' => $userId]);

        if ($newLevel > $oldLevel) {
            $this->db->update('users', ['level' => $newLevel], 'id = :id', ['id' => $userId]);
            notify($userId, 'level_up', 'Niveau supérieur !', "Félicitations ! Niveau {$newLevel} atteint : " . \level_name($newLevel));
        }
    }
}

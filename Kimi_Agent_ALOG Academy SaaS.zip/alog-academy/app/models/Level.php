<?php
namespace App\Models;

use App\Core\Model;

class Level extends Model {
    protected string $table = 'levels';
    protected string $primaryKey = 'id';
    protected array $fillable = ['name', 'slug', 'description', 'icon', 'color', 'sort_order', 'is_active'];

    public function getActive(): array {
        return $this->where('is_active', 1, 'sort_order', 'ASC');
    }

    public function getWithSubjects(): array {
        $levels = $this->getActive();
        foreach ($levels as &$level) {
            $level['subjects'] = $this->db->fetchAll(
                "SELECT * FROM subjects WHERE level_id = :lid AND is_active = 1 ORDER BY sort_order ASC",
                ['lid' => $level['id']]
            );
        }
        return $levels;
    }

    public function getBySlug(string $slug): ?array {
        return $this->findWhere('slug', $slug);
    }
}

<?php
/**
 * ALOG ACADEMY - Fonctions Helpers Globales
 */

/**
 * Génère un token CSRF
 */
function csrf_token(): string {
    return $_SESSION[CSRF_TOKEN_NAME] ?? '';
}

/**
 * Champ input caché CSRF
 */
function csrf_field(): string {
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . htmlspecialchars(csrf_token()) . '">';
}

/**
 * Vérifie le token CSRF
 */
function verify_csrf(): bool {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return true;
    $token = $_POST[CSRF_TOKEN_NAME] ?? '';
    return hash_equals(csrf_token(), $token);
}

/**
 * Redirection
 */
function redirect(string $path = ''): void {
    $url = BASE_URL . '/' . ltrim($path, '/');
    header("Location: $url");
    exit;
}

/**
 * Ancienne valeur d'input
 */
function old(string $key, $default = ''): string {
    return htmlspecialchars($_SESSION['old'][$key] ?? $default);
}

/**
 * Stocke les anciennes valeurs
 */
function flash_old(array $data = []): void {
    $_SESSION['old'] = $data;
}

/**
 * Message flash
 */
function flash(string $key, string $message = ''): ?string {
    if ($message) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }
    $msg = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $msg;
}

/**
 * Vérifie si un message flash existe
 */
function has_flash(string $key): bool {
    return isset($_SESSION['flash'][$key]);
}

/**
 * Authentifié ?
 */
function auth(): ?array {
    return $_SESSION['user'] ?? null;
}

/**
 * Utilisateur connecté ?
 */
function is_logged_in(): bool {
    return isset($_SESSION['user']) && !empty($_SESSION['user']['id']);
}

/**
 * Rôle utilisateur
 */
function user_role(): string {
    return $_SESSION['user']['role'] ?? '';
}

/**
 * Est admin ?
 */
function is_admin(): bool {
    return in_array(user_role(), [ROLE_ADMIN, ROLE_SUPER_ADMIN]);
}

/**
 * Est super admin ?
 */
function is_super_admin(): bool {
    return user_role() === ROLE_SUPER_ADMIN;
}

/**
 * Vérifie le rôle
 */
function has_role(string $role): bool {
    return user_role() === $role;
}

/**
 * Asset URL
 */
function asset(string $path): string {
    return BASE_URL . '/assets/' . ltrim($path, '/');
}

/**
 * Upload URL
 */
function upload_url(string $filename): string {
    return BASE_URL . '/assets/uploads/' . $filename;
}

/**
 * Upload path
 */
function upload_path(string $filename = ''): string {
    return UPLOAD_PATH . ($filename ? '/' . $filename : '');
}

/**
 * Route URL
 */
function route(string $name, array $params = []): string {
    $routes = require ROOT_PATH . '/routes/web.php';
    // Simple route resolution
    return BASE_URL . '/' . ltrim($name, '/');
}

/**
 * URL actuelle
 */
function current_url(): string {
    return BASE_URL . $_SERVER['REQUEST_URI'];
}

/**
 * Méthode HTTP
 */
function request_method(): string {
    return $_SERVER['REQUEST_METHOD'];
}

/**
 * Est une requête POST ?
 */
function is_post(): bool {
    return request_method() === 'POST';
}

/**
 * Est une requête GET ?
 */
function is_get(): bool {
    return request_method() === 'GET';
}

/**
 * Donnée POST sécurisée
 */
function input(string $key, $default = '') {
    return $_POST[$key] ?? $_GET[$key] ?? $default;
}

/**
 * Échappement HTML
 */
function e(string $text): string {
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

/**
 * Tronquer texte
 */
function truncate(string $text, int $length = 100): string {
    if (strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . '...';
}

/**
 * Format date
 */
function format_date(?string $date, string $format = 'd/m/Y H:i'): string {
    if (!$date) return 'N/A';
    return date($format, strtotime($date));
}

/**
 * Format date relative
 */
function time_ago(?string $datetime): string {
    if (!$datetime) return '';
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;

    if ($diff < 60) return 'À l\'instant';
    if ($diff < 3600) return 'Il y a ' . floor($diff / 60) . ' min';
    if ($diff < 86400) return 'Il y a ' . floor($diff / 3600) . ' h';
    if ($diff < 604800) return 'Il y a ' . floor($diff / 86400) . ' j';
    return format_date($datetime);
}

/**
 * Format nombre XP
 */
function format_xp(int $xp): string {
    return number_format($xp, 0, ',', ' ');
}

/**
 * Niveau à partir de l'XP
 */
function xp_to_level(int $xp): int {
    $level = 1;
    $required = XP_LEVEL_BASE;
    while ($xp >= $required) {
        $xp -= (int)$required;
        $required *= XP_LEVEL_MULTIPLIER;
        $level++;
    }
    return max(1, $level);
}

/**
 * XP requis pour le niveau suivant
 */
function xp_for_level(int $level): int {
    return (int)(XP_LEVEL_BASE * pow(XP_LEVEL_MULTIPLIER, $level - 1));
}

/**
 * XP dans le niveau actuel
 */
function xp_in_current_level(int $totalXp): int {
    $level = 1;
    $required = XP_LEVEL_BASE;
    $remaining = $totalXp;
    while ($remaining >= $required) {
        $remaining -= (int)$required;
        $required *= XP_LEVEL_MULTIPLIER;
        $level++;
    }
    return $remaining;
}

/**
 * Pourcentage de progression dans le niveau
 */
function level_progress(int $totalXp): int {
    $level = xp_to_level($totalXp);
    $currentXp = xp_in_current_level($totalXp);
    $required = xp_for_level($level);
    return min(100, (int)(($currentXp / $required) * 100));
}

/**
 * Nom du niveau
 */
function level_name(int $level): string {
    $names = [
        1 => 'Débutant',
        2 => 'Apprenti',
        3 => 'Étudiant',
        4 => 'Collégien',
        5 => 'Lycéen',
        6 => 'Bachelier',
        7 => 'Universitaire',
        8 => 'Gradué',
        9 => 'Expert',
        10 => 'Maître',
        11 => 'Génie',
        12 => 'Légende',
    ];
    return $names[$level] ?? 'Niveau ' . $level;
}

/**
 * Badge pour un niveau
 */
function level_badge(int $level): string {
    $badges = [
        1 => 'badge-beginner',
        2 => 'badge-apprentice',
        3 => 'badge-student',
        4 => 'badge-highschool',
        5 => 'badge-bachelor',
        6 => 'badge-graduate',
        7 => 'badge-master',
        8 => 'badge-expert',
        9 => 'badge-genius',
        10 => 'badge-legend',
    ];
    return $badges[$level] ?? 'badge-default';
}

/**
 * Plan badge color
 */
function plan_color(string $plan): string {
    return match($plan) {
        'FREE' => 'secondary',
        'PRO' => 'primary',
        'ULTRA' => 'warning',
        default => 'secondary',
    };
}

/**
 * Plan label
 */
function plan_label(string $plan): string {
    return match($plan) {
        'FREE' => 'Gratuit',
        'PRO' => 'PRO',
        'ULTRA' => 'ULTRA',
        default => $plan,
    };
}

/**
 * Statut paiement badge
 */
function payment_status_badge(string $status): string {
    return match($status) {
        'pending' => '<span class="badge bg-warning">En attente</span>',
        'approved' => '<span class="badge bg-success">Approuvé</span>',
        'rejected' => '<span class="badge bg-danger">Rejeté</span>',
        default => '<span class="badge bg-secondary">' . e($status) . '</span>',
    };
}

/**
 * Génère un slug
 */
function slugify(string $text): string {
    $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
    $text = preg_replace('/[^a-zA-Z0-9\s-]/', '', $text);
    $text = strtolower(trim($text));
    $text = preg_replace('/[\s-]+/', '-', $text);
    return $text;
}

/**
 * YouTube embed URL
 */
function youtube_embed_url(string $url): string {
    preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]+)/', $url, $matches);
    return isset($matches[1]) ? 'https://www.youtube.com/embed/' . $matches[1] : $url;
}

/**
 * YouTube thumbnail
 */
function youtube_thumbnail(string $url): string {
    preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]+)/', $url, $matches);
    return isset($matches[1]) ? 'https://img.youtube.com/vi/' . $matches[1] . '/mqdefault.jpg' : '';
}

/**
 * Upload un fichier
 */
function upload_file(array $file, string $subdir = '', array $allowed = ['jpg','jpeg','png','pdf']): ?string {
    if ($file['error'] !== UPLOAD_ERR_OK) return null;

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) return null;

    $uploadDir = UPLOAD_PATH . ($subdir ? '/' . trim($subdir, '/') : '');
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $filename = uniqid() . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $filepath = $uploadDir . '/' . $filename;

    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return ($subdir ? trim($subdir, '/') . '/' : '') . $filename;
    }
    return null;
}

/**
 * Vérifie l'accès à une leçon
 */
function can_access_lesson(string $accessType, ?string $userPlan = 'FREE', int $userXp = 0): bool {
    return match($accessType) {
        'FREE' => true,
        'PRO' => in_array($userPlan, ['PRO', 'ULTRA']),
        'ULTRA' => $userPlan === 'ULTRA',
        'XP' => $userXp >= 100,
        default => false,
    };
}

/**
 * Pagination
 */
function paginate(int $total, int $page = 1, int $perPage = 10): array {
    $page = max(1, $page);
    $totalPages = (int)ceil($total / $perPage);
    $page = min($page, max(1, $totalPages));
    $offset = ($page - 1) * $perPage;

    return [
        'page' => $page,
        'per_page' => $perPage,
        'total' => $total,
        'total_pages' => $totalPages,
        'offset' => $offset,
        'has_prev' => $page > 1,
        'has_next' => $page < $totalPages,
        'prev_page' => $page - 1,
        'next_page' => $page + 1,
    ];
}

/**
 * Pagination HTML
 */
function pagination_links(array $pag, string $baseUrl): string {
    if ($pag['total_pages'] <= 1) return '';

    $html = '<nav aria-label="Pagination"><ul class="pagination justify-content-center">';

    // Previous
    $html .= '<li class="page-item ' . ($pag['has_prev'] ? '' : 'disabled') . '">';
    $html .= '<a class="page-link" href="' . $baseUrl . '?page=' . $pag['prev_page'] . '">Précédent</a></li>';

    // Pages
    $start = max(1, $pag['page'] - 2);
    $end = min($pag['total_pages'], $pag['page'] + 2);

    for ($i = $start; $i <= $end; $i++) {
        $active = $i === $pag['page'] ? 'active' : '';
        $html .= '<li class="page-item ' . $active . '">';
        $html .= '<a class="page-link" href="' . $baseUrl . '?page=' . $i . '">' . $i . '</a></li>';
    }

    // Next
    $html .= '<li class="page-item ' . ($pag['has_next'] ? '' : 'disabled') . '">';
    $html .= '<a class="page-link" href="' . $baseUrl . '?page=' . $pag['next_page'] . '">Suivant</a></li>';

    $html .= '</ul></nav>';
    return $html;
}

/**
 * Log d'erreur
 */
function log_error(string $message): void {
    $logFile = STORAGE_PATH . '/logs/error.log';
    $logDir = dirname($logFile);
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
    error_log($line, 3, $logFile);
}

/**
 * Envoi de notification
 */
function notify(int $userId, string $type, string $title, string $message): void {
    try {
        $db = \App\Core\Database::getInstance();
        $db->query(
            "INSERT INTO notifications (user_id, type, title, message, created_at) VALUES (:uid, :type, :title, :msg, NOW())",
            ['uid' => $userId, 'type' => $type, 'title' => $title, 'msg' => $message]
        );
    } catch (\Exception $e) {
        log_error('Notification error: ' . $e->getMessage());
    }
}

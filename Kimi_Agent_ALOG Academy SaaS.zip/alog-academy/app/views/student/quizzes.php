<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-question-circle text-warning me-2"></i>Quiz</h2>
    <p class="text-muted mb-0">Testez vos connaissances et gagnez des XP</p>
</div>

<div class="row g-4">
    <?php foreach ($quizzes as $quiz): ?>
    <div class="col-md-6 col-lg-4">
        <div class="card quiz-card border-0 shadow-sm h-100">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div class="quiz-icon bg-warning bg-opacity-10 text-warning">
                        <i class="bi bi-question-circle fs-2"></i>
                    </div>
                    <?php if ($quiz['last_attempt']): ?>
                        <?php if ($quiz['last_attempt']['is_passed']): ?>
                            <span class="badge bg-success"><i class="bi bi-check-lg"></i> Réussi</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Échoué</span>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <h5 class="fw-bold mb-2"><?= e($quiz['title']) ?></h5>
                <p class="text-muted small mb-3"><?= e(truncate($quiz['description'] ?? '', 80)) ?></p>

                <div class="d-flex flex-wrap gap-2 mb-3">
                    <span class="badge bg-primary bg-opacity-10 text-primary">
                        <i class="bi bi-lightning me-1"></i>+<?= $quiz['xp_reward'] ?> XP
                    </span>
                    <?php if ($quiz['time_limit']): ?>
                    <span class="badge bg-info bg-opacity-10 text-info">
                        <i class="bi bi-clock me-1"></i><?= $quiz['time_limit'] ?> min
                    </span>
                    <?php endif; ?>
                    <span class="badge bg-secondary bg-opacity-10 text-secondary">
                        <?= $quiz['passing_score'] ?>% pour réussir
                    </span>
                </div>

                <?php if ($quiz['attempts'] > 0): ?>
                <small class="text-muted d-block mb-3">
                    <?= $quiz['attempts'] ?> tentative<?= $quiz['attempts'] > 1 ? 's' : '' ?>
                    <?php if ($quiz['last_attempt']): ?>
                        | Dernier: <?= $quiz['last_attempt']['percentage'] ?>%
                    <?php endif; ?>
                </small>
                <?php endif; ?>

                <?php if (!$quiz['can_retake'] && $quiz['cooldown'] > 0): ?>
                    <?php $cooldownMin = ceil($quiz['cooldown'] / 60); ?>
                    <button class="btn btn-secondary btn-sm w-100" disabled>
                        <i class="bi bi-clock me-1"></i>Attendre <?= $cooldownMin ?> min
                    </button>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>/quiz/<?= $quiz['slug'] ?>" class="btn btn-warning btn-sm w-100">
                        <i class="bi bi-play-fill me-1"></i><?= $quiz['attempts'] > 0 ? 'Réessayer' : 'Commencer' ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php if (empty($quizzes)): ?>
<div class="text-center py-5">
    <i class="bi bi-inbox fs-1 text-muted"></i>
    <p class="text-muted mt-3">Aucun quiz disponible pour le moment.</p>
</div>
<?php endif; ?>

<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-layers text-primary me-2"></i>Niveaux</h2>
    <p class="text-muted mb-0">Choisissez votre niveau pour voir les matières disponibles</p>
</div>

<div class="row g-4">
    <?php foreach ($levels as $level): ?>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/levels/<?= $level['slug'] ?>" class="text-decoration-none">
            <div class="card level-card border-0 shadow-sm h-100 hover-lift">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="level-icon bg-<?= $level['color'] ?> bg-opacity-10 text-<?= $level['color'] ?> me-3">
                            <i class="bi bi-<?= $level['icon'] ?> fs-3"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0 text-body"><?= e($level['name']) ?></h5>
                            <small class="text-muted"><?= count($level['subjects'] ?? []) ?> matières</small>
                        </div>
                    </div>
                    <p class="text-muted small mb-0"><?= e(truncate($level['description'] ?? '', 100)) ?></p>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0 pb-3 px-4">
                    <span class="btn btn-<?= $level['color'] ?> btn-sm w-100">
                        Explorer <i class="bi bi-arrow-right ms-1"></i>
                    </span>
                </div>
            </div>
        </a>
    </div>
    <?php endforeach; ?>
</div>

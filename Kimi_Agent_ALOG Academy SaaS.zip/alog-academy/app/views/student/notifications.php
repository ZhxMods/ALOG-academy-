<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-bell text-primary me-2"></i>Notifications</h2>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <?php if (empty($notifications)): ?>
            <div class="text-center py-5">
                <i class="bi bi-bell-slash fs-1 text-muted"></i>
                <p class="text-muted mt-3">Aucune notification</p>
            </div>
        <?php else: ?>
            <div class="list-group list-group-flush">
                <?php foreach ($notifications as $notif): ?>
                <div class="list-group-item d-flex align-items-start py-3 <?= $notif['is_read'] ? 'bg-body-tertiary' : '' ?>">
                    <div class="flex-shrink-0 me-3">
                        <div class="notif-icon bg-<?= match($notif['type']) { 'level_up' => 'success', 'quiz_result' => 'warning', 'payment_status' => 'info', 'badge' => 'primary', default => 'secondary' } ?> bg-opacity-10 text-<?= match($notif['type']) { 'level_up' => 'success', 'quiz_result' => 'warning', 'payment_status' => 'info', 'badge' => 'primary', default => 'secondary' } ?>">
                            <i class="bi bi-<?= match($notif['type']) { 'level_up' => 'bar-chart', 'quiz_result' => 'check-circle', 'payment_status' => 'credit-card', 'badge' => 'award', default => 'bell' } ?>"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1">
                        <div class="d-flex justify-content-between">
                            <h6 class="fw-bold mb-1 <?= $notif['is_read'] ? 'text-muted' : '' ?>"><?= e($notif['title']) ?></h6>
                            <small class="text-muted"><?= time_ago($notif['created_at']) ?></small>
                        </div>
                        <p class="mb-0 <?= $notif['is_read'] ? 'text-muted' : '' ?>"><?= e($notif['message']) ?></p>
                    </div>
                    <?php if (!$notif['is_read']): ?>
                    <span class="badge bg-primary ms-2">Nouveau</span>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/levels">Niveaux</a></li>
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/levels/<?= $lesson['level_slug'] ?>"><?= e($lesson['level_name']) ?></a></li>
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/subjects/<?= $lesson['subject_slug'] ?>"><?= e($lesson['subject_name']) ?></a></li>
        <li class="breadcrumb-item active"><?= e(truncate($lesson['title'], 30)) ?></li>
    </ol>
</nav>

<div class="row g-4">
    <!-- Main Content -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <h2 class="fw-bold mb-1"><?= e($lesson['title']) ?></h2>
                        <span class="badge bg-primary bg-opacity-10 text-primary"><?= e($lesson['subject_name']) ?></span>
                        <span class="badge bg-success bg-opacity-10 text-success"><i class="bi bi-lightning me-1"></i>+<?= $lesson['xp_reward'] ?> XP</span>
                    </div>
                    <?php if ($progress && $progress['is_completed']): ?>
                        <span class="badge bg-success"><i class="bi bi-check-lg me-1"></i>Terminé</span>
                    <?php endif; ?>
                </div>

                <p class="text-muted"><?= e($lesson['description']) ?></p>

                <!-- YouTube Video -->
                <?php if ($lesson['youtube_url']): ?>
                <div class="ratio ratio-16x9 mb-4 rounded-3 overflow-hidden">
                    <iframe src="<?= youtube_embed_url($lesson['youtube_url']) ?>" 
                            title="<?= e($lesson['title']) ?>" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                            allowfullscreen></iframe>
                </div>
                <?php endif; ?>

                <!-- PDF Links -->
                <div class="d-flex flex-wrap gap-2 mb-4">
                    <?php if ($lesson['pdf_url']): ?>
                    <a href="<?= e($lesson['pdf_url']) ?>" target="_blank" class="btn btn-outline-primary">
                        <i class="bi bi-file-pdf me-1"></i>Cours PDF
                    </a>
                    <?php endif; ?>
                    <?php if ($lesson['exercise_pdf_url']): ?>
                    <a href="<?= e($lesson['exercise_pdf_url']) ?>" target="_blank" class="btn btn-outline-success">
                        <i class="bi bi-file-earmark-text me-1"></i>Exercices
                    </a>
                    <?php endif; ?>
                </div>

                <!-- Content -->
                <?php if ($lesson['content']): ?>
                <div class="lesson-content">
                    <?= nl2br(e($lesson['content'])) ?>
                </div>
                <?php endif; ?>

                <!-- Navigation -->
                <hr class="my-4">
                <div class="d-flex justify-content-between">
                    <?php if ($prevLesson): ?>
                    <a href="<?= BASE_URL ?>/lesson/<?= $prevLesson['slug'] ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-1"></i>Précédent
                    </a>
                    <?php else: ?>
                    <span></span>
                    <?php endif; ?>

                    <div class="d-flex gap-2">
                        <?php if (!$progress || !$progress['is_completed']): ?>
                        <form action="<?= BASE_URL ?>/lesson/<?= $lesson['id'] ?>/complete" method="POST" class="d-inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="skip" value="1">
                            <button type="submit" class="btn btn-outline-secondary">
                                <i class="bi bi-skip-forward me-1"></i>Passer
                            </button>
                        </form>
                        <form action="<?= BASE_URL ?>/lesson/<?= $lesson['id'] ?>/complete" method="POST" class="d-inline">
                            <?= csrf_field() ?>
                            <?php if ($nextLesson): ?>
                            <input type="hidden" name="next_lesson" value="<?= $nextLesson['slug'] ?>">
                            <?php endif; ?>
                            <button type="submit" class="btn btn-success">
                                <i class="bi bi-check-lg me-1"></i>Terminer (+<?= $lesson['xp_reward'] ?> XP)
                            </button>
                        </form>
                        <?php else: ?>
                        <span class="badge bg-success fs-6"><i class="bi bi-check-lg me-1"></i>Leçon terminée</span>
                        <?php endif; ?>
                    </div>

                    <?php if ($nextLesson): ?>
                    <a href="<?= BASE_URL ?>/lesson/<?= $nextLesson['slug'] ?>" class="btn btn-primary">
                        Suivant<i class="bi bi-arrow-right ms-1"></i>
                    </a>
                    <?php else: ?>
                    <span></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Quizzes -->
        <?php if (!empty($quizzes)): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3"><i class="bi bi-question-circle text-warning me-2"></i>Quiz associés</h5>
                <?php foreach ($quizzes as $quiz): ?>
                <div class="d-flex justify-content-between align-items-center p-3 bg-body-tertiary rounded-3 mb-2">
                    <div>
                        <h6 class="mb-1"><?= e($quiz['title']) ?></h6>
                        <small class="text-muted">Score minimum: <?= $quiz['passing_score'] ?>% | +<?= $quiz['xp_reward'] ?> XP</small>
                    </div>
                    <a href="<?= BASE_URL ?>/quiz/<?= $quiz['slug'] ?>" class="btn btn-warning btn-sm">
                        <i class="bi bi-play-fill me-1"></i>Commencer
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Comments -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3"><i class="bi bi-chat text-info me-2"></i>Commentaires</h5>
                
                <?php if (!empty($comments)): ?>
                    <?php foreach ($comments as $comment): ?>
                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <div class="avatar-circle-xs bg-primary"><?= strtoupper(substr($comment['fullname'], 0, 1)) ?></div>
                        </div>
                        <div class="ms-3">
                            <div class="d-flex align-items-center">
                                <strong class="me-2"><?= e($comment['fullname']) ?></strong>
                                <small class="text-muted"><?= time_ago($comment['created_at']) ?></small>
                            </div>
                            <p class="mb-0"><?= e($comment['content']) ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted">Soyez le premier à commenter !</p>
                <?php endif; ?>

                <form action="<?= BASE_URL ?>/lesson/<?= $lesson['id'] ?>/comment" method="POST" class="mt-3">
                    <?= csrf_field() ?>
                    <div class="input-group">
                        <input type="text" name="content" class="form-control" placeholder="Ajouter un commentaire..." required>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-3">Informations</h6>
                <ul class="list-unstyled text-muted">
                    <li class="mb-2"><i class="bi bi-clock me-2"></i><?= $lesson['duration_minutes'] ?? 0 ?> minutes</li>
                    <li class="mb-2"><i class="bi bi-eye me-2"></i><?= number_format($lesson['views_count']) ?> vues</li>
                    <li class="mb-2"><i class="bi bi-check-circle me-2"></i><?= number_format($lesson['completions_count']) ?> complétions</li>
                    <li class="mb-2"><i class="bi bi-lightning me-2"></i>+<?= $lesson['xp_reward'] ?> XP</li>
                    <li><i class="bi bi-shield me-2"></i><?= $lesson['access_type'] ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

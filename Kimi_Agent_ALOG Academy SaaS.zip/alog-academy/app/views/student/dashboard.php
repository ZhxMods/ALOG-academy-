<?php
$userId = auth()['id'];
$userPlan = auth()['plan'] ?? 'FREE';
$currentLevel = xp_to_level($user['xp_total'] ?? 0);
$nextLevelXp = xp_for_level($currentLevel);
$currentXpInLevel = xp_in_current_level($user['xp_total'] ?? 0);
$progressPercent = level_progress($user['xp_total'] ?? 0);
?>
<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1">Bienvenue, <?= e($user['fullname']) ?> !</h2>
    <p class="text-muted mb-0">Voici votre tableau de bord personnel</p>
</div>

<!-- Stats Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-0 shadow-sm">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                    <i class="bi bi-lightning"></i>
                </div>
                <div class="ms-3">
                    <h4 class="fw-bold mb-0"><?= format_xp($user['xp_total'] ?? 0) ?></h4>
                    <small class="text-muted">Points XP</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-0 shadow-sm">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-success bg-opacity-10 text-success">
                    <i class="bi bi-bar-chart"></i>
                </div>
                <div class="ms-3">
                    <h4 class="fw-bold mb-0">Niv. <?= $user['level'] ?? 1 ?></h4>
                    <small class="text-muted"><?= level_name($user['level'] ?? 1) ?></small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-0 shadow-sm">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                    <i class="bi bi-book"></i>
                </div>
                <div class="ms-3">
                    <h4 class="fw-bold mb-0"><?= $stats['lessons_completed'] ?? 0 ?></h4>
                    <small class="text-muted">Leçons terminées</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-0 shadow-sm">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-info bg-opacity-10 text-info">
                    <i class="bi bi-trophy"></i>
                </div>
                <div class="ms-3">
                    <h4 class="fw-bold mb-0"><?= $stats['quizzes_taken'] ?? 0 ?></h4>
                    <small class="text-muted">Quiz passés</small>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column -->
    <div class="col-lg-8">
        <!-- Level Progress -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0"><i class="bi bi-bar-chart-line text-primary me-2"></i>Progression Niveau <?= $currentLevel ?></h5>
                    <span class="badge bg-primary"><?= level_name($currentLevel) ?></span>
                </div>
                <div class="progress mb-2" style="height: 24px;">
                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary" 
                         role="progressbar" style="width: <?= $progressPercent ?>%">
                        <?= $progressPercent ?>%
                    </div>
                </div>
                <small class="text-muted"><?= format_xp($currentXpInLevel) ?> / <?= format_xp($nextLevelXp) ?> XP pour le niveau <?= $currentLevel + 1 ?></small>
            </div>
        </div>

        <!-- Continue Learning -->
        <?php if (!empty($inProgress)): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3"><i class="bi bi-play-circle text-success me-2"></i>Continuer l'apprentissage</h5>
                <?php foreach ($inProgress as $prog): ?>
                <div class="d-flex align-items-center p-3 bg-body-tertiary rounded-3 mb-2">
                    <div class="flex-shrink-0">
                        <div class="bg-primary bg-opacity-10 text-primary rounded-3 d-flex align-items-center justify-content-center" style="width: 48px; height: 48px;">
                            <i class="bi bi-book"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <h6 class="mb-1"><?= e($prog['title']) ?></h6>
                        <small class="text-muted"><?= e($prog['subject_name']) ?></small>
                        <div class="progress mt-1" style="height: 6px;">
                            <div class="progress-bar bg-success" style="width: <?= $prog['progress_percent'] ?>"></div>
                        </div>
                    </div>
                    <a href="<?= BASE_URL ?>/lesson/<?= $prog['slug'] ?>" class="btn btn-primary btn-sm">
                        <i class="bi bi-play-fill"></i>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Recent XP -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0"><i class="bi bi-lightning text-warning me-2"></i>Activité récente</h5>
                    <a href="<?= BASE_URL ?>/xp-history" class="btn btn-sm btn-outline-primary">Voir tout</a>
                </div>
                <?php if (empty($recentXp)): ?>
                    <p class="text-muted mb-0">Aucune activité récente. Commencez à apprendre !</p>
                <?php else: ?>
                    <?php foreach ($recentXp as $xp): ?>
                    <div class="d-flex align-items-center py-2 border-bottom">
                        <span class="badge bg-<?= match($xp['source']) { 'daily_login' => 'info', 'lesson_complete' => 'success', 'quiz_pass' => 'warning', default => 'secondary' } ?> me-2">
                            +<?= $xp['amount'] ?> XP
                        </span>
                        <span class="flex-grow-1 small"><?= e($xp['description']) ?></span>
                        <small class="text-muted"><?= time_ago($xp['created_at']) ?></small>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Right Column -->
    <div class="col-lg-4">
        <!-- Rank -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4 text-center">
                <h5 class="fw-bold mb-3"><i class="bi bi-trophy text-warning me-2"></i>Mon classement</h5>
                <?php if ($rankInfo): ?>
                    <div class="display-4 fw-bold text-primary mb-1">#<?= $rankInfo['global_rank'] ?? '?' ?></div>
                    <p class="text-muted mb-3">Classement global</p>
                    <?php if ($rankInfo['regional_rank']): ?>
                        <div class="badge bg-info bg-opacity-10 text-info mb-3">
                            #<?= $rankInfo['regional_rank'] ?> dans votre région
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="text-muted">Participez pour apparaître dans le classement !</p>
                <?php endif; ?>
                <a href="<?= BASE_URL ?>/rankings" class="btn btn-outline-primary btn-sm w-100">Voir le classement</a>
            </div>
        </div>

        <!-- Subscription -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3"><i class="bi bi-credit-card text-primary me-2"></i>Mon abonnement</h5>
                <div class="text-center">
                    <span class="badge bg-<?= plan_color($userPlan) ?> fs-6 px-3 py-2 mb-2"><?= plan_label($userPlan) ?></span>
                    <?php if ($activeSub && $activeSub['expires_at']): ?>
                        <p class="text-muted small mb-0">Expire le <?= format_date($activeSub['expires_at'], 'd/m/Y') ?></p>
                    <?php elseif ($userPlan === 'FREE'): ?>
                        <p class="text-muted small">Passez à PRO pour plus de contenu</p>
                        <a href="<?= BASE_URL ?>/pricing" class="btn btn-warning btn-sm w-100">Mettre à niveau</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Quick Links -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3">Liens rapides</h5>
                <div class="list-group list-group-flush">
                    <a href="<?= BASE_URL ?>/levels" class="list-group-item list-group-item-action px-0">
                        <i class="bi bi-book text-primary me-2"></i>Explorer les cours
                    </a>
                    <a href="<?= BASE_URL ?>/quizzes" class="list-group-item list-group-item-action px-0">
                        <i class="bi bi-question-circle text-success me-2"></i>Faire un quiz
                    </a>
                    <a href="<?= BASE_URL ?>/rankings" class="list-group-item list-group-item-action px-0">
                        <i class="bi bi-trophy text-warning me-2"></i>Classement
                    </a>
                    <a href="<?= BASE_URL ?>/profile" class="list-group-item list-group-item-action px-0">
                        <i class="bi bi-person text-info me-2"></i>Mon profil
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

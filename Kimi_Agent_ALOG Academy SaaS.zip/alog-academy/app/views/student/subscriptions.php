<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-credit-card text-primary me-2"></i>Mes abonnements</h2>
</div>

<!-- Current Plan -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-4">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h5 class="fw-bold mb-2">Abonnement actuel</h5>
                <span class="badge bg-<?= plan_color(auth()['plan'] ?? 'FREE') ?> fs-5 px-3 py-2">
                    <?= plan_label(auth()['plan'] ?? 'FREE') ?>
                </span>
                <?php if ($activeSub && $activeSub['expires_at']): ?>
                    <p class="text-muted mt-2 mb-0">
                        <i class="bi bi-calendar me-1"></i>Expire le <?= format_date($activeSub['expires_at'], 'd/m/Y') ?>
                    </p>
                <?php endif; ?>
            </div>
            <div class="col-md-6 text-md-end mt-3 mt-md-0">
                <a href="<?= BASE_URL ?>/pricing" class="btn btn-warning">
                    <i class="bi bi-arrow-up-circle me-1"></i>Changer de plan
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Payment History -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-4">
        <h5 class="fw-bold mb-3"><i class="bi bi-clock-history me-2"></i>Historique des paiements</h5>
        <?php if (empty($payments)): ?>
            <p class="text-muted mb-0">Aucun paiement enregistré.</p>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Plan</th>
                        <th>Montant</th>
                        <th>Statut</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payments as $payment): ?>
                    <tr>
                        <td><?= format_date($payment['created_at']) ?></td>
                        <td><span class="badge bg-<?= plan_color($payment['plan']) ?>"><?= plan_label($payment['plan']) ?></span></td>
                        <td><?= $payment['amount'] ?> MAD</td>
                        <td><?= payment_status_badge($payment['status']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- How to subscribe -->
<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <h5 class="fw-bold mb-3"><i class="bi bi-info-circle text-info me-2"></i>Comment s'abonner ?</h5>
        <div class="row g-3">
            <div class="col-md-4 text-center">
                <div class="step-number-circle bg-primary text-white mx-auto mb-2">1</div>
                <h6 class="fw-bold">Choisissez un plan</h6>
                <small class="text-muted">Sélectionnez PRO (49 MAD) ou ULTRA (99 MAD)</small>
            </div>
            <div class="col-md-4 text-center">
                <div class="step-number-circle bg-success text-white mx-auto mb-2">2</div>
                <h6 class="fw-bold">Payez par WhatsApp</h6>
                <small class="text-muted">Envoyez le paiement au <?= WHATSAPP_NUMBER ?></small>
            </div>
            <div class="col-md-4 text-center">
                <div class="step-number-circle bg-warning text-dark mx-auto mb-2">3</div>
                <h6 class="fw-bold">Activation</h6>
                <small class="text-muted">Votre compte est activé sous 24h</small>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>?text=Bonjour,%20je%20souhaite%20m'abonner%20à%20ALOG%20Academy" 
               target="_blank" class="btn btn-success btn-lg">
                <i class="bi bi-whatsapp me-2"></i>Payer via WhatsApp
            </a>
        </div>
    </div>
</div>

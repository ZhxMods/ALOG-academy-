<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-calendar-check text-primary me-2"></i>Mes réservations</h2>
</div>

<!-- New Booking Form -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-4">
        <h5 class="fw-bold mb-3">Nouvelle réservation</h5>
        <form action="<?= BASE_URL ?>/bookings/create" method="POST">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Type</label>
                    <select name="booking_type" class="form-select" required>
                        <option value="tutoring">Soutien scolaire</option>
                        <option value="coaching">Coaching</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Sujet / Matière</label>
                    <input type="text" name="subject" class="form-control" placeholder="Ex: Mathématiques, Bac..." required>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Date</label>
                    <input type="date" name="preferred_date" class="form-control">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Heure</label>
                    <input type="time" name="preferred_time" class="form-control">
                </div>
                <div class="col-12">
                    <label class="form-label">Message</label>
                    <textarea name="message" class="form-control" rows="2" placeholder="Décrivez votre besoin..."></textarea>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-send me-1"></i>Envoyer la demande
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Bookings List -->
<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <h5 class="fw-bold mb-3">Mes demandes</h5>
        <?php if (empty($bookings)): ?>
            <p class="text-muted mb-0">Aucune réservation pour le moment.</p>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Type</th>
                        <th>Sujet</th>
                        <th>Date préférée</th>
                        <th>Statut</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $booking): ?>
                    <tr>
                        <td>
                            <span class="badge bg-<?= $booking['booking_type'] === 'coaching' ? 'info' : 'primary' ?>">
                                <?= $booking['booking_type'] === 'coaching' ? 'Coaching' : 'Soutien' ?>
                            </span>
                        </td>
                        <td><?= e($booking['subject']) ?></td>
                        <td><?= $booking['preferred_date'] ? format_date($booking['preferred_date'], 'd/m/Y') . ' ' . ($booking['preferred_time'] ?? '') : '-' ?></td>
                        <td>
                            <?= match($booking['status']) {
                                'pending' => '<span class="badge bg-warning">En attente</span>',
                                'approved' => '<span class="badge bg-success">Approuvé</span>',
                                'rejected' => '<span class="badge bg-danger">Rejeté</span>',
                                'completed' => '<span class="badge bg-info">Terminé</span>',
                                'cancelled' => '<span class="badge bg-secondary">Annulé</span>',
                                default => '<span class="badge bg-secondary">' . e($booking['status']) . '</span>',
                            } ?>
                        </td>
                        <td>
                            <?php if ($booking['status'] === 'pending'): ?>
                            <form action="<?= BASE_URL ?>/bookings/<?= $booking['id'] ?>/cancel" method="POST" class="d-inline">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">Annuler</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-5 text-center">
                <!-- Score Circle -->
                <div class="score-circle mx-auto mb-4 <?= $attempt['is_passed'] ? ($attempt['percentage'] == 100 ? 'perfect' : 'passed') : 'failed' ?>">
                    <div class="score-inner">
                        <span class="score-percent"><?= $attempt['percentage'] ?>%</span>
                        <span class="score-label"><?= $attempt['score'] ?>/<?= $attempt['max_score'] ?></span>
                    </div>
                </div>

                <h2 class="fw-bold mb-2">
                    <?php if ($attempt['percentage'] == 100): ?>
                        <i class="bi bi-trophy-fill text-warning"></i> Score parfait !
                    <?php elseif ($attempt['is_passed']): ?>
                        <i class="bi bi-check-circle-fill text-success"></i> Quiz réussi !
                    <?php else: ?>
                        <i class="bi bi-x-circle-fill text-danger"></i> Quiz non réussi
                    <?php endif; ?>
                </h2>

                <?php if ($attempt['xp_earned'] > 0): ?>
                <div class="alert alert-success d-inline-block">
                    <i class="bi bi-lightning me-2"></i>+<strong><?= $attempt['xp_earned'] ?></strong> XP gagnés !
                </div>
                <?php endif; ?>

                <div class="d-flex justify-content-center gap-3 mt-3">
                    <span class="badge bg-primary">Tentative #<?= $attempt['attempt_number'] ?></span>
                    <?php if ($attempt['time_taken']): ?>
                    <span class="badge bg-info"><?= floor($attempt['time_taken'] / 60) ?>:<?= str_pad($attempt['time_taken'] % 60, 2, '0', STR_PAD_LEFT) ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Correction -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h4 class="fw-bold mb-4"><i class="bi bi-journal-check text-primary me-2"></i>Correction détaillée</h4>

                <?php foreach ($questions as $index => $q): ?>
                <?php
                $userAnswer = $userAnswers[$q['id']] ?? null;
                $isCorrect = strval($userAnswer) === strval($q['correct_answer']);
                $options = json_decode($q['options'] ?? '[]', true);
                ?>
                <div class="quiz-correction-item mb-3 p-3 rounded-3 <?= $isCorrect ? 'bg-success bg-opacity-10 border-start border-success border-4' : 'bg-danger bg-opacity-10 border-start border-danger border-4' ?>">
                    <div class="d-flex align-items-start mb-2">
                        <span class="badge bg-<?= $isCorrect ? 'success' : 'danger' ?> me-2">
                            <i class="bi bi-<?= $isCorrect ? 'check' : 'x' ?>-lg"></i>
                        </span>
                        <div>
                            <strong>Question <?= $index + 1 ?>:</strong> <?= e($q['question']) ?>
                            <span class="badge bg-secondary ms-1"><?= $q['points'] ?> pt</span>
                        </div>
                    </div>

                    <div class="ms-4">
                        <?php if ($q['question_type'] === 'true_false'): ?>
                            <p class="mb-1">
                                <strong>Votre réponse:</strong> 
                                <span class="text-<?= $isCorrect ? 'success' : 'danger' ?>"><?= $userAnswer == '1' ? 'Vrai' : ($userAnswer == '0' ? 'Faux' : 'Non répondu') ?></span>
                            </p>
                            <?php if (!$isCorrect): ?>
                            <p class="mb-1"><strong>Bonne réponse:</strong> <span class="text-success"><?= $q['correct_answer'] == '1' ? 'Vrai' : 'Faux' ?></span></p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p class="mb-1">
                                <strong>Votre réponse:</strong> 
                                <span class="text-<?= $isCorrect ? 'success' : 'danger' ?>"><?= $userAnswer !== null ? e($options[$userAnswer] ?? 'Non répondu') : 'Non répondu' ?></span>
                            </p>
                            <?php if (!$isCorrect): ?>
                            <p class="mb-1"><strong>Bonne réponse:</strong> <span class="text-success"><?= e($options[$q['correct_answer']] ?? $q['correct_answer']) ?></span></p>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if ($q['explanation']): ?>
                        <div class="alert alert-info mt-2 mb-0 py-2">
                            <small><i class="bi bi-info-circle me-1"></i><?= e($q['explanation']) ?></small>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>

                <div class="text-center mt-4">
                    <a href="<?= BASE_URL ?>/quizzes" class="btn btn-primary me-2"><i class="bi bi-arrow-left me-1"></i>Tous les quiz</a>
                    <a href="<?= BASE_URL ?>/quiz/<?= $quiz['slug'] ?>" class="btn btn-warning"><i class="bi bi-arrow-repeat me-1"></i>Réessayer</a>
                </div>
            </div>
        </div>
    </div>
</div>

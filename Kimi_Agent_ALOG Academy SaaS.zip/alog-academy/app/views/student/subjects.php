<nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/levels">Niveaux</a></li>
        <li class="breadcrumb-item active"><?= e($level['name']) ?></li>
    </ol>
</nav>

<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-bookmark text-primary me-2"></i><?= e($level['name']) ?></h2>
    <p class="text-muted mb-0"><?= e($level['description'] ?? 'Choisissez une matière') ?></p>
</div>

<div class="row g-4">
    <?php foreach ($subjects as $subject): ?>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/subjects/<?= $subject['slug'] ?>" class="text-decoration-none">
            <div class="card subject-card border-0 shadow-sm h-100 hover-lift">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="subject-icon bg-<?= $subject['color'] ?> bg-opacity-10 text-<?= $subject['color'] ?> me-3">
                            <i class="bi bi-<?= $subject['icon'] ?> fs-3"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0 text-body"><?= e($subject['name']) ?></h5>
                        </div>
                    </div>
                    <?php if ($subject['description']): ?>
                    <p class="text-muted small"><?= e(truncate($subject['description'], 80)) ?></p>
                    <?php endif; ?>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0 pb-3 px-4">
                    <span class="btn btn-outline-<?= $subject['color'] ?> btn-sm w-100">
                        Voir les leçons <i class="bi bi-arrow-right ms-1"></i>
                    </span>
                </div>
            </div>
        </a>
    </div>
    <?php endforeach; ?>
</div>

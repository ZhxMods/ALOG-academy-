<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-lightning text-warning me-2"></i>Historique XP</h2>
    <p class="text-muted mb-0">Toute votre progression en détail</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <?php if (empty($logs)): ?>
            <div class="text-center py-5">
                <i class="bi bi-lightning-slash fs-1 text-muted"></i>
                <p class="text-muted mt-3">Aucun historique pour le moment. Commencez à apprendre !</p>
            </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Source</th>
                        <th>Description</th>
                        <th class="text-end">XP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?= format_date($log['created_at']) ?></td>
                        <td>
                            <span class="badge bg-<?= match($log['source']) { 'daily_login' => 'info', 'lesson_complete' => 'success', 'quiz_pass' => 'warning', default => 'secondary' } ?>">
                                <?= match($log['source']) { 'daily_login' => 'Connexion', 'lesson_complete' => 'Leçon', 'quiz_pass' => 'Quiz', default => e($log['source']) } ?>
                            </span>
                        </td>
                        <td><?= e($log['description']) ?></td>
                        <td class="text-end fw-bold text-<?= $log['amount'] > 0 ? 'success' : 'danger' ?>">
                            <?= $log['amount'] > 0 ? '+' : '' ?><?= $log['amount'] ?> XP
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($pagination['total_pages'] > 1): ?>
            <div class="p-3">
                <?= pagination_links($pagination, BASE_URL . '/xp-history') ?>
            </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

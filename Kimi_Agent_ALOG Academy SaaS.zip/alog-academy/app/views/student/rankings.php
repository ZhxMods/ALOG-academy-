<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-trophy text-warning me-2"></i>Classement</h2>
    <p class="text-muted mb-0">Comparez-vous aux autres étudiants</p>
</div>

<!-- My Rank -->
<?php if ($userRank): ?>
<div class="card border-0 shadow-sm mb-4 bg-warning bg-opacity-10">
    <div class="card-body p-4">
        <div class="row align-items-center">
            <div class="col-md-4 text-center">
                <h3 class="fw-bold text-warning mb-0">#<?= $userRank['global_rank'] ?? '?' ?></h3>
                <small class="text-muted">Rang mondial</small>
            </div>
            <div class="col-md-4 text-center">
                <h4 class="fw-bold mb-0"><?= format_xp($userRank['xp_total'] ?? 0) ?> XP</h4>
                <small class="text-muted">Points totaux</small>
            </div>
            <div class="col-md-4 text-center">
                <h4 class="fw-bold mb-0">Niv. <?= $userRank['level'] ?? 1 ?></h4>
                <small class="text-muted"><?= level_name($userRank['level'] ?? 1) ?></small>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Tabs -->
<ul class="nav nav-pills mb-4" id="rankingTabs">
    <li class="nav-item">
        <a class="nav-link <?= $currentType === 'global' ? 'active' : '' ?>" href="<?= BASE_URL ?>/rankings?type=global">Global</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $currentType === 'weekly' ? 'active' : '' ?>" href="<?= BASE_URL ?>/rankings?type=weekly">Hebdo</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $currentType === 'monthly' ? 'active' : '' ?>" href="<?= BASE_URL ?>/rankings?type=monthly">Mensuel</a>
    </li>
    <?php if (!empty($regions)): ?>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle <?= $currentType === 'regional' ? 'active' : '' ?>" href="#" data-bs-toggle="dropdown">Régional</a>
        <ul class="dropdown-menu">
            <?php foreach ($regions as $r): ?>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/rankings?type=regional&region=<?= $r['region'] ?>"><?= e(ucfirst($r['region'])) ?></a></li>
            <?php endforeach; ?>
        </ul>
    </li>
    <?php endif; ?>
</ul>

<!-- Leaderboard Table -->
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="text-center" style="width:60px">#</th>
                        <th>Étudiant</th>
                        <th class="text-center">Niveau</th>
                        <th class="text-center">XP</th>
                        <th class="text-center">Leçons</th>
                        <th class="text-center">Quiz</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($leaderboard as $index => $entry): ?>
                    <?php $isMe = ($entry['id'] ?? null) == (auth()['id'] ?? 0); ?>
                    <tr class="<?= $isMe ? 'table-warning' : '' ?> <?= $index < 3 ? 'rank-top-' . ($index + 1) : '' ?>">
                        <td class="text-center fw-bold">
                            <?php if ($index === 0): ?><i class="bi bi-trophy-fill text-warning"></i>
                            <?php elseif ($index === 1): ?><i class="bi bi-trophy-fill text-secondary"></i>
                            <?php elseif ($index === 2): ?><i class="bi bi-trophy-fill" style="color:#cd7f32"></i>
                            <?php else: ?>#<?= $index + 1 ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <?php if (!empty($entry['avatar'])): ?>
                                    <img src="<?= upload_url($entry['avatar']) ?>" class="rounded-circle me-2" width="32" height="32">
                                <?php else: ?>
                                    <div class="avatar-circle-xs bg-primary me-2"><?= strtoupper(substr($entry['fullname'], 0, 1)) ?></div>
                                <?php endif; ?>
                                <span><?= e($entry['fullname']) ?> <?= $isMe ? '<span class="badge bg-warning ms-1">Vous</span>' : '' ?></span>
                            </div>
                        </td>
                        <td class="text-center">
                            <span class="badge bg-primary"><?= $entry['level'] ?? 1 ?></span>
                        </td>
                        <td class="text-center fw-semibold"><?= format_xp($entry['xp_total'] ?? ($entry['weekly_xp'] ?? ($entry['monthly_xp'] ?? 0))) ?></td>
                        <td class="text-center"><?= $entry['lessons_completed'] ?? 0 ?></td>
                        <td class="text-center"><?= $entry['quizzes_passed'] ?? 0 ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if (empty($leaderboard)): ?>
<div class="text-center py-5">
    <i class="bi bi-trophy fs-1 text-muted"></i>
    <p class="text-muted mt-3">Aucun classement pour le moment.</p>
</div>
<?php endif; ?>

<!-- Badges -->
<?php if (!empty($badges)): ?>
<div class="card border-0 shadow-sm mt-4">
    <div class="card-body p-4">
        <h5 class="fw-bold mb-3"><i class="bi bi-award text-warning me-2"></i>Mes badges</h5>
        <div class="row g-3">
            <?php foreach ($badges as $badge): ?>
            <div class="col-md-4 col-lg-3">
                <div class="badge-item text-center p-3 bg-body-tertiary rounded-3">
                    <i class="bi bi-<?= $badge['icon'] ?> fs-2 text-<?= $badge['color'] ?> mb-2"></i>
                    <h6 class="fw-bold mb-1"><?= e($badge['name']) ?></h6>
                    <small class="text-muted"><?= e($badge['description']) ?></small>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/quizzes">Quiz</a></li>
        <li class="breadcrumb-item active"><?= e(truncate($quiz['title'], 30)) ?></li>
    </ol>
</nav>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <div class="text-center mb-4">
                    <div class="quiz-header-icon bg-warning bg-opacity-10 text-warning mb-3">
                        <i class="bi bi-question-circle fs-1"></i>
                    </div>
                    <h2 class="fw-bold"><?= e($quiz['title']) ?></h2>
                    <p class="text-muted"><?= e($quiz['description']) ?></p>
                    <div class="d-flex justify-content-center gap-2">
                        <span class="badge bg-primary"><?= count($questions) ?> questions</span>
                        <span class="badge bg-success">+<?= $quiz['xp_reward'] ?> XP</span>
                        <?php if ($quiz['time_limit']): ?>
                        <span class="badge bg-danger" id="timer"><i class="bi bi-clock me-1"></i><span id="timeLeft"><?= $quiz['time_limit'] ?>:00</span></span>
                        <?php endif; ?>
                    </div>
                </div>

                <form action="<?= BASE_URL ?>/quiz/<?= $quiz['id'] ?>/submit" method="POST" id="quizForm">
                    <?= csrf_field() ?>
                    <input type="hidden" name="time_taken" id="timeTaken" value="0">

                    <?php foreach ($questions as $index => $q): ?>
                    <div class="quiz-question mb-4 p-4 bg-body-tertiary rounded-3">
                        <h6 class="fw-bold mb-3">
                            <span class="badge bg-primary me-2"><?= $index + 1 ?></span>
                            <?= e($q['question']) ?>
                            <span class="badge bg-success bg-opacity-10 text-success ms-2"><?= $q['points'] ?> pt<?= $q['points'] > 1 ? 's' : '' ?></span>
                        </h6>

                        <?php if ($q['question_type'] === 'true_false'): ?>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="radio" name="answers[<?= $q['id'] ?>]" value="1" id="q<?= $q['id'] ?>_true" required>
                                <label class="form-check-label" for="q<?= $q['id'] ?>_true">Vrai</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="answers[<?= $q['id'] ?>]" value="0" id="q<?= $q['id'] ?>_false" required>
                                <label class="form-check-label" for="q<?= $q['id'] ?>_false">Faux</label>
                            </div>
                        <?php else: ?>
                            <?php $options = json_decode($q['options'] ?? '[]', true); ?>
                            <?php foreach ($options as $optIndex => $option): ?>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="radio" name="answers[<?= $q['id'] ?>]" value="<?= $optIndex ?>" id="q<?= $q['id'] ?>_<?= $optIndex ?>" required>
                                <label class="form-check-label" for="q<?= $q['id'] ?>_<?= $optIndex ?>"><?= e($option) ?></label>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>

                    <div class="text-center">
                        <button type="submit" class="btn btn-warning btn-lg fw-semibold px-5">
                            <i class="bi bi-send me-2"></i>Soumettre mes réponses
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php if ($quiz['time_limit']): ?>
<script>
const timeLimitMinutes = <?= $quiz['time_limit'] ?>;
let timeLeft = timeLimitMinutes * 60;
const timerEl = document.getElementById('timeLeft');
const timeTakenEl = document.getElementById('timeTaken');
let elapsed = 0;

const timer = setInterval(() => {
    timeLeft--;
    elapsed++;
    timeTakenEl.value = elapsed;
    const mins = Math.floor(timeLeft / 60);
    const secs = timeLeft % 60;
    timerEl.textContent = `${mins}:${secs.toString().padStart(2, '0')}`;
    
    if (timeLeft <= 60) {
        document.getElementById('timer').classList.remove('bg-danger');
        document.getElementById('timer').classList.add('bg-dark');
    }
    
    if (timeLeft <= 0) {
        clearInterval(timer);
        document.getElementById('quizForm').submit();
    }
}, 1000);
</script>
<?php endif; ?>

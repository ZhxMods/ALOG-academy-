<?php
$currentLevel = xp_to_level($user['xp_total'] ?? 0);
$progressPercent = level_progress($user['xp_total'] ?? 0);
?>
<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-person text-primary me-2"></i>Mon profil</h2>
</div>

<div class="row g-4">
    <div class="col-lg-4">
        <!-- Profile Card -->
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body p-4">
                <div class="position-relative d-inline-block mb-3">
                    <?php if (!empty($user['avatar'])): ?>
                        <img src="<?= upload_url($user['avatar']) ?>" class="rounded-circle" width="120" height="120" style="object-fit:cover;">
                    <?php else: ?>
                        <div class="avatar-circle-lg bg-primary mx-auto"><?= strtoupper(substr($user['fullname'], 0, 1)) ?></div>
                    <?php endif; ?>
                    <span class="badge bg-<?= plan_color($user['plan'] ?? 'FREE') ?> position-absolute bottom-0 end-0"><?= plan_label($user['plan'] ?? 'FREE') ?></span>
                </div>
                <h4 class="fw-bold mb-1"><?= e($user['fullname']) ?></h4>
                <p class="text-muted mb-2"><?= e($user['email']) ?></p>
                <div class="mb-3">
                    <span class="badge bg-primary">Niv. <?= $user['level'] ?? 1 ?> : <?= level_name($user['level'] ?? 1) ?></span>
                </div>
                <div class="progress mb-1" style="height: 10px;">
                    <div class="progress-bar bg-primary" style="width: <?= $progressPercent ?>%"></div>
                </div>
                <small class="text-muted"><?= format_xp($user['xp_total'] ?? 0) ?> XP total</small>
            </div>
        </div>

        <!-- Stats -->
        <div class="card border-0 shadow-sm mt-4">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-3">Statistiques</h6>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Leçons terminées</span>
                    <strong><?= $stats['lessons_completed'] ?? 0 ?></strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Quiz passés</span>
                    <strong><?= $stats['quizzes_taken'] ?? 0 ?></strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Score moyen</span>
                    <strong><?= $stats['avg_quiz_score'] ? round($stats['avg_quiz_score'], 1) : 0 ?>%</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Badges</span>
                    <strong><?= $stats['badges_count'] ?? 0 ?></strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Membre depuis</span>
                    <strong><?= format_date($user['created_at'], 'd/m/Y') ?></strong>
                </div>
            </div>
        </div>

        <!-- Badges -->
        <?php if (!empty($badges)): ?>
        <div class="card border-0 shadow-sm mt-4">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-3">Badges</h6>
                <div class="d-flex flex-wrap gap-2">
                    <?php foreach ($badges as $badge): ?>
                    <span class="badge bg-<?= $badge['color'] ?> bg-opacity-10 text-<?= $badge['color'] ?> p-2" title="<?= e($badge['description']) ?>">
                        <i class="bi bi-<?= $badge['icon'] ?> me-1"></i><?= e($badge['name']) ?>
                    </span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-4">Modifier mon profil</h5>
                <form action="<?= BASE_URL ?>/profile/update" method="POST" enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nom complet</label>
                            <input type="text" name="fullname" class="form-control" value="<?= e($user['fullname']) ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" value="<?= e($user['email']) ?>" disabled>
                            <small class="text-muted">L'email ne peut pas être modifié</small>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Téléphone</label>
                            <input type="text" name="phone" class="form-control" value="<?= e($user['phone'] ?? '') ?>" placeholder="+2126XXXXXXXX">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Ville</label>
                            <input type="text" name="city" class="form-control" value="<?= e($user['city'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Région</label>
                            <select name="region" class="form-select">
                                <option value="">-- Sélectionnez --</option>
                                <?php foreach (['casablanca-settat','rabat-sale-kenitra','marrakech-safi','tanger-tetouan-al-hoceima','fes-meknes','oriental','beni-mellal-khenifra','draa-tafilalet','souss-massa','guelmim-oued-noun','laayoune-sakia-el-hamra','dakhla-oued-ed-dahab','autre'] as $r): ?>
                                <option value="<?= $r ?>" <?= ($user['region'] ?? '') === $r ? 'selected' : '' ?>><?= ucfirst(str_replace('-', ' ', $r)) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">École / Université</label>
                            <input type="text" name="school" class="form-control" value="<?= e($user['school'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Bio</label>
                        <textarea name="bio" class="form-control" rows="3" placeholder="Parlez-nous de vous..."><?= e($user['bio'] ?? '') ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Photo de profil</label>
                        <input type="file" name="avatar" class="form-control" accept="image/*">
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg me-1"></i>Enregistrer
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

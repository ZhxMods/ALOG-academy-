<nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/levels">Niveaux</a></li>
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/levels/<?= $subject['level_slug'] ?? '' ?>"><?= e($subject['level_name'] ?? '') ?></a></li>
        <li class="breadcrumb-item active"><?= e($subject['name']) ?></li>
    </ol>
</nav>

<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-book text-primary me-2"></i><?= e($subject['name']) ?></h2>
    <p class="text-muted mb-0"><?= count($lessons) ?> leçons disponibles</p>
</div>

<div class="row g-4">
    <?php foreach ($lessons as $lesson): ?>
    <div class="col-md-6 col-lg-4">
        <div class="card lesson-card border-0 shadow-sm h-100 <?= !$lesson['is_accessible'] ? 'locked' : '' ?>">
            <div class="lesson-img-wrapper position-relative">
                <?php if ($lesson['image_url']): ?>
                    <img src="<?= e($lesson['image_url']) ?>" class="card-img-top" alt="" style="height: 160px; object-fit: cover;">
                <?php elseif ($lesson['youtube_url']): ?>
                    <img src="<?= youtube_thumbnail($lesson['youtube_url']) ?>" class="card-img-top" alt="" style="height: 160px; object-fit: cover;">
                <?php else: ?>
                    <div class="bg-primary bg-opacity-10 d-flex align-items-center justify-content-center" style="height: 160px;">
                        <i class="bi bi-book text-primary fs-1"></i>
                    </div>
                <?php endif; ?>

                <?php if ($lesson['access_type'] !== 'FREE'): ?>
                    <span class="badge bg-<?= $lesson['access_type'] === 'ULTRA' ? 'warning text-dark' : 'primary' ?> position-absolute top-0 start-0 m-2">
                        <i class="bi bi-star-fill me-1"></i><?= $lesson['access_type'] ?>
                    </span>
                <?php endif; ?>

                <?php if (!empty($lesson['progress']) && $lesson['progress']['is_completed']): ?>
                    <span class="badge bg-success position-absolute top-0 end-0 m-2"><i class="bi bi-check-lg"></i></span>
                <?php endif; ?>

                <?php if (!$lesson['is_accessible']): ?>
                    <div class="lesson-overlay d-flex align-items-center justify-content-center">
                        <i class="bi bi-lock-fill fs-1 text-white"></i>
                    </div>
                <?php endif; ?>
            </div>

            <div class="card-body p-3">
                <h6 class="fw-bold mb-1"><?= e($lesson['title']) ?></h6>
                <p class="text-muted small mb-2"><?= e(truncate($lesson['description'] ?? '', 60)) ?></p>

                <?php if (!empty($lesson['progress']) && !$lesson['progress']['is_completed']): ?>
                <div class="progress mb-2" style="height: 6px;">
                    <div class="progress-bar bg-primary" style="width: <?= $lesson['progress']['progress_percent'] ?>"></div>
                </div>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center">
                    <span class="badge bg-success bg-opacity-10 text-success small">
                        <i class="bi bi-lightning me-1"></i>+<?= $lesson['xp_reward'] ?> XP
                    </span>
                    <span class="text-muted small"><i class="bi bi-clock me-1"></i><?= $lesson['duration_minutes'] ?? 0 ?> min</span>
                </div>
            </div>

            <div class="card-footer bg-transparent border-0 pt-0 pb-3 px-3">
                <?php if ($lesson['is_accessible']): ?>
                    <a href="<?= BASE_URL ?>/lesson/<?= $lesson['slug'] ?>" class="btn btn-primary btn-sm w-100">
                        <i class="bi bi-play-fill me-1"></i><?= !empty($lesson['progress']) && $lesson['progress']['is_completed'] ? 'Revoir' : 'Commencer' ?>
                    </a>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>/pricing" class="btn btn-outline-warning btn-sm w-100">
                        <i class="bi bi-lock me-1"></i>Débloquer
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php if (empty($lessons)): ?>
<div class="text-center py-5">
    <i class="bi bi-inbox fs-1 text-muted"></i>
    <p class="text-muted mt-3">Aucune leçon disponible pour cette matière.</p>
</div>
<?php endif; ?>

<?php
// HERO SECTION
?>
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center min-vh-75">
            <div class="col-lg-6">
                <div class="hero-badge mb-3">
                    <span class="badge bg-warning text-dark fs-6 px-3 py-2">
                        <i class="bi bi-stars me-1"></i> Plateforme éducative #1 au Maroc
                    </span>
                </div>
                <h1 class="hero-title">Apprenez en vous<br><span class="text-primary">amusant</span></h1>
                <p class="hero-subtitle lead">Cours en ligne, quiz interactifs et système de récompenses pour les étudiants marocains du collège au supérieur.</p>
                <div class="hero-cta">
                    <a href="<?= BASE_URL ?>/levels" class="btn btn-primary btn-lg me-2 mb-2">
                        <i class="bi bi-play-fill me-1"></i>Commencer gratuitement
                    </a>
                    <a href="<?= BASE_URL ?>/pricing" class="btn btn-outline-primary btn-lg mb-2">
                        <i class="bi bi-crown me-1"></i>Voir les plans
                    </a>
                </div>
                <div class="hero-stats mt-4">
                    <div class="d-flex gap-4">
                        <div><strong class="fs-4"><?= number_format($userCount ?? 0) ?></strong><br><small class="text-muted">Étudiants</small></div>
                        <div><strong class="fs-4"><?= number_format($lessonCount ?? 0) ?></strong><br><small class="text-muted">Leçons</small></div>
                        <div><strong class="fs-4"><?= number_format($quizCount ?? 0) ?></strong><br><small class="text-muted">Quiz</small></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 d-none d-lg-block">
                <div class="hero-illustration">
                    <div class="floating-card card-1">
                        <i class="bi bi-trophy-fill text-warning fs-1"></i>
                        <div><strong>+50 XP</strong><br><small>Quiz réussi!</small></div>
                    </div>
                    <div class="floating-card card-2">
                        <i class="bi bi-fire text-danger fs-1"></i>
                        <div><strong>Niveau 5</strong><br><small>Continuez!</small></div>
                    </div>
                    <div class="hero-img-wrapper">
                        <div class="hero-img-bg"></div>
                        <i class="bi bi-mortarboard-fill hero-icon"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php // LEVELS SECTION ?>
<section class="py-5 bg-body-tertiary">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Choisissez votre <span class="text-primary">niveau</span></h2>
            <p class="text-muted">Des cours adaptés à chaque étape de votre parcours scolaire</p>
        </div>
        <div class="row g-4">
            <?php foreach ($levels as $level): ?>
            <div class="col-md-6 col-lg-4 col-xl">
                <a href="<?= BASE_URL ?>/levels/<?= $level['slug'] ?>" class="text-decoration-none">
                    <div class="card level-card h-100 border-0 shadow-sm hover-lift">
                        <div class="card-body text-center p-4">
                            <div class="level-icon bg-<?= $level['color'] ?> bg-opacity-10 text-<?= $level['color'] ?> mb-3">
                                <i class="bi bi-<?= $level['icon'] ?> fs-1"></i>
                            </div>
                            <h5 class="fw-bold mb-2"><?= e($level['name']) ?></h5>
                            <p class="text-muted small mb-3"><?= e(truncate($level['description'] ?? '', 80)) ?></p>
                            <span class="badge bg-<?= $level['color'] ?> bg-opacity-10 text-<?= $level['color'] ?>">
                                <?= count($level['subjects'] ?? []) ?> matières
                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php // FEATURES SECTION ?>
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Pourquoi choisir <span class="text-primary">ALOG Academy</span> ?</h2>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card feature-card border-0 h-100">
                    <div class="card-body p-4 text-center">
                        <div class="feature-icon bg-primary bg-opacity-10 text-primary mb-3">
                            <i class="bi bi-collection-play fs-1"></i>
                        </div>
                        <h5 class="fw-bold">Cours vidéo</h5>
                        <p class="text-muted">Des leçons avec vidéos YouTube intégrées et supports PDF téléchargeables.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card feature-card border-0 h-100">
                    <div class="card-body p-4 text-center">
                        <div class="feature-icon bg-success bg-opacity-10 text-success mb-3">
                            <i class="bi bi-controller fs-1"></i>
                        </div>
                        <h5 class="fw-bold">Gamification</h5>
                        <p class="text-muted">Gagnez des XP, montez de niveau et grimpez dans le classement national.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card feature-card border-0 h-100">
                    <div class="card-body p-4 text-center">
                        <div class="feature-icon bg-warning bg-opacity-10 text-warning mb-3">
                            <i class="bi bi-question-circle fs-1"></i>
                        </div>
                        <h5 class="fw-bold">Quiz interactifs</h5>
                        <p class="text-muted">Testez vos connaissances avec des QCM et Vrai/Faux avec correction détaillée.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card feature-card border-0 h-100">
                    <div class="card-body p-4 text-center">
                        <div class="feature-icon bg-info bg-opacity-10 text-info mb-3">
                            <i class="bi bi-trophy fs-1"></i>
                        </div>
                        <h5 class="fw-bold">Classement</h5>
                        <p class="text-muted">Comparez-vous aux autres étudiants au Maroc et dans votre région.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card feature-card border-0 h-100">
                    <div class="card-body p-4 text-center">
                        <div class="feature-icon bg-danger bg-opacity-10 text-danger mb-3">
                            <i class="bi bi-phone fs-1"></i>
                        </div>
                        <h5 class="fw-bold">Mobile-first</h5>
                        <p class="text-muted">Apprenez où que vous soyez, sur mobile, tablette ou ordinateur.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card feature-card border-0 h-100">
                    <div class="card-body p-4 text-center">
                        <div class="feature-icon bg-secondary bg-opacity-10 text-secondary mb-3">
                            <i class="bi bi-moon-stars fs-1"></i>
                        </div>
                        <h5 class="fw-bold">Mode sombre</h5>
                        <p class="text-muted">Étudiez confortablement de jour comme de nuit avec le mode dark.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php // RECENT LESSONS ?>
<section class="py-5 bg-body-tertiary">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0">Leçons <span class="text-primary">récentes</span></h2>
            <a href="<?= BASE_URL ?>/levels" class="btn btn-outline-primary btn-sm">Voir tout</a>
        </div>
        <div class="row g-4">
            <?php foreach ($recentLessons as $lesson): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card lesson-card border-0 shadow-sm h-100 hover-lift">
                    <div class="lesson-img-wrapper position-relative">
                        <?php if ($lesson['image_url']): ?>
                            <img src="<?= e($lesson['image_url']) ?>" class="card-img-top" alt="" style="height: 160px; object-fit: cover;">
                        <?php elseif ($lesson['youtube_url']): ?>
                            <img src="<?= youtube_thumbnail($lesson['youtube_url']) ?>" class="card-img-top" alt="" style="height: 160px; object-fit: cover;">
                        <?php else: ?>
                            <div class="bg-primary bg-opacity-10 d-flex align-items-center justify-content-center" style="height: 160px;">
                                <i class="bi bi-book text-primary fs-1"></i>
                            </div>
                        <?php endif; ?>
                        <span class="badge bg-dark position-absolute top-0 end-0 m-2">
                            <i class="bi bi-clock me-1"></i><?= $lesson['duration_minutes'] ?? 0 ?> min
                        </span>
                        <?php if ($lesson['access_type'] !== 'FREE'): ?>
                            <span class="badge bg-warning text-dark position-absolute top-0 start-0 m-2">
                                <i class="bi bi-star-fill me-1"></i><?= $lesson['access_type'] ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body p-3">
                        <small class="text-muted"><?= e($lesson['subject_name'] ?? '') ?></small>
                        <h6 class="fw-bold mb-2"><?= e($lesson['title']) ?></h6>
                        <p class="text-muted small mb-3"><?= e(truncate($lesson['description'] ?? '', 80)) ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-success bg-opacity-10 text-success">
                                <i class="bi bi-lightning me-1"></i>+<?= $lesson['xp_reward'] ?> XP
                            </span>
                            <a href="<?= BASE_URL ?>/lesson/<?= $lesson['slug'] ?>" class="btn btn-primary btn-sm">
                                <i class="bi bi-play-fill"></i> Voir
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php // CTA SECTION ?>
<section class="py-5">
    <div class="container">
        <div class="cta-card text-center p-5 rounded-4">
            <h2 class="fw-bold mb-3">Prêt à commencer votre parcours ?</h2>
            <p class="lead mb-4">Rejoignez des milliers d'étudiants marocains qui apprennent avec ALOG Academy.</p>
            <a href="<?= BASE_URL ?>/register" class="btn btn-warning btn-lg fw-semibold px-5">
                <i class="bi bi-rocket-fill me-2"></i>Créer un compte gratuit
            </a>
        </div>
    </div>
</section>

<?php // BLOG PREVIEW ?>
<section class="py-5 bg-body-tertiary">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0">Blog <span class="text-primary">éducatif</span></h2>
            <a href="<?= BASE_URL ?>/blog" class="btn btn-outline-primary btn-sm">Voir tout</a>
        </div>
        <div class="row g-4">
            <?php foreach ($blogPosts as $post): ?>
            <div class="col-md-4">
                <a href="<?= BASE_URL ?>/blog/<?= $post['slug'] ?>" class="text-decoration-none">
                    <div class="card blog-card border-0 shadow-sm h-100 hover-lift">
                        <?php if ($post['featured_image']): ?>
                            <img src="<?= e($post['featured_image']) ?>" class="card-img-top" alt="" style="height: 180px; object-fit: cover;">
                        <?php else: ?>
                            <div class="bg-info bg-opacity-10 d-flex align-items-center justify-content-center" style="height: 180px;">
                                <i class="bi bi-newspaper text-info fs-1"></i>
                            </div>
                        <?php endif; ?>
                        <div class="card-body p-3">
                            <span class="badge bg-primary bg-opacity-10 text-primary mb-2"><?= e($post['category_name'] ?? 'Article') ?></span>
                            <h6 class="fw-bold text-body"><?= e($post['title']) ?></h6>
                            <p class="text-muted small mb-0"><?= e(truncate($post['excerpt'] ?? $post['content'], 100)) ?></p>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

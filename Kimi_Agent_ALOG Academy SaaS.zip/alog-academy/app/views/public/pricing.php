<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="fw-bold display-5">Choisissez votre <span class="text-primary">plan</span></h1>
            <p class="lead text-muted">Commencez gratuitement, passez à PRO ou ULTRA pour débloquer tout le contenu</p>
        </div>

        <div class="row g-4 justify-content-center">
            <!-- FREE -->
            <div class="col-lg-4 col-md-6">
                <div class="card pricing-card border-0 shadow-sm h-100">
                    <div class="card-body p-4 text-center">
                        <div class="pricing-badge bg-secondary bg-opacity-10 text-secondary mb-3">GRATUIT</div>
                        <h2 class="fw-bold mb-1">0 MAD</h2>
                        <p class="text-muted mb-4">Pour toujours</p>
                        <hr class="my-4">
                        <ul class="list-unstyled text-start mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Accès aux leçons gratuites</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Quiz gratuits</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Système d'XP et niveaux</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Classement global</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Blog éducatif</li>
                            <li class="mb-2 text-muted"><i class="bi bi-x-circle-fill me-2"></i>Leçons PRO et ULTRA</li>
                            <li class="mb-2 text-muted"><i class="bi bi-x-circle-fill me-2"></i>Support prioritaire</li>
                            <li class="mb-2 text-muted"><i class="bi bi-x-circle-fill me-2"></i>Coaching personnalisé</li>
                        </ul>
                        <a href="<?= BASE_URL ?>/register" class="btn btn-outline-secondary w-100">Commencer gratuitement</a>
                    </div>
                </div>
            </div>

            <!-- PRO -->
            <div class="col-lg-4 col-md-6">
                <div class="card pricing-card border-primary border-2 shadow h-100 position-relative">
                    <span class="badge bg-primary position-absolute top-0 start-50 translate-middle px-3 py-2">POPULAIRE</span>
                    <div class="card-body p-4 text-center">
                        <div class="pricing-badge bg-primary bg-opacity-10 text-primary mb-3">PRO</div>
                        <h2 class="fw-bold mb-1">49 MAD</h2>
                        <p class="text-muted mb-4">/mois</p>
                        <hr class="my-4">
                        <ul class="list-unstyled text-start mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Tout le plan FREE</strong></li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Accès aux leçons PRO</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Tous les quiz PRO</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>PDF téléchargeables</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Exercices corrigés</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Support par email</li>
                            <li class="mb-2 text-muted"><i class="bi bi-x-circle-fill me-2"></i>Leçons ULTRA</li>
                            <li class="mb-2 text-muted"><i class="bi bi-x-circle-fill me-2"></i>Coaching privé</li>
                        </ul>
                        <button type="button" class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#subscribeModal" data-plan="PRO">
                            <i class="bi bi-credit-card me-1"></i>S'abonner PRO
                        </button>
                    </div>
                </div>
            </div>

            <!-- ULTRA -->
            <div class="col-lg-4 col-md-6">
                <div class="card pricing-card border-warning border-2 shadow h-100">
                    <div class="card-body p-4 text-center">
                        <div class="pricing-badge bg-warning bg-opacity-10 text-warning mb-3">ULTRA</div>
                        <h2 class="fw-bold mb-1">99 MAD</h2>
                        <p class="text-muted mb-4">/mois</p>
                        <hr class="my-4">
                        <ul class="list-unstyled text-start mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Tout le plan PRO</strong></li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Accès à TOUTES les leçons</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Tous les quiz ULTRA</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Coaching personnalisé</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Réservation de cours privés</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Support WhatsApp prioritaire</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Bonus XP quotidien</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Badge ULTRA exclusif</li>
                        </ul>
                        <button type="button" class="btn btn-warning w-100" data-bs-toggle="modal" data-bs-target="#subscribeModal" data-plan="ULTRA">
                            <i class="bi bi-crown me-1"></i>S'abonner ULTRA
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center mt-5">
            <div class="card border-0 shadow-sm p-4 d-inline-block">
                <h5 class="fw-bold mb-3"><i class="bi bi-whatsapp text-success me-2"></i>Paiement par WhatsApp</h5>
                <p class="text-muted mb-3">Envoyez votre paiement via WhatsApp et nous activons votre compte sous 24h.</p>
                <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>?text=Bonjour,%20je%20souhaite%20m'abonner%20à%20ALOG%20Academy" 
                   target="_blank" class="btn btn-success">
                    <i class="bi bi-whatsapp me-1"></i><?= WHATSAPP_NUMBER ?>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Modal Subscription -->
<div class="modal fade" id="subscribeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">S'abonner <span id="modalPlanName"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?= BASE_URL ?>/subscribe" method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="plan" id="modalPlanInput">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>Envoyez le montant via WhatsApp, puis téléchargez la capture d'écran.
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Montant à payer</label>
                        <input type="text" class="form-control" id="modalPlanPrice" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Votre numéro WhatsApp</label>
                        <input type="text" name="whatsapp" class="form-control" placeholder="+2126XXXXXXXX" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Capture d'écran du paiement</label>
                        <input type="file" name="proof" class="form-control" accept="image/*">
                        <small class="text-muted">Facultatif mais recommandé</small>
                    </div>
                    <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>" target="_blank" class="btn btn-success w-100">
                        <i class="bi bi-whatsapp me-1"></i>Payer via WhatsApp
                    </a>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Confirmer la demande</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('subscribeModal').addEventListener('show.bs.modal', function(e) {
    const btn = e.relatedTarget;
    const plan = btn.dataset.plan;
    document.getElementById('modalPlanName').textContent = plan;
    document.getElementById('modalPlanInput').value = plan;
    document.getElementById('modalPlanPrice').value = plan === 'ULTRA' ? '99 MAD' : '49 MAD';
});
</script>

<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="fw-bold display-5">Blog <span class="text-primary">éducatif</span></h1>
            <p class="lead text-muted">Conseils, méthodes et motivation pour réussir vos études</p>
        </div>

        <div class="row g-4">
            <!-- Sidebar categories -->
            <div class="col-lg-3">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body p-3">
                        <h6 class="fw-bold mb-3">Catégories</h6>
                        <div class="list-group list-group-flush">
                            <a href="<?= BASE_URL ?>/blog" class="list-group-item list-group-item-action <?= !$currentCategory ? 'active' : '' ?>">
                                <i class="bi bi-grid me-2"></i>Toutes
                            </a>
                            <?php foreach ($categories as $cat): ?>
                            <a href="<?= BASE_URL ?>/blog?category=<?= $cat['id'] ?>"
                               class="list-group-item list-group-item-action <?= ($currentCategory == $cat['id']) ? 'active' : '' ?>">
                                <?= e($cat['name']) ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Posts -->
            <div class="col-lg-9">
                <div class="row g-4">
                    <?php foreach ($posts as $post): ?>
                    <div class="col-md-6">
                        <a href="<?= BASE_URL ?>/blog/<?= $post['slug'] ?>" class="text-decoration-none">
                            <div class="card blog-card border-0 shadow-sm h-100 hover-lift">
                                <?php if ($post['featured_image']): ?>
                                    <img src="<?= e($post['featured_image']) ?>" class="card-img-top" alt="" style="height: 200px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="bg-primary bg-opacity-10 d-flex align-items-center justify-content-center" style="height: 200px;">
                                        <i class="bi bi-newspaper text-primary fs-1"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="card-body p-3">
                                    <span class="badge bg-primary bg-opacity-10 text-primary mb-2"><?= e($post['category_name'] ?? 'Article') ?></span>
                                    <h5 class="fw-bold text-body mb-2"><?= e($post['title']) ?></h5>
                                    <p class="text-muted small"><?= e(truncate($post['excerpt'] ?? $post['content'], 120)) ?></p>
                                    <div class="d-flex justify-content-between align-items-center text-muted small">
                                        <span><i class="bi bi-person me-1"></i><?= e($post['author_name'] ?? 'ALOG Team') ?></span>
                                        <span><i class="bi bi-eye me-1"></i><?= $post['views_count'] ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>

                <?php if (empty($posts)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-inbox fs-1 text-muted"></i>
                    <p class="text-muted mt-3">Aucun article pour le moment.</p>
                </div>
                <?php endif; ?>

                <?php if ($pagination['total_pages'] > 1): ?>
                    <div class="mt-4">
                        <?= pagination_links($pagination, BASE_URL . '/blog') ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

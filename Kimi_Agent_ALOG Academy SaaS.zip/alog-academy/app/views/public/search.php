<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="fw-bold">Recherche</h1>
            <p class="text-muted">Résultats pour: <strong>"<?= e($query) ?>"</strong></p>
        </div>

        <?php if (strlen($query) < 2): ?>
            <div class="alert alert-info text-center">
                <i class="bi bi-info-circle me-2"></i>Veuillez entrer au moins 2 caractères pour la recherche.
            </div>
        <?php else: ?>
            <!-- Lessons -->
            <?php if (!empty($results['lessons'])): ?>
            <h4 class="fw-bold mb-3"><i class="bi bi-book text-primary me-2"></i>Leçons</h4>
            <div class="row g-3 mb-5">
                <?php foreach ($results['lessons'] as $lesson): ?>
                <div class="col-md-6 col-lg-4">
                    <a href="<?= BASE_URL ?>/lesson/<?= $lesson['slug'] ?>" class="text-decoration-none">
                        <div class="card border-0 shadow-sm hover-lift">
                            <div class="card-body p-3">
                                <small class="text-muted"><?= e($lesson['level_name']) ?> > <?= e($lesson['subject_name']) ?></small>
                                <h6 class="fw-bold text-body mb-1"><?= e($lesson['title']) ?></h6>
                                <p class="text-muted small mb-0"><?= e(truncate($lesson['description'] ?? '', 80)) ?></p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Blog -->
            <?php if (!empty($results['blog'])): ?>
            <h4 class="fw-bold mb-3"><i class="bi bi-newspaper text-info me-2"></i>Articles</h4>
            <div class="row g-3">
                <?php foreach ($results['blog'] as $post): ?>
                <div class="col-md-6 col-lg-4">
                    <a href="<?= BASE_URL ?>/blog/<?= $post['slug'] ?>" class="text-decoration-none">
                        <div class="card border-0 shadow-sm hover-lift">
                            <div class="card-body p-3">
                                <small class="text-info"><?= e($post['category_name'] ?? 'Blog') ?></small>
                                <h6 class="fw-bold text-body mb-1"><?= e($post['title']) ?></h6>
                                <p class="text-muted small mb-0"><?= e(truncate($post['excerpt'] ?? $post['content'], 80)) ?></p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if (empty($results['lessons']) && empty($results['blog'])): ?>
            <div class="text-center py-5">
                <i class="bi bi-search fs-1 text-muted"></i>
                <p class="text-muted mt-3">Aucun résultat trouvé pour "<?= e($query) ?>".</p>
                <a href="<?= BASE_URL ?>/levels" class="btn btn-primary">Explorer les cours</a>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

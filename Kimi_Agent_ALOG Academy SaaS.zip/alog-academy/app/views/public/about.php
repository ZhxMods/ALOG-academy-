<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center mb-5">
                <h1 class="fw-bold display-5">À propos d'<span class="text-primary">ALOG Academy</span></h1>
                <p class="lead text-muted">La plateforme éducative qui révolutionne l'apprentissage au Maroc</p>
            </div>
        </div>

        <div class="row g-4 mb-5">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <h4 class="fw-bold mb-3"><i class="bi bi-bullseye text-primary me-2"></i>Notre mission</h4>
                        <p class="text-muted">ALOG Academy a été créée pour offrir aux étudiants marocains un accès gratuit et premium à des ressources éducatives de qualité. Notre mission est de démocratiser l'éducation et de rendre l'apprentissage amusant grâce à la gamification.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <h4 class="fw-bold mb-3"><i class="bi bi-eye text-success me-2"></i>Notre vision</h4>
                        <p class="text-muted">Nous visions un Maroc où chaque étudiant, quel que soit son lieu de résidence ou sa situation financière, a accès à une éducation de qualité. Nous croyons que la technologie peut transformer l'apprentissage.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mb-5">
            <div class="col-md-3 text-center">
                <div class="p-4">
                    <i class="bi bi-mortarboard-fill text-primary fs-1 mb-3"></i>
                    <h3 class="fw-bold">5</h3>
                    <p class="text-muted">Niveaux couverts</p>
                </div>
            </div>
            <div class="col-md-3 text-center">
                <div class="p-4">
                    <i class="bi bi-book text-success fs-1 mb-3"></i>
                    <h3 class="fw-bold">100+</h3>
                    <p class="text-muted">Leçons disponibles</p>
                </div>
            </div>
            <div class="col-md-3 text-center">
                <div class="p-4">
                    <i class="bi bi-question-circle text-warning fs-1 mb-3"></i>
                    <h3 class="fw-bold">500+</h3>
                    <p class="text-muted">Questions de quiz</p>
                </div>
            </div>
            <div class="col-md-3 text-center">
                <div class="p-4">
                    <i class="bi bi-people text-info fs-1 mb-3"></i>
                    <h3 class="fw-bold">1000+</h3>
                    <p class="text-muted">Étudiants inscrits</p>
                </div>
            </div>
        </div>

        <div class="text-center">
            <h3 class="fw-bold mb-4">Comment ça marche ?</h3>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="step-card p-4">
                        <div class="step-number">1</div>
                        <h5 class="fw-bold mt-3">Créez un compte</h5>
                        <p class="text-muted">Inscrivez-vous gratuitement en quelques secondes.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="step-card p-4">
                        <div class="step-number">2</div>
                        <h5 class="fw-bold mt-3">Suivez des cours</h5>
                        <p class="text-muted">Choisissez votre niveau et matière, puis apprenez.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="step-card p-4">
                        <div class="step-number">3</div>
                        <h5 class="fw-bold mt-3">Gagnez des récompenses</h5>
                        <p class="text-muted">Accumulez des XP, montez de niveau et décrochez des badges.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center mb-5">
                <h1 class="fw-bold display-5">Contactez-<span class="text-primary">nous</span></h1>
                <p class="lead text-muted">Une question ? Un problème ? Nous sommes là pour vous aider.</p>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-4">Informations de contact</h5>
                        <div class="mb-4">
                            <i class="bi bi-envelope-fill text-primary me-2"></i>
                            <strong>Email</strong><br>
                            <a href="mailto:contact@alogacademy.ma" class="text-decoration-none">contact@alogacademy.ma</a>
                        </div>
                        <div class="mb-4">
                            <i class="bi bi-telephone-fill text-success me-2"></i>
                            <strong>Téléphone / WhatsApp</strong><br>
                            <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>" target="_blank" class="text-decoration-none"><?= WHATSAPP_NUMBER ?></a>
                        </div>
                        <div class="mb-4">
                            <i class="bi bi-geo-alt-fill text-danger me-2"></i>
                            <strong>Adresse</strong><br>
                            <span class="text-muted">Maroc</span>
                        </div>
                        <hr>
                        <h6 class="fw-bold mb-3">Réseaux sociaux</h6>
                        <div class="d-flex gap-2">
                            <a href="#" class="btn btn-outline-primary btn-sm"><i class="bi bi-facebook"></i></a>
                            <a href="#" class="btn btn-outline-danger btn-sm"><i class="bi bi-instagram"></i></a>
                            <a href="#" class="btn btn-outline-info btn-sm"><i class="bi bi-telegram"></i></a>
                            <a href="#" class="btn btn-outline-success btn-sm"><i class="bi bi-whatsapp"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-4">Envoyez-nous un message</h5>
                        <form action="<?= BASE_URL ?>/contact" method="POST">
                            <?= csrf_field() ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Nom</label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Sujet</label>
                                <input type="text" name="subject" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Message</label>
                                <textarea name="message" class="form-control" rows="5" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-send me-1"></i>Envoyer
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

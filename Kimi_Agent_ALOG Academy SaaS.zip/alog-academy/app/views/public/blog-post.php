<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <nav aria-label="breadcrumb" class="mb-3">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/">Accueil</a></li>
                        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/blog">Blog</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= e(truncate($post['title'], 40)) ?></li>
                    </ol>
                </nav>

                <span class="badge bg-primary bg-opacity-10 text-primary mb-3"><?= e($post['category_name'] ?? 'Article') ?></span>
                <h1 class="fw-bold mb-3"><?= e($post['title']) ?></h1>

                <div class="d-flex align-items-center text-muted mb-4">
                    <span class="me-3"><i class="bi bi-person me-1"></i><?= e($post['author_name'] ?? 'ALOG Team') ?></span>
                    <span class="me-3"><i class="bi bi-calendar me-1"></i><?= format_date($post['published_at'] ?? $post['created_at'], 'd/m/Y') ?></span>
                    <span><i class="bi bi-eye me-1"></i><?= $post['views_count'] ?> vues</span>
                </div>

                <?php if ($post['featured_image']): ?>
                <img src="<?= e($post['featured_image']) ?>" class="img-fluid rounded-3 mb-4 w-100" alt="" style="max-height: 400px; object-fit: cover;">
                <?php endif; ?>

                <div class="blog-content">
                    <?= nl2br(e($post['content'])) ?>
                </div>

                <hr class="my-5">

                <!-- Share -->
                <div class="d-flex justify-content-between align-items-center mb-5">
                    <span class="fw-semibold">Partager:</span>
                    <div>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(current_url()) ?>" target="_blank" class="btn btn-outline-primary btn-sm me-1"><i class="bi bi-facebook"></i></a>
                        <a href="https://twitter.com/intent/tweet?url=<?= urlencode(current_url()) ?>" target="_blank" class="btn btn-outline-info btn-sm me-1"><i class="bi bi-twitter-x"></i></a>
                        <a href="https://wa.me/?text=<?= urlencode($post['title'] . ' - ' . current_url()) ?>" target="_blank" class="btn btn-outline-success btn-sm"><i class="bi bi-whatsapp"></i></a>
                    </div>
                </div>

                <!-- Related -->
                <?php if (!empty($related)): ?>
                <h4 class="fw-bold mb-4">Articles similaires</h4>
                <div class="row g-3">
                    <?php foreach ($related as $r): ?>
                    <div class="col-md-4">
                        <a href="<?= BASE_URL ?>/blog/<?= $r['slug'] ?>" class="text-decoration-none">
                            <div class="card border-0 shadow-sm hover-lift">
                                <div class="card-body p-3">
                                    <small class="text-primary"><?= e($r['category_name'] ?? '') ?></small>
                                    <h6 class="fw-bold text-body mb-0 mt-1"><?= e(truncate($r['title'], 50)) ?></h6>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

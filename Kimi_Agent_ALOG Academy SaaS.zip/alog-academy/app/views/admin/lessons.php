<div class="dashboard-header mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1"><i class="bi bi-book text-primary me-2"></i>Leçons</h2>
        <p class="text-muted mb-0">Gérez les leçons de la plateforme</p>
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createLessonModal">
        <i class="bi bi-plus-lg me-1"></i>Nouvelle leçon
    </button>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Titre</th>
                        <th>Matière</th>
                        <th>Niveau</th>
                        <th>Accès</th>
                        <th>XP</th>
                        <th>Vues</th>
                        <th>Statut</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($lessons as $lesson): ?>
                    <tr>
                        <td><strong><?= e(truncate($lesson['title'], 40)) ?></strong></td>
                        <td><?= e($lesson['subject_name']) ?></td>
                        <td><?= e($lesson['level_name']) ?></td>
                        <td><span class="badge bg-<?= $lesson['access_type'] === 'FREE' ? 'success' : ($lesson['access_type'] === 'PRO' ? 'primary' : 'warning text-dark') ?>"><?= $lesson['access_type'] ?></span></td>
                        <td><?= $lesson['xp_reward'] ?></td>
                        <td><?= number_format($lesson['views_count']) ?></td>
                        <td><?= $lesson['is_active'] ? '<span class="badge bg-success">Actif</span>' : '<span class="badge bg-secondary">Inactif</span>' ?></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editLesson<?= $lesson['id'] ?>"><i class="bi bi-pencil"></i></button>
                            <form action="<?= BASE_URL ?>/admin/lessons/<?= $lesson['id'] ?>/delete" method="POST" class="d-inline" onsubmit="return confirm('Supprimer cette leçon ?')">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($pagination['total_pages'] > 1): ?>
    <div class="mt-3"><?= pagination_links($pagination, BASE_URL . '/admin/lessons') ?></div>
<?php endif; ?>

<!-- Create Modal -->
<div class="modal fade" id="createLessonModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Nouvelle leçon</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?= BASE_URL ?>/admin/lessons/create" method="POST">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Niveau</label>
                            <select name="level_id" class="form-select" required>
                                <?php foreach ($levels as $l): ?><option value="<?= $l['id'] ?>"><?= e($l['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Matière</label>
                            <select name="subject_id" class="form-select" required>
                                <?php foreach ($subjects as $s): ?><option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12"><label class="form-label">Titre</label><input type="text" name="title" class="form-control" required></div>
                        <div class="col-12"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
                        <div class="col-12"><label class="form-label">Contenu</label><textarea name="content" class="form-control" rows="4"></textarea></div>
                        <div class="col-md-6"><label class="form-label">YouTube URL</label><input type="url" name="youtube_url" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">PDF URL</label><input type="url" name="pdf_url" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label">XP</label><input type="number" name="xp_reward" class="form-control" value="10"></div>
                        <div class="col-md-4"><label class="form-label">Accès</label>
                            <select name="access_type" class="form-select"><option value="FREE">FREE</option><option value="PRO">PRO</option><option value="ULTRA">ULTRA</option><option value="XP">XP</option></select>
                        </div>
                        <div class="col-md-4"><label class="form-label">Durée (min)</label><input type="number" name="duration_minutes" class="form-control" value="0"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Créer</button>
                </div>
            </form>
        </div>
    </div>
</div>

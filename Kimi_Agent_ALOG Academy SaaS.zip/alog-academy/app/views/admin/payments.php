<div class="dashboard-header mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1"><i class="bi bi-credit-card text-warning me-2"></i>Paiements</h2>
        <p class="text-muted mb-0">Validation des paiements manuels</p>
    </div>
    <div class="d-flex gap-2">
        <span class="badge bg-warning"><?= $stats['pending'] ?> en attente</span>
        <span class="badge bg-success"><?= $stats['approved'] ?> approuvés</span>
        <span class="badge bg-danger"><?= $stats['rejected'] ?> rejetés</span>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Étudiant</th>
                        <th>Plan</th>
                        <th>Montant</th>
                        <th>WhatsApp</th>
                        <th>Preuve</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payments as $payment): ?>
                    <tr>
                        <td><?= format_date($payment['created_at']) ?></td>
                        <td><strong><?= e($payment['fullname']) ?></strong><br><small class="text-muted"><?= e($payment['email']) ?></small></td>
                        <td><span class="badge bg-<?= plan_color($payment['plan']) ?>"><?= plan_label($payment['plan']) ?></span></td>
                        <td class="fw-bold"><?= $payment['amount'] ?> MAD</td>
                        <td><a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $payment['whatsapp_number'] ?? '') ?>" target="_blank" class="text-decoration-none"><i class="bi bi-whatsapp text-success"></i> <?= e($payment['whatsapp_number'] ?? '') ?></a></td>
                        <td>
                            <?php if ($payment['proof_image']): ?>
                            <a href="<?= upload_url($payment['proof_image']) ?>" target="_blank" class="btn btn-sm btn-outline-info"><i class="bi bi-image"></i></a>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td><?= payment_status_badge($payment['status']) ?></td>
                        <td>
                            <?php if ($payment['status'] === 'pending'): ?>
                            <form action="<?= BASE_URL ?>/admin/payments/<?= $payment['id'] ?>/approve" method="POST" class="d-inline">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-success"><i class="bi bi-check-lg"></i></button>
                            </form>
                            <form action="<?= BASE_URL ?>/admin/payments/<?= $payment['id'] ?>/reject" method="POST" class="d-inline">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="bi bi-x-lg"></i></button>
                            </form>
                            <?php else: ?>
                            <small class="text-muted">Par <?= e($payment['validator_name'] ?? 'Admin') ?></small>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($pagination['total_pages'] > 1): ?>
    <div class="mt-3"><?= pagination_links($pagination, BASE_URL . '/admin/payments') ?></div>
<?php endif; ?>

<div class="dashboard-header mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1"><i class="bi bi-people text-primary me-2"></i>Utilisateurs</h2>
        <p class="text-muted mb-0"><?= $pagination['total'] ?> étudiants inscrits</p>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Nom</th>
                        <th>Email</th>
                        <th>Plan</th>
                        <th>XP</th>
                        <th>Niv.</th>
                        <th>Région</th>
                        <th>Statut</th>
                        <th>Inscription</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><strong><?= e($user['fullname']) ?></strong></td>
                        <td><?= e($user['email']) ?></td>
                        <td><span class="badge bg-<?= plan_color($user['plan']) ?>"><?= plan_label($user['plan']) ?></span></td>
                        <td><?= format_xp($user['xp_total']) ?></td>
                        <td><?= $user['level'] ?></td>
                        <td><?= e(ucfirst(str_replace('-', ' ', $user['region'] ?? ''))) ?></td>
                        <td>
                            <?php if ($user['status'] === 'active'): ?>
                                <span class="badge bg-success">Actif</span>
                            <?php else: ?>
                                <span class="badge bg-danger"><?= e($user['status']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?= format_date($user['created_at'], 'd/m/Y') ?></td>
                        <td>
                            <a href="<?= BASE_URL ?>/admin/users/<?= $user['id'] ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($pagination['total_pages'] > 1): ?>
    <div class="mt-3"><?= pagination_links($pagination, BASE_URL . '/admin/users') ?></div>
<?php endif; ?>

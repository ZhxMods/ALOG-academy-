<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-gear text-primary me-2"></i>Paramètres</h2>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <form action="<?= BASE_URL ?>/admin/settings/update" method="POST">
            <?= csrf_field() ?>
            <?php
            $grouped = [];
            foreach ($settings as $s) {
                $grouped[$s['setting_group']][] = $s;
            }
            ?>
            <?php foreach ($grouped as $group => $items): ?>
            <h5 class="fw-bold mb-3 text-capitalize"><?= e($group) ?></h5>
            <div class="row g-3 mb-4">
                <?php foreach ($items as $item): ?>
                <div class="col-md-6">
                    <label class="form-label"><?= e(str_replace('_', ' ', $item['setting_key'])) ?></label>
                    <input type="text" name="settings[<?= $item['setting_key'] ?>]" class="form-control" value="<?= e($item['setting_value'] ?? '') ?>">
                </div>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-check-lg me-1"></i>Enregistrer
            </button>
        </form>
    </div>
</div>

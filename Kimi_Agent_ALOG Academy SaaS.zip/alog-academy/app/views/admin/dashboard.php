<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-speedometer2 text-primary me-2"></i>Dashboard Admin</h2>
    <p class="text-muted mb-0">Vue d'ensemble de la plateforme</p>
</div>

<!-- Stats Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-0 shadow-sm border-start border-4 border-primary">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-primary bg-opacity-10 text-primary"><i class="bi bi-people"></i></div>
                <div class="ms-3"><h4 class="fw-bold mb-0"><?= number_format($stats['total_students']) ?></h4><small class="text-muted">Étudiants</small></div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-0 shadow-sm border-start border-4 border-success">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-success bg-opacity-10 text-success"><i class="bi bi-person-check"></i></div>
                <div class="ms-3"><h4 class="fw-bold mb-0"><?= number_format($stats['active_today']) ?></h4><small class="text-muted">Actifs aujourd'hui</small></div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-0 shadow-sm border-start border-4 border-warning">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-warning bg-opacity-10 text-warning"><i class="bi bi-credit-card"></i></div>
                <div class="ms-3"><h4 class="fw-bold mb-0"><?= number_format($stats['total_revenue'], 2) ?> MAD</h4><small class="text-muted">Revenus</small></div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card stat-card border-0 shadow-sm border-start border-4 border-danger">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-danger bg-opacity-10 text-danger"><i class="bi bi-book"></i></div>
                <div class="ms-3"><h4 class="fw-bold mb-0"><?= number_format($stats['total_lessons']) ?></h4><small class="text-muted">Leçons</small></div>
            </div>
        </div>
    </div>
</div>

<!-- Pending Items -->
<div class="row g-3 mb-4">
    <div class="col-md-6">
        <a href="<?= BASE_URL ?>/admin/payments" class="text-decoration-none">
            <div class="card border-0 shadow-sm bg-warning bg-opacity-10">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div><i class="bi bi-credit-card fs-3 text-warning"></i><h5 class="fw-bold mb-0 mt-2"><?= $stats['pending_payments'] ?> paiements en attente</h5></div>
                    <i class="bi bi-arrow-right fs-4 text-warning"></i>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6">
        <a href="<?= BASE_URL ?>/admin/bookings" class="text-decoration-none">
            <div class="card border-0 shadow-sm bg-info bg-opacity-10">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div><i class="bi bi-calendar-check fs-3 text-info"></i><h5 class="fw-bold mb-0 mt-2"><?= $stats['pending_bookings'] ?> réservations en attente</h5></div>
                    <i class="bi bi-arrow-right fs-4 text-info"></i>
                </div>
            </div>
        </a>
    </div>
</div>

<div class="row g-4">
    <!-- Chart: Signups -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3">Inscriptions (7 derniers jours)</h5>
                <canvas id="signupsChart" height="200"></canvas>
            </div>
        </div>
    </div>
    <!-- Recent Activity -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3">Activité récente</h5>
                <?php if (empty($recentActivities)): ?>
                    <p class="text-muted">Aucune activité récente</p>
                <?php else: ?>
                    <?php foreach (array_slice($recentActivities, 0, 8) as $act): ?>
                    <div class="d-flex align-items-center py-2 border-bottom">
                        <span class="badge bg-primary bg-opacity-10 text-primary me-2">XP</span>
                        <div class="flex-grow-1 small"><?= e($act['fullname'] ?? '') ?></div>
                        <small class="text-muted"><?= time_ago($act['created_at']) ?></small>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
const signupsCtx = document.getElementById('signupsChart').getContext('2d');
new Chart(signupsCtx, {
    type: 'line',
    data: {
        labels: <?= json_encode(array_column($dailySignups, 'date')) ?>,
        datasets: [{
            label: 'Inscriptions',
            data: <?= json_encode(array_map('intval', array_column($dailySignups, 'count'))) ?>,
            backgroundColor: 'rgba(13, 110, 253, 0.1)',
            borderColor: '#0d6efd',
            borderWidth: 2,
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
    }
});
</script>

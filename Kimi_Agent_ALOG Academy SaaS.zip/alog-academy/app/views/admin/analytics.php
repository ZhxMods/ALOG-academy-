<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-graph-up text-primary me-2"></i>Analytics</h2>
</div>

<div class="row g-4">
    <!-- Subscriptions by Plan -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3">Abonnements par plan</h5>
                <canvas id="plansChart" height="200"></canvas>
            </div>
        </div>
    </div>

    <!-- Revenue -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3">Revenus mensuels</h5>
                <canvas id="revenueChart" height="200"></canvas>
            </div>
        </div>
    </div>

    <!-- Top Lessons -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3">Leçons les plus vues</h5>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead><tr><th>Leçon</th><th>Vues</th><th>Complétions</th></tr></thead>
                        <tbody>
                            <?php foreach ($stats['top_lessons'] as $lesson): ?>
                            <tr><td><?= e(truncate($lesson['title'], 40)) ?></td><td><?= number_format($lesson['views_count']) ?></td><td><?= number_format($lesson['completions_count']) ?></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Top Students -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3">Top étudiants</h5>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead><tr><th>Étudiant</th><th>XP</th><th>Niveau</th></tr></thead>
                        <tbody>
                            <?php foreach ($stats['top_students'] as $student): ?>
                            <tr><td><?= e($student['fullname']) ?></td><td><?= format_xp($student['xp_total']) ?></td><td><?= $student['level'] ?></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
new Chart(document.getElementById('plansChart').getContext('2d'), {
    type: 'doughnut',
    data: {
        labels: <?= json_encode(array_column($stats['subscriptions_by_plan'], 'plan')) ?>,
        datasets: [{
            data: <?= json_encode(array_map('intval', array_column($stats['subscriptions_by_plan'], 'count'))) ?>,
            backgroundColor: ['#6c757d', '#0d6efd', '#ffc107']
        }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});

new Chart(document.getElementById('revenueChart').getContext('2d'), {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($stats['revenue_by_month'], 'month')) ?>,
        datasets: [{
            label: 'Revenus (MAD)',
            data: <?= json_encode(array_map('floatval', array_column($stats['revenue_by_month'], 'total'))) ?>,
            backgroundColor: 'rgba(25, 135, 84, 0.7)'
        }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
});
</script>

<div class="dashboard-header mb-4">
    <h2 class="fw-bold mb-1"><i class="bi bi-calendar-check text-info me-2"></i>Réservations</h2>
    <p class="text-muted mb-0">Gérez les demandes de soutien et coaching</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Étudiant</th>
                        <th>Type</th>
                        <th>Sujet</th>
                        <th>Date préférée</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $booking): ?>
                    <tr>
                        <td><?= format_date($booking['created_at']) ?></td>
                        <td><strong><?= e($booking['fullname']) ?></strong><br><small class="text-muted"><?= e($booking['email']) ?></small></td>
                        <td><span class="badge bg-<?= $booking['booking_type'] === 'coaching' ? 'info' : 'primary' ?>"><?= $booking['booking_type'] === 'coaching' ? 'Coaching' : 'Soutien' ?></span></td>
                        <td><?= e($booking['subject']) ?></td>
                        <td><?= $booking['preferred_date'] ? format_date($booking['preferred_date'], 'd/m/Y') . ' ' . ($booking['preferred_time'] ?? '') : '-' ?></td>
                        <td>
                            <?= match($booking['status']) {
                                'pending' => '<span class="badge bg-warning">En attente</span>',
                                'approved' => '<span class="badge bg-success">Approuvé</span>',
                                'rejected' => '<span class="badge bg-danger">Rejeté</span>',
                                'completed' => '<span class="badge bg-info">Terminé</span>',
                                default => '<span class="badge bg-secondary">' . e($booking['status']) . '</span>',
                            } ?>
                        </td>
                        <td>
                            <?php if ($booking['status'] === 'pending'): ?>
                            <form action="<?= BASE_URL ?>/admin/bookings/<?= $booking['id'] ?>/approve" method="POST" class="d-inline">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-success" title="Approuver"><i class="bi bi-check-lg"></i></button>
                            </form>
                            <form action="<?= BASE_URL ?>/admin/bookings/<?= $booking['id'] ?>/reject" method="POST" class="d-inline">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-danger" title="Rejeter"><i class="bi bi-x-lg"></i></button>
                            </form>
                            <?php elseif ($booking['status'] === 'approved'): ?>
                            <form action="<?= BASE_URL ?>/admin/bookings/<?= $booking['id'] ?>/complete" method="POST" class="d-inline">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-info" title="Marquer terminé"><i class="bi bi-check-all"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($pagination['total_pages'] > 1): ?>
    <div class="mt-3"><?= pagination_links($pagination, BASE_URL . '/admin/bookings') ?></div>
<?php endif; ?>

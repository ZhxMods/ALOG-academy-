<div class="card auth-card border-0 shadow">
    <div class="card-body p-4 p-md-5">
        <div class="text-center mb-4">
            <div class="icon-circle bg-primary bg-opacity-10 text-primary mx-auto mb-3">
                <i class="bi bi-key fs-2"></i>
            </div>
            <h3 class="fw-bold mb-1">Mot de passe oublié ?</h3>
            <p class="text-muted">Entrez votre email et nous vous enverrons un lien de réinitialisation.</p>
        </div>

        <form action="<?= BASE_URL ?>/forgot-password" method="POST">
            <?= csrf_field() ?>

            <div class="mb-4">
                <label class="form-label">Adresse email</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="email" class="form-control" placeholder="votre@email.com" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                <i class="bi bi-send me-2"></i>Envoyer le lien
            </button>
        </form>

        <div class="text-center mt-4">
            <a href="<?= BASE_URL ?>/login" class="text-decoration-none"><i class="bi bi-arrow-left me-1"></i>Retour à la connexion</a>
        </div>
    </div>
</div>

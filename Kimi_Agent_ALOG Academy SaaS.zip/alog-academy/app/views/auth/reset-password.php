<div class="card auth-card border-0 shadow">
    <div class="card-body p-4 p-md-5">
        <div class="text-center mb-4">
            <div class="icon-circle bg-success bg-opacity-10 text-success mx-auto mb-3">
                <i class="bi bi-shield-check fs-2"></i>
            </div>
            <h3 class="fw-bold mb-1">Nouveau mot de passe</h3>
            <p class="text-muted">Choisissez un nouveau mot de passe sécurisé.</p>
        </div>

        <form action="<?= BASE_URL ?>/reset-password" method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="token" value="<?= e($token) ?>">

            <div class="mb-3">
                <label class="form-label">Nouveau mot de passe</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Min. 6 caractères" required>
                    <button class="btn btn-outline-secondary toggle-password" type="button"><i class="bi bi-eye"></i></button>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label">Confirmer le mot de passe</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                    <input type="password" name="password_confirm" class="form-control" placeholder="Répétez le mot de passe" required>
                </div>
            </div>

            <button type="submit" class="btn btn-success w-100 py-2 fw-semibold">
                <i class="bi bi-check-lg me-2"></i>Réinitialiser le mot de passe
            </button>
        </form>
    </div>
</div>

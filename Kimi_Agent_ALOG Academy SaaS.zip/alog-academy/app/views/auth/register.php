<div class="card auth-card border-0 shadow">
    <div class="card-body p-4 p-md-5">
        <h3 class="fw-bold mb-1">Créer un compte</h3>
        <p class="text-muted mb-4">Rejoignez ALOG Academy et commencez votre parcours !</p>

        <form action="<?= BASE_URL ?>/register" method="POST">
            <?= csrf_field() ?>

            <div class="mb-3">
                <label class="form-label">Nom complet</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-person"></i></span>
                    <input type="text" name="fullname" class="form-control <?= isset($errors['fullname']) ? 'is-invalid' : '' ?>"
                           value="<?= old('fullname') ?>" placeholder="Votre nom complet" required>
                </div>
                <?php if (isset($errors['fullname'])): ?>
                    <div class="invalid-feedback d-block"><?= $errors['fullname'] ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Adresse email</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>"
                           value="<?= old('email') ?>" placeholder="votre@email.com" required>
                </div>
                <?php if (isset($errors['email'])): ?>
                    <div class="invalid-feedback d-block"><?= $errors['email'] ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Région</label>
                <select name="region" class="form-select">
                    <option value="">-- Sélectionnez --</option>
                    <option value="casablanca-settat" <?= old('region') === 'casablanca-settat' ? 'selected' : '' ?>>Casablanca-Settat</option>
                    <option value="rabat-sale-kenitra" <?= old('region') === 'rabat-sale-kenitra' ? 'selected' : '' ?>>Rabat-Salé-Kénitra</option>
                    <option value="marrakech-safi" <?= old('region') === 'marrakech-safi' ? 'selected' : '' ?>>Marrakech-Safi</option>
                    <option value="tanger-tetouan-al-hoceima" <?= old('region') === 'tanger-tetouan-al-hoceima' ? 'selected' : '' ?>>Tanger-Tétouan-Al Hoceïma</option>
                    <option value="fes-meknes" <?= old('region') === 'fes-meknes' ? 'selected' : '' ?>>Fès-Meknès</option>
                    <option value="oriental" <?= old('region') === 'oriental' ? 'selected' : '' ?>>L'Oriental</option>
                    <option value="beni-mellal-khenifra" <?= old('region') === 'beni-mellal-khenifra' ? 'selected' : '' ?>>Béni Mellal-Khénifra</option>
                    <option value="draa-tafilalet" <?= old('region') === 'draa-tafilalet' ? 'selected' : '' ?>>Drâa-Tafilalet</option>
                    <option value="souss-massa" <?= old('region') === 'souss-massa' ? 'selected' : '' ?>>Souss-Massa</option>
                    <option value="guelmim-oued-noun" <?= old('region') === 'guelmim-oued-noun' ? 'selected' : '' ?>>Guelmim-Oued Noun</option>
                    <option value="laayoune-sakia-el-hamra" <?= old('region') === 'laayoune-sakia-el-hamra' ? 'selected' : '' ?>>Laâyoune-Sakia El Hamra</option>
                    <option value="dakhla-oued-ed-dahab" <?= old('region') === 'dakhla-oued-ed-dahab' ? 'selected' : '' ?>>Dakhla-Oued Ed-Dahab</option>
                    <option value="autre" <?= old('region') === 'autre' ? 'selected' : '' ?>>Autre</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Mot de passe</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>"
                           placeholder="Min. 6 caractères" required>
                    <button class="btn btn-outline-secondary toggle-password" type="button"><i class="bi bi-eye"></i></button>
                </div>
                <?php if (isset($errors['password'])): ?>
                    <div class="invalid-feedback d-block"><?= $errors['password'] ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-4">
                <label class="form-label">Confirmer le mot de passe</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                    <input type="password" name="password_confirm" class="form-control <?= isset($errors['password_confirm']) ? 'is-invalid' : '' ?>"
                           placeholder="Répétez le mot de passe" required>
                </div>
                <?php if (isset($errors['password_confirm'])): ?>
                    <div class="invalid-feedback d-block"><?= $errors['password_confirm'] ?></div>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                <i class="bi bi-person-plus me-2"></i>S'inscrire
            </button>
        </form>

        <div class="text-center mt-4">
            <p class="text-muted mb-0">Déjà un compte ? <a href="<?= BASE_URL ?>/login" class="text-decoration-none fw-semibold">Se connecter</a></p>
        </div>
    </div>
</div>

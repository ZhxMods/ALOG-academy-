<div class="card auth-card border-0 shadow">
    <div class="card-body p-4 p-md-5">
        <h3 class="fw-bold mb-1">Connexion</h3>
        <p class="text-muted mb-4">Content de vous revoir ! Connectez-vous pour continuer.</p>

        <form action="<?= BASE_URL ?>/login" method="POST">
            <?= csrf_field() ?>

            <div class="mb-3">
                <label class="form-label">Adresse email</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>"
                           value="<?= old('email') ?>" placeholder="votre@email.com" required>
                </div>
                <?php if (isset($errors['email'])): ?>
                    <div class="invalid-feedback d-block"><?= $errors['email'] ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Mot de passe</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>"
                           placeholder="Votre mot de passe" required>
                    <button class="btn btn-outline-secondary toggle-password" type="button"><i class="bi bi-eye"></i></button>
                </div>
                <?php if (isset($errors['password'])): ?>
                    <div class="invalid-feedback d-block"><?= $errors['password'] ?></div>
                <?php endif; ?>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="remember_me" id="remember">
                    <label class="form-check-label" for="remember">Se souvenir de moi</label>
                </div>
                <a href="<?= BASE_URL ?>/forgot-password" class="text-decoration-none">Mot de passe oublié ?</a>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                <i class="bi bi-box-arrow-in-right me-2"></i>Se connecter
            </button>
        </form>

        <div class="text-center mt-4">
            <p class="text-muted mb-0">Pas encore de compte ? <a href="<?= BASE_URL ?>/register" class="text-decoration-none fw-semibold">S'inscrire</a></p>
        </div>
    </div>
</div>

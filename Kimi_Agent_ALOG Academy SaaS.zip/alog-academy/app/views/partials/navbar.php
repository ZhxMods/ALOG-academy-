<?php
$user = auth();
$unreadCount = $user ? (new App\Models\Notification())->countUnread($user['id']) : 0;
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>/">
            <i class="bi bi-mortarboard-fill me-1"></i>ALOG Academy
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/">Accueil</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/levels">Cours</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/quizzes">Quiz</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/rankings">Classement</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/blog">Blog</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/pricing">Tarifs</a></li>
            </ul>

            <ul class="navbar-nav align-items-center">
                <li class="nav-item me-2">
                    <button class="btn btn-link nav-link" id="themeToggle" title="Changer le thème">
                        <i class="bi bi-sun-fill" id="themeIcon"></i>
                    </button>
                </li>

                <?php if ($user): ?>
                    <li class="nav-item dropdown me-2">
                        <a class="nav-link position-relative" href="<?= BASE_URL ?>/notifications" role="button">
                            <i class="bi bi-bell-fill"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.6rem;">
                                    <?= $unreadCount ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="dropdown">
                            <?php if (!empty($user['avatar'])): ?>
                                <img src="<?= upload_url($user['avatar']) ?>" class="rounded-circle me-2" width="28" height="28" alt="">
                            <?php else: ?>
                                <div class="avatar-circle-sm me-2 bg-<?= plan_color($user['plan'] ?? 'FREE') ?>">
                                    <?= strtoupper(substr($user['fullname'], 0, 1)) ?>
                                </div>
                            <?php endif; ?>
                            <span class="d-none d-lg-inline"><?= e($user['fullname']) ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/dashboard"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/profile"><i class="bi bi-person me-2"></i>Profil</a></li>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/subscriptions"><i class="bi bi-credit-card me-2"></i>Abonnements</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <?php if (is_admin()): ?>
                                <li><a class="dropdown-item" href="<?= BASE_URL ?>/admin/dashboard"><i class="bi bi-shield-lock me-2"></i>Admin</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/logout"><i class="bi bi-box-arrow-right me-2"></i>Déconnexion</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item"><a class="btn btn-outline-light btn-sm me-2" href="<?= BASE_URL ?>/login">Connexion</a></li>
                    <li class="nav-item"><a class="btn btn-warning btn-sm" href="<?= BASE_URL ?>/register">Inscription</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

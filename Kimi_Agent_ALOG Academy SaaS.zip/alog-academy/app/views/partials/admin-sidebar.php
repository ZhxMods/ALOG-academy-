<?php
$currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '';
$currentPath = str_replace(dirname($_SERVER['SCRIPT_NAME']) ?: '', '', $currentPath);
$currentPath = preg_replace('#^/public#', '', $currentPath);
$currentPath = $currentPath ?: '/';

function adminActive(string $path, string $current): string {
    return str_starts_with($current, $path) ? 'active' : '';
}

// Stats rapides pour badges
$pendingPayments = (new App\Models\Payment())->count("status = 'pending'");
$pendingBookings = (new App\Models\Booking())->count("status = 'pending'");
?>
<aside class="dashboard-sidebar admin-sidebar" id="adminSidebar">
    <div class="sidebar-header">
        <a href="<?= BASE_URL ?>/admin/dashboard" class="sidebar-brand">
            <i class="bi bi-shield-lock"></i>
            <span>Panel Admin</span>
        </a>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section">
            <span class="nav-label">Principal</span>
            <a href="<?= BASE_URL ?>/admin/dashboard" class="nav-link <?= adminActive('/admin/dashboard', $currentPath) ?>">
                <i class="bi bi-speedometer2"></i>
                <span>Dashboard</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/analytics" class="nav-link <?= adminActive('/admin/analytics', $currentPath) ?>">
                <i class="bi bi-graph-up"></i>
                <span>Analytics</span>
            </a>
        </div>

        <div class="nav-section">
            <span class="nav-label">Contenu</span>
            <a href="<?= BASE_URL ?>/admin/levels" class="nav-link <?= adminActive('/admin/levels', $currentPath) ?>">
                <i class="bi bi-layers"></i>
                <span>Niveaux</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/subjects" class="nav-link <?= adminActive('/admin/subjects', $currentPath) ?>">
                <i class="bi bi-bookmark"></i>
                <span>Matières</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/lessons" class="nav-link <?= adminActive('/admin/lessons', $currentPath) ?>">
                <i class="bi bi-book"></i>
                <span>Leçons</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/quizzes" class="nav-link <?= adminActive('/admin/quizzes', $currentPath) ?>">
                <i class="bi bi-question-circle"></i>
                <span>Quiz</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/blog" class="nav-link <?= adminActive('/admin/blog', $currentPath) ?>">
                <i class="bi bi-newspaper"></i>
                <span>Blog</span>
            </a>
        </div>

        <div class="nav-section">
            <span class="nav-label">Gestion</span>
            <a href="<?= BASE_URL ?>/admin/users" class="nav-link <?= adminActive('/admin/users', $currentPath) ?>">
                <i class="bi bi-people"></i>
                <span>Utilisateurs</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/payments" class="nav-link <?= adminActive('/admin/payments', $currentPath) ?>">
                <i class="bi bi-credit-card"></i>
                <span>Paiements</span>
                <?php if ($pendingPayments > 0): ?>
                    <span class="badge bg-warning text-dark ms-auto"><?= $pendingPayments ?></span>
                <?php endif; ?>
            </a>
            <a href="<?= BASE_URL ?>/admin/bookings" class="nav-link <?= adminActive('/admin/bookings', $currentPath) ?>">
                <i class="bi bi-calendar-check"></i>
                <span>Réservations</span>
                <?php if ($pendingBookings > 0): ?>
                    <span class="badge bg-warning text-dark ms-auto"><?= $pendingBookings ?></span>
                <?php endif; ?>
            </a>
            <a href="<?= BASE_URL ?>/admin/rankings" class="nav-link <?= adminActive('/admin/rankings', $currentPath) ?>">
                <i class="bi bi-trophy"></i>
                <span>Classements</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/announcements" class="nav-link <?= adminActive('/admin/announcements', $currentPath) ?>">
                <i class="bi bi-megaphone"></i>
                <span>Annonces</span>
            </a>
        </div>

        <div class="nav-section">
            <span class="nav-label">Configuration</span>
            <a href="<?= BASE_URL ?>/admin/settings" class="nav-link <?= adminActive('/admin/settings', $currentPath) ?>">
                <i class="bi bi-gear"></i>
                <span>Paramètres</span>
            </a>
        </div>
    </nav>
</aside>

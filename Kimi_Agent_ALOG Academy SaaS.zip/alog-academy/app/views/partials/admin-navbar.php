<?php $user = auth(); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark admin-topbar sticky-top">
    <div class="container-fluid">
        <button class="btn btn-link text-light me-3" id="sidebarToggle">
            <i class="bi bi-list fs-5"></i>
        </button>
        <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>/admin/dashboard">
            <i class="bi bi-shield-lock me-1"></i>Admin
        </a>

        <div class="ms-auto d-flex align-items-center">
            <a href="<?= BASE_URL ?>/" class="btn btn-link text-light text-decoration-none me-3" target="_blank">
                <i class="bi bi-box-arrow-up-right me-1"></i>Site
            </a>
            <div class="dropdown">
                <a class="btn btn-link text-light text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-person-circle me-1"></i><?= e($user['fullname'] ?? 'Admin') ?>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="<?= BASE_URL ?>/profile"><i class="bi bi-person me-2"></i>Profil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/logout"><i class="bi bi-box-arrow-right me-2"></i>Déconnexion</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

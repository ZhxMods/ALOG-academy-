<?php
$user = auth();
$currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '';
$currentPath = str_replace(dirname($_SERVER['SCRIPT_NAME']) ?: '', '', $currentPath);
$currentPath = preg_replace('#^/public#', '', $currentPath);
$currentPath = $currentPath ?: '/';

function active(string $path, string $current): string {
    return str_starts_with($current, $path) ? 'active' : '';
}

$notifCount = $user ? (new App\Models\Notification())->countUnread($user['id']) : 0;
?>
<aside class="dashboard-sidebar" id="studentSidebar">
    <div class="sidebar-header">
        <a href="<?= BASE_URL ?>/dashboard" class="sidebar-brand">
            <i class="bi bi-mortarboard-fill"></i>
            <span>ALOG Academy</span>
        </a>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section">
            <span class="nav-label">Menu</span>
            <a href="<?= BASE_URL ?>/dashboard" class="nav-link <?= active('/dashboard', $currentPath) ?>">
                <i class="bi bi-speedometer2"></i>
                <span>Dashboard</span>
            </a>
            <a href="<?= BASE_URL ?>/levels" class="nav-link <?= active('/levels', $currentPath) ?> <?= active('/subjects', $currentPath) ?> <?= active('/lesson', $currentPath) ?>">
                <i class="bi bi-book"></i>
                <span>Leçons</span>
            </a>
            <a href="<?= BASE_URL ?>/quizzes" class="nav-link <?= active('/quizzes', $currentPath) ?> <?= active('/quiz', $currentPath) ?>">
                <i class="bi bi-question-circle"></i>
                <span>Quiz</span>
            </a>
            <a href="<?= BASE_URL ?>/rankings" class="nav-link <?= active('/rankings', $currentPath) ?>">
                <i class="bi bi-trophy"></i>
                <span>Classement</span>
            </a>
        </div>

        <div class="nav-section">
            <span class="nav-label">Compte</span>
            <a href="<?= BASE_URL ?>/profile" class="nav-link <?= active('/profile', $currentPath) ?>">
                <i class="bi bi-person"></i>
                <span>Profil</span>
            </a>
            <a href="<?= BASE_URL ?>/subscriptions" class="nav-link <?= active('/subscriptions', $currentPath) ?>">
                <i class="bi bi-credit-card"></i>
                <span>Abonnements</span>
                <span class="badge bg-<?= plan_color($user['plan'] ?? 'FREE') ?> ms-auto"><?= plan_label($user['plan'] ?? 'FREE') ?></span>
            </a>
            <a href="<?= BASE_URL ?>/notifications" class="nav-link <?= active('/notifications', $currentPath) ?>">
                <i class="bi bi-bell"></i>
                <span>Notifications</span>
                <?php if ($notifCount > 0): ?>
                    <span class="badge bg-danger ms-auto"><?= $notifCount ?></span>
                <?php endif; ?>
            </a>
            <a href="<?= BASE_URL ?>/bookings" class="nav-link <?= active('/bookings', $currentPath) ?>">
                <i class="bi bi-calendar-check"></i>
                <span>Réservations</span>
            </a>
            <a href="<?= BASE_URL ?>/xp-history" class="nav-link <?= active('/xp-history', $currentPath) ?>">
                <i class="bi bi-lightning"></i>
                <span>Historique XP</span>
            </a>
        </div>
    </nav>

    <div class="sidebar-footer">
        <div class="user-mini">
            <?php if (!empty($user['avatar'])): ?>
                <img src="<?= upload_url($user['avatar']) ?>" class="rounded-circle" width="32" height="32" alt="">
            <?php else: ?>
                <div class="avatar-circle-xs bg-primary"><?= strtoupper(substr($user['fullname'], 0, 1)) ?></div>
            <?php endif; ?>
            <div class="user-mini-info">
                <div class="fw-semibold small"><?= e($user['fullname']) ?></div>
                <div class="text-muted" style="font-size: 0.7rem;">Niv. <?= $user['level'] ?? 1 ?> | <?= format_xp($user['xp_total'] ?? 0) ?> XP</div>
            </div>
        </div>
    </div>
</aside>

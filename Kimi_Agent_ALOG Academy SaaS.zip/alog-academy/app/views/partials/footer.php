<footer class="site-footer">
    <div class="container">
        <div class="row gy-4">
            <div class="col-lg-4 col-md-6">
                <h5 class="fw-bold mb-3"><i class="bi bi-mortarboard-fill me-2"></i>ALOG Academy</h5>
                <p class="text-muted">Plateforme éducative gamifiée pour étudiants marocains. Apprenez en vous amusant avec des cours, des quiz et un système de récompenses.</p>
                <div class="social-links">
                    <a href="#" class="me-2"><i class="bi bi-facebook fs-5"></i></a>
                    <a href="#" class="me-2"><i class="bi bi-instagram fs-5"></i></a>
                    <a href="#" class="me-2"><i class="bi bi-youtube fs-5"></i></a>
                    <a href="#" class="me-2"><i class="bi bi-telegram fs-5"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-6">
                <h6 class="fw-bold mb-3">Liens rapides</h6>
                <ul class="list-unstyled footer-links">
                    <li><a href="<?= BASE_URL ?>/">Accueil</a></li>
                    <li><a href="<?= BASE_URL ?>/levels">Cours</a></li>
                    <li><a href="<?= BASE_URL ?>/quizzes">Quiz</a></li>
                    <li><a href="<?= BASE_URL ?>/pricing">Tarifs</a></li>
                    <li><a href="<?= BASE_URL ?>/blog">Blog</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-6">
                <h6 class="fw-bold mb-3">Support</h6>
                <ul class="list-unstyled footer-links">
                    <li><a href="<?= BASE_URL ?>/about">À propos</a></li>
                    <li><a href="<?= BASE_URL ?>/contact">Contact</a></li>
                    <li><a href="<?= BASE_URL ?>/faq">FAQ</a></li>
                    <li><a href="https://wa.me/<?= WHATSAPP_NUMBER ?>" target="_blank">WhatsApp</a></li>
                </ul>
            </div>
            <div class="col-lg-4 col-md-6">
                <h6 class="fw-bold mb-3">Contact</h6>
                <ul class="list-unstyled text-muted">
                    <li class="mb-2"><i class="bi bi-envelope me-2"></i>contact@alogacademy.ma</li>
                    <li class="mb-2"><i class="bi bi-telephone me-2"></i><?= WHATSAPP_NUMBER ?></li>
                    <li class="mb-2"><i class="bi bi-geo-alt me-2"></i>Maroc</li>
                </ul>
            </div>
        </div>
        <hr class="my-4">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0 text-muted">&copy; <?= date('Y') ?> ALOG Academy. Tous droits réservés.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <small class="text-muted">Fait avec <i class="bi bi-heart-fill text-danger"></i> au Maroc</small>
            </div>
        </div>
    </div>
</footer>

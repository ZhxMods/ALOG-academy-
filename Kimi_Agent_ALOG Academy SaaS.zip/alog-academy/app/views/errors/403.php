<section class="py-5">
    <div class="container text-center py-5">
        <div class="error-code">403</div>
        <h2 class="fw-bold mb-3">Accès interdit</h2>
        <p class="text-muted mb-4">Vous n'avez pas les permissions nécessaires pour accéder à cette page.</p>
        <a href="<?= BASE_URL ?>/" class="btn btn-primary"><i class="bi bi-house me-1"></i>Retour à l'accueil</a>
    </div>
</section>

<style>.error-code { font-size: 8rem; font-weight: 800; color: var(--bs-danger); opacity: 0.3; line-height: 1; }</style>

<section class="py-5">
    <div class="container text-center py-5">
        <div class="error-code">404</div>
        <h2 class="fw-bold mb-3">Page non trouvée</h2>
        <p class="text-muted mb-4">La page que vous recherchez n'existe pas ou a été déplacée.</p>
        <a href="<?= BASE_URL ?>/" class="btn btn-primary"><i class="bi bi-house me-1"></i>Retour à l'accueil</a>
    </div>
</section>

<style>.error-code { font-size: 8rem; font-weight: 800; color: var(--bs-primary); opacity: 0.3; line-height: 1; }</style>

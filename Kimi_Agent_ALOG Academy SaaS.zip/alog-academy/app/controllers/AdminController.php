<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;
use App\Models\Level;
use App\Models\Subject;
use App\Models\Lesson;
use App\Models\Quiz;
use App\Models\Ranking;
use App\Models\Subscription;
use App\Models\Payment;
use App\Models\Booking;
use App\Models\BlogPost;
use App\Models\Notification;

class AdminController extends Controller {
    private User $userModel;
    private Level $levelModel;
    private Subject $subjectModel;
    private Lesson $lessonModel;
    private Quiz $quizModel;
    private Ranking $rankingModel;
    private Subscription $subModel;
    private Payment $paymentModel;
    private Booking $bookingModel;
    private BlogPost $blogModel;

    public function __construct() {
        parent::__construct();
        $this->userModel = new User();
        $this->levelModel = new Level();
        $this->subjectModel = new Subject();
        $this->lessonModel = new Lesson();
        $this->quizModel = new Quiz();
        $this->rankingModel = new Ranking();
        $this->subModel = new Subscription();
        $this->paymentModel = new Payment();
        $this->bookingModel = new Booking();
        $this->blogModel = new BlogPost();
    }

    private function requireAdmin(): void {
        if (!is_admin()) {
            http_response_code(403);
            $this->viewWithLayout('errors/403', 'main', ['title' => 'Accès interdit']);
            exit;
        }
    }

    // ==================== DASHBOARD ====================

    public function dashboard(): void {
        $this->requireAdmin();

        $stats = [
            'total_students' => $this->userModel->countByRole('student'),
            'total_admins' => $this->userModel->countByRole('admin') + $this->userModel->countByRole('super_admin'),
            'active_today' => $this->userModel->countActiveToday(),
            'total_lessons' => $this->lessonModel->count(),
            'total_quizzes' => $this->quizModel->count(),
            'total_blog_posts' => $this->blogModel->countPublished(),
            'pending_payments' => $this->paymentModel->count("status = 'pending'"),
            'pending_bookings' => $this->bookingModel->count("status = 'pending'"),
            'total_revenue' => $this->db->fetchColumn("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = 'approved'"),
        ];

        // Graphiques - Inscriptions par jour (7 derniers jours)
        $dailySignups = $this->db->fetchAll(
            "SELECT DATE(created_at) as date, COUNT(*) as count
             FROM users WHERE role = 'student' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY DATE(created_at) ORDER BY date"
        );

        // Activité XP par jour
        $dailyXp = $this->db->fetchAll(
            "SELECT DATE(created_at) as date, SUM(amount) as total
             FROM xp_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY DATE(created_at) ORDER BY date"
        );

        // Dernières activités
        $recentActivities = $this->db->fetchAll(
            "SELECT 'xp' as type, u.fullname, xl.description, xl.created_at
             FROM xp_logs xl JOIN users u ON xl.user_id = u.id
             ORDER BY xl.created_at DESC LIMIT 10"
        );

        $this->viewWithLayout('admin/dashboard', 'admin', [
            'title' => 'Admin Dashboard',
            'stats' => $stats,
            'dailySignups' => $dailySignups,
            'dailyXp' => $dailyXp,
            'recentActivities' => $recentActivities,
        ]);
    }

    // ==================== USERS ====================

    public function users(): void {
        $this->requireAdmin();
        $page = (int)($_GET['page'] ?? 1);
        $result = $this->userModel->getStudents($page, 20);

        $this->viewWithLayout('admin/users', 'admin', [
            'title' => 'Gestion des utilisateurs',
            'users' => $result['items'],
            'pagination' => $result['pagination'],
        ]);
    }

    public function userDetail(int $id): void {
        $this->requireAdmin();
        $user = $this->userModel->find($id);
        if (!$user) {
            flash('error', 'Utilisateur introuvable.');
            redirect('/admin/users');
        }

        $stats = $this->userModel->getStats($id);
        $xpLogs = $this->db->fetchAll("SELECT * FROM xp_logs WHERE user_id = :uid ORDER BY created_at DESC LIMIT 20", ['uid' => $id]);
        $subHistory = $this->subModel->getHistory($id);
        $payments = $this->paymentModel->getByUser($id);

        $this->viewWithLayout('admin/user-detail', 'admin', [
            'title' => $user['fullname'],
            'user' => $user,
            'stats' => $stats,
            'xpLogs' => $xpLogs,
            'subHistory' => $subHistory,
            'payments' => $payments,
        ]);
    }

    public function updateUser(int $id): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/admin/users');
        }

        $data = [
            'fullname' => htmlspecialchars(trim($_POST['fullname'] ?? '')),
            'email' => strtolower(trim($_POST['email'] ?? '')),
            'role' => $_POST['role'] ?? 'student',
            'plan' => $_POST['plan'] ?? 'FREE',
            'status' => $_POST['status'] ?? 'active',
            'xp_total' => (int)($_POST['xp_total'] ?? 0),
            'level' => (int)($_POST['level'] ?? 1),
            'region' => $_POST['region'] ?? '',
        ];

        if (!empty($_POST['password'])) {
            $data['password'] = password_hash($_POST['password'], PASSWORD_BCRYPT);
        }

        $this->userModel->update($id, $data);
        flash('success', 'Utilisateur mis à jour.');
        redirect('/admin/users');
    }

    public function deleteUser(int $id): void {
        $this->requireAdmin();
        if (!is_super_admin()) {
            flash('error', 'Seul le super admin peut supprimer des utilisateurs.');
            redirect('/admin/users');
        }

        $this->userModel->delete($id);
        flash('success', 'Utilisateur supprimé.');
        redirect('/admin/users');
    }

    // ==================== LEVELS ====================

    public function levels(): void {
        $this->requireAdmin();
        $levels = $this->levelModel->all('sort_order', 'ASC');

        $this->viewWithLayout('admin/levels', 'admin', [
            'title' => 'Gestion des niveaux',
            'levels' => $levels,
        ]);
    }

    public function createLevel(): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'name' => htmlspecialchars(trim($_POST['name'] ?? '')),
                'slug' => \slugify($_POST['name'] ?? ''),
                'description' => htmlspecialchars(trim($_POST['description'] ?? '')),
                'icon' => $_POST['icon'] ?? 'book',
                'color' => $_POST['color'] ?? 'primary',
                'sort_order' => (int)($_POST['sort_order'] ?? 0),
            ];
            $this->levelModel->create($data);
            flash('success', 'Niveau créé.');
            redirect('/admin/levels');
        }
    }

    public function updateLevel(int $id): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'name' => htmlspecialchars(trim($_POST['name'] ?? '')),
                'slug' => \slugify($_POST['name'] ?? ''),
                'description' => htmlspecialchars(trim($_POST['description'] ?? '')),
                'icon' => $_POST['icon'] ?? 'book',
                'color' => $_POST['color'] ?? 'primary',
                'sort_order' => (int)($_POST['sort_order'] ?? 0),
                'is_active' => isset($_POST['is_active']) ? 1 : 0,
            ];
            $this->levelModel->update($id, $data);
            flash('success', 'Niveau mis à jour.');
            redirect('/admin/levels');
        }
    }

    // ==================== SUBJECTS ====================

    public function subjects(): void {
        $this->requireAdmin();
        $subjects = $this->db->fetchAll(
            "SELECT s.*, l.name as level_name FROM subjects s
             JOIN levels l ON s.level_id = l.id ORDER BY s.sort_order ASC"
        );
        $levels = $this->levelModel->getActive();

        $this->viewWithLayout('admin/subjects', 'admin', [
            'title' => 'Gestion des matières',
            'subjects' => $subjects,
            'levels' => $levels,
        ]);
    }

    public function createSubject(): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'level_id' => (int)($_POST['level_id'] ?? 0),
                'name' => htmlspecialchars(trim($_POST['name'] ?? '')),
                'slug' => \slugify($_POST['name'] ?? ''),
                'description' => htmlspecialchars(trim($_POST['description'] ?? '')),
                'icon' => $_POST['icon'] ?? 'book',
                'color' => $_POST['color'] ?? 'primary',
                'sort_order' => (int)($_POST['sort_order'] ?? 0),
            ];
            $this->subjectModel->create($data);
            flash('success', 'Matière créée.');
            redirect('/admin/subjects');
        }
    }

    public function updateSubject(int $id): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'level_id' => (int)($_POST['level_id'] ?? 0),
                'name' => htmlspecialchars(trim($_POST['name'] ?? '')),
                'slug' => \slugify($_POST['name'] ?? ''),
                'description' => htmlspecialchars(trim($_POST['description'] ?? '')),
                'icon' => $_POST['icon'] ?? 'book',
                'color' => $_POST['color'] ?? 'primary',
                'sort_order' => (int)($_POST['sort_order'] ?? 0),
                'is_active' => isset($_POST['is_active']) ? 1 : 0,
            ];
            $this->subjectModel->update($id, $data);
            flash('success', 'Matière mise à jour.');
            redirect('/admin/subjects');
        }
    }

    // ==================== LESSONS ====================

    public function lessons(): void {
        $this->requireAdmin();
        $page = (int)($_GET['page'] ?? 1);
        $perPage = 20;
        $total = $this->lessonModel->count();
        $pag = \paginate($total, $page, $perPage);

        $lessons = $this->db->fetchAll(
            "SELECT l.*, s.name as subject_name, lv.name as level_name
             FROM lessons l
             JOIN subjects s ON l.subject_id = s.id
             JOIN levels lv ON l.level_id = lv.id
             ORDER BY l.created_at DESC LIMIT {$pag['per_page']} OFFSET {$pag['offset']}"
        );

        $subjects = $this->db->fetchAll("SELECT id, name FROM subjects WHERE is_active = 1 ORDER BY name");
        $levels = $this->levelModel->getActive();

        $this->viewWithLayout('admin/lessons', 'admin', [
            'title' => 'Gestion des leçons',
            'lessons' => $lessons,
            'pagination' => $pag,
            'subjects' => $subjects,
            'levels' => $levels,
        ]);
    }

    public function createLesson(): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'subject_id' => (int)($_POST['subject_id'] ?? 0),
                'level_id' => (int)($_POST['level_id'] ?? 0),
                'title' => htmlspecialchars(trim($_POST['title'] ?? '')),
                'slug' => \slugify($_POST['title'] ?? ''),
                'description' => htmlspecialchars(trim($_POST['description'] ?? '')),
                'content' => $_POST['content'] ?? '',
                'youtube_url' => $_POST['youtube_url'] ?? null,
                'pdf_url' => $_POST['pdf_url'] ?? null,
                'exercise_pdf_url' => $_POST['exercise_pdf_url'] ?? null,
                'image_url' => $_POST['image_url'] ?? null,
                'xp_reward' => (int)($_POST['xp_reward'] ?? 10),
                'access_type' => $_POST['access_type'] ?? 'FREE',
                'duration_minutes' => (int)($_POST['duration_minutes'] ?? 0),
                'sort_order' => (int)($_POST['sort_order'] ?? 0),
            ];
            $this->lessonModel->create($data);
            flash('success', 'Leçon créée.');
            redirect('/admin/lessons');
        }
    }

    public function updateLesson(int $id): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'subject_id' => (int)($_POST['subject_id'] ?? 0),
                'level_id' => (int)($_POST['level_id'] ?? 0),
                'title' => htmlspecialchars(trim($_POST['title'] ?? '')),
                'slug' => \slugify($_POST['title'] ?? ''),
                'description' => htmlspecialchars(trim($_POST['description'] ?? '')),
                'content' => $_POST['content'] ?? '',
                'youtube_url' => $_POST['youtube_url'] ?? null,
                'pdf_url' => $_POST['pdf_url'] ?? null,
                'exercise_pdf_url' => $_POST['exercise_pdf_url'] ?? null,
                'image_url' => $_POST['image_url'] ?? null,
                'xp_reward' => (int)($_POST['xp_reward'] ?? 10),
                'access_type' => $_POST['access_type'] ?? 'FREE',
                'duration_minutes' => (int)($_POST['duration_minutes'] ?? 0),
                'sort_order' => (int)($_POST['sort_order'] ?? 0),
                'is_active' => isset($_POST['is_active']) ? 1 : 0,
            ];
            $this->lessonModel->update($id, $data);
            flash('success', 'Leçon mise à jour.');
            redirect('/admin/lessons');
        }
    }

    public function deleteLesson(int $id): void {
        $this->requireAdmin();
        $this->lessonModel->delete($id);
        flash('success', 'Leçon supprimée.');
        redirect('/admin/lessons');
    }

    // ==================== QUIZZES ====================

    public function quizzes(): void {
        $this->requireAdmin();
        $quizzes = $this->db->fetchAll(
            "SELECT q.*, l.title as lesson_title, s.name as subject_name
             FROM quizzes q
             LEFT JOIN lessons l ON q.lesson_id = l.id
             LEFT JOIN subjects s ON q.subject_id = s.id
             ORDER BY q.created_at DESC"
        );

        $this->viewWithLayout('admin/quizzes', 'admin', [
            'title' => 'Gestion des quiz',
            'quizzes' => $quizzes,
        ]);
    }

    public function createQuiz(): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'lesson_id' => !empty($_POST['lesson_id']) ? (int)$_POST['lesson_id'] : null,
                'subject_id' => !empty($_POST['subject_id']) ? (int)$_POST['subject_id'] : null,
                'level_id' => !empty($_POST['level_id']) ? (int)$_POST['level_id'] : null,
                'title' => htmlspecialchars(trim($_POST['title'] ?? '')),
                'slug' => \slugify($_POST['title'] ?? ''),
                'description' => htmlspecialchars(trim($_POST['description'] ?? '')),
                'time_limit' => !empty($_POST['time_limit']) ? (int)$_POST['time_limit'] : null,
                'passing_score' => (int)($_POST['passing_score'] ?? 60),
                'xp_reward' => (int)($_POST['xp_reward'] ?? 20),
                'xp_perfect_bonus' => (int)($_POST['xp_perfect_bonus'] ?? 50),
                'shuffle_questions' => isset($_POST['shuffle_questions']) ? 1 : 0,
                'max_attempts' => !empty($_POST['max_attempts']) ? (int)$_POST['max_attempts'] : null,
                'cooldown_hours' => (int)($_POST['cooldown_hours'] ?? 0),
                'access_type' => $_POST['access_type'] ?? 'FREE',
            ];
            $quizId = $this->quizModel->create($data);

            // Ajouter les questions
            if (!empty($_POST['questions'])) {
                foreach ($_POST['questions'] as $q) {
                    $this->db->insert('quiz_questions', [
                        'quiz_id' => $quizId,
                        'question' => htmlspecialchars(trim($q['question'])),
                        'question_type' => $q['type'] ?? 'mcq',
                        'options' => json_encode($q['options'] ?? []),
                        'correct_answer' => $q['correct'] ?? '',
                        'explanation' => htmlspecialchars(trim($q['explanation'] ?? '')),
                        'points' => (int)($q['points'] ?? 1),
                        'sort_order' => (int)($q['sort_order'] ?? 0),
                    ]);
                }
            }

            flash('success', 'Quiz créé avec succès.');
            redirect('/admin/quizzes');
        }
    }

    public function updateQuiz(int $id): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'title' => htmlspecialchars(trim($_POST['title'] ?? '')),
                'slug' => \slugify($_POST['title'] ?? ''),
                'description' => htmlspecialchars(trim($_POST['description'] ?? '')),
                'time_limit' => !empty($_POST['time_limit']) ? (int)$_POST['time_limit'] : null,
                'passing_score' => (int)($_POST['passing_score'] ?? 60),
                'xp_reward' => (int)($_POST['xp_reward'] ?? 20),
                'xp_perfect_bonus' => (int)($_POST['xp_perfect_bonus'] ?? 50),
                'shuffle_questions' => isset($_POST['shuffle_questions']) ? 1 : 0,
                'max_attempts' => !empty($_POST['max_attempts']) ? (int)$_POST['max_attempts'] : null,
                'cooldown_hours' => (int)($_POST['cooldown_hours'] ?? 0),
                'access_type' => $_POST['access_type'] ?? 'FREE',
                'is_active' => isset($_POST['is_active']) ? 1 : 0,
            ];
            $this->quizModel->update($id, $data);
            flash('success', 'Quiz mis à jour.');
            redirect('/admin/quizzes');
        }
    }

    public function deleteQuiz(int $id): void {
        $this->requireAdmin();
        $this->quizModel->delete($id);
        flash('success', 'Quiz supprimé.');
        redirect('/admin/quizzes');
    }

    // ==================== PAYMENTS ====================

    public function payments(): void {
        $this->requireAdmin();
        $page = (int)($_GET['page'] ?? 1);
        $result = $this->paymentModel->getAll($page, 20);
        $stats = $this->paymentModel->getStats();

        $this->viewWithLayout('admin/payments', 'admin', [
            'title' => 'Validation des paiements',
            'payments' => $result['items'],
            'pagination' => $result['pagination'],
            'stats' => $stats,
        ]);
    }

    public function approvePayment(int $id): void {
        $this->requireAdmin();
        $success = $this->paymentModel->approve($id, auth()['id']);
        if ($success) {
            flash('success', 'Paiement approuvé et abonnement activé.');
        } else {
            flash('error', 'Erreur lors de l\'approbation.');
        }
        redirect('/admin/payments');
    }

    public function rejectPayment(int $id): void {
        $this->requireAdmin();
        $reason = $_POST['reason'] ?? '';
        $this->paymentModel->reject($id, auth()['id'], $reason);
        flash('success', 'Paiement rejeté.');
        redirect('/admin/payments');
    }

    // ==================== BOOKINGS ====================

    public function bookings(): void {
        $this->requireAdmin();
        $page = (int)($_GET['page'] ?? 1);
        $result = $this->bookingModel->getAll($page, 20);

        $this->viewWithLayout('admin/bookings', 'admin', [
            'title' => 'Gestion des réservations',
            'bookings' => $result['items'],
            'pagination' => $result['pagination'],
        ]);
    }

    public function approveBooking(int $id): void {
        $this->requireAdmin();
        $response = $_POST['response'] ?? '';
        $this->bookingModel->approve($id, auth()['id'], $response);
        flash('success', 'Réservation approuvée.');
        redirect('/admin/bookings');
    }

    public function rejectBooking(int $id): void {
        $this->requireAdmin();
        $response = $_POST['response'] ?? '';
        $this->bookingModel->reject($id, auth()['id'], $response);
        flash('success', 'Réservation rejetée.');
        redirect('/admin/bookings');
    }

    public function completeBooking(int $id): void {
        $this->requireAdmin();
        $this->bookingModel->complete($id, auth()['id']);
        flash('success', 'Réservation marquée comme complétée.');
        redirect('/admin/bookings');
    }

    // ==================== BLOG ====================

    public function blogPosts(): void {
        $this->requireAdmin();
        $posts = $this->db->fetchAll(
            "SELECT bp.*, bc.name as category_name, u.fullname as author_name
             FROM blog_posts bp
             LEFT JOIN blog_categories bc ON bp.category_id = bc.id
             LEFT JOIN users u ON bp.author_id = u.id
             ORDER BY bp.created_at DESC"
        );
        $categories = $this->blogModel->getCategories();

        $this->viewWithLayout('admin/blog-posts', 'admin', [
            'title' => 'Gestion du blog',
            'posts' => $posts,
            'categories' => $categories,
        ]);
    }

    public function createBlogPost(): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'category_id' => !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null,
                'author_id' => auth()['id'],
                'title' => htmlspecialchars(trim($_POST['title'] ?? '')),
                'slug' => \slugify($_POST['title'] ?? ''),
                'excerpt' => htmlspecialchars(trim($_POST['excerpt'] ?? '')),
                'content' => $_POST['content'] ?? '',
                'featured_image' => $_POST['featured_image'] ?? null,
                'meta_title' => htmlspecialchars(trim($_POST['meta_title'] ?? '')),
                'meta_description' => htmlspecialchars(trim($_POST['meta_description'] ?? '')),
                'is_published' => isset($_POST['is_published']) ? 1 : 0,
                'published_at' => isset($_POST['is_published']) ? date('Y-m-d H:i:s') : null,
            ];
            $this->blogModel->create($data);
            flash('success', 'Article créé.');
            redirect('/admin/blog');
        }
    }

    public function updateBlogPost(int $id): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'category_id' => !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null,
                'title' => htmlspecialchars(trim($_POST['title'] ?? '')),
                'slug' => \slugify($_POST['title'] ?? ''),
                'excerpt' => htmlspecialchars(trim($_POST['excerpt'] ?? '')),
                'content' => $_POST['content'] ?? '',
                'featured_image' => $_POST['featured_image'] ?? null,
                'meta_title' => htmlspecialchars(trim($_POST['meta_title'] ?? '')),
                'meta_description' => htmlspecialchars(trim($_POST['meta_description'] ?? '')),
                'is_published' => isset($_POST['is_published']) ? 1 : 0,
                'published_at' => isset($_POST['is_published']) ? date('Y-m-d H:i:s') : null,
            ];
            $this->blogModel->update($id, $data);
            flash('success', 'Article mis à jour.');
            redirect('/admin/blog');
        }
    }

    public function deleteBlogPost(int $id): void {
        $this->requireAdmin();
        $this->blogModel->delete($id);
        flash('success', 'Article supprimé.');
        redirect('/admin/blog');
    }

    // ==================== RANKINGS ====================

    public function rankings(): void {
        $this->requireAdmin();
        $leaderboard = $this->rankingModel->getGlobalLeaderboard(100);
        $regions = $this->rankingModel->getRegions();

        $this->viewWithLayout('admin/rankings', 'admin', [
            'title' => 'Classements',
            'leaderboard' => $leaderboard,
            'regions' => $regions,
        ]);
    }

    // ==================== ANNOUNCEMENTS ====================

    public function announcements(): void {
        $this->requireAdmin();
        $announcements = $this->db->fetchAll("SELECT * FROM announcements ORDER BY created_at DESC");

        $this->viewWithLayout('admin/announcements', 'admin', [
            'title' => 'Annonces',
            'announcements' => $announcements,
        ]);
    }

    public function createAnnouncement(): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->db->insert('announcements', [
                'title' => htmlspecialchars(trim($_POST['title'] ?? '')),
                'content' => $_POST['content'] ?? '',
                'type' => $_POST['type'] ?? 'info',
                'is_active' => isset($_POST['is_active']) ? 1 : 0,
                'starts_at' => $_POST['starts_at'] ?? null,
                'expires_at' => $_POST['expires_at'] ?? null,
            ]);
            flash('success', 'Annonce créée.');
            redirect('/admin/announcements');
        }
    }

    public function deleteAnnouncement(int $id): void {
        $this->requireAdmin();
        $this->db->delete('announcements', 'id = :id', ['id' => $id]);
        flash('success', 'Annonce supprimée.');
        redirect('/admin/announcements');
    }

    // ==================== ANALYTICS ====================

    public function analytics(): void {
        $this->requireAdmin();

        // Statistiques globales
        $stats = [
            'students_by_month' => $this->db->fetchAll(
                "SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count
                 FROM users WHERE role = 'student' GROUP BY month ORDER BY month DESC LIMIT 12"
            ),
            'subscriptions_by_plan' => $this->db->fetchAll(
                "SELECT plan, COUNT(*) as count FROM users WHERE role = 'student' GROUP BY plan"
            ),
            'revenue_by_month' => $this->db->fetchAll(
                "SELECT DATE_FORMAT(created_at, '%Y-%m') as month, SUM(amount) as total
                 FROM payments WHERE status = 'approved' GROUP BY month ORDER BY month DESC LIMIT 12"
            ),
            'top_lessons' => $this->db->fetchAll(
                "SELECT title, views_count, completions_count FROM lessons ORDER BY views_count DESC LIMIT 10"
            ),
            'top_students' => $this->db->fetchAll(
                "SELECT fullname, xp_total, level FROM users WHERE role = 'student' ORDER BY xp_total DESC LIMIT 10"
            ),
        ];

        $this->viewWithLayout('admin/analytics', 'admin', [
            'title' => 'Analytics',
            'stats' => $stats,
        ]);
    }

    // ==================== SETTINGS ====================

    public function settings(): void {
        $this->requireAdmin();
        $settings = $this->db->fetchAll("SELECT * FROM settings ORDER BY setting_group, setting_key");

        $this->viewWithLayout('admin/settings', 'admin', [
            'title' => 'Paramètres',
            'settings' => $settings,
        ]);
    }

    public function updateSettings(): void {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            foreach ($_POST['settings'] ?? [] as $key => $value) {
                $this->db->update('settings', ['setting_value' => $value], 'setting_key = :key', ['key' => $key]);
            }
            flash('success', 'Paramètres mis à jour.');
            redirect('/admin/settings');
        }
    }
}

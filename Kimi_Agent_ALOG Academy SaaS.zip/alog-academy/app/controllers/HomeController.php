<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Level;
use App\Models\Lesson;
use App\Models\BlogPost;
use App\Models\User;

class HomeController extends Controller {
    private Level $levelModel;
    private Lesson $lessonModel;
    private BlogPost $blogModel;

    public function __construct() {
        parent::__construct();
        $this->levelModel = new Level();
        $this->lessonModel = new Lesson();
        $this->blogModel = new BlogPost();
    }

    public function index(): void {
        $levels = $this->levelModel->getWithSubjects();
        $recentLessons = $this->lessonModel->getRecent(6);
        $popularLessons = $this->lessonModel->getPopular(6);
        $blogPosts = $this->blogModel->getRecent(3);

        // Stats pour la page d'accueil
        $userCount = $this->db->fetchColumn("SELECT COUNT(*) FROM users WHERE role = 'student'");
        $lessonCount = $this->db->fetchColumn("SELECT COUNT(*) FROM lessons WHERE is_active = 1");
        $quizCount = $this->db->fetchColumn("SELECT COUNT(*) FROM quizzes WHERE is_active = 1");

        $this->viewWithLayout('public/home', 'main', [
            'title' => 'ALOG Academy - Apprenez en vous amusant',
            'description' => 'Plateforme éducative gamifiée pour étudiants marocains. Cours en ligne, quiz interactifs, et système de récompenses.',
            'levels' => $levels,
            'recentLessons' => $recentLessons,
            'popularLessons' => $popularLessons,
            'blogPosts' => $blogPosts,
            'userCount' => $userCount,
            'lessonCount' => $lessonCount,
            'quizCount' => $quizCount,
        ]);
    }

    public function about(): void {
        $this->viewWithLayout('public/about', 'main', [
            'title' => 'À propos - ALOG Academy',
            'description' => 'Découvrez ALOG Academy, la plateforme éducative gamifiée pour les étudiants marocains.',
        ]);
    }

    public function pricing(): void {
        $this->viewWithLayout('public/pricing', 'main', [
            'title' => 'Tarifs - ALOG Academy',
            'description' => 'Choisissez le plan qui vous convient. Commencez gratuitement et passez à PRO ou ULTRA.',
        ]);
    }

    public function contact(): void {
        $this->viewWithLayout('public/contact', 'main', [
            'title' => 'Contact - ALOG Academy',
            'description' => 'Contactez l\'équipe ALOG Academy.',
        ]);
    }

    public function sendContact(): void {
        if (!verify_csrf()) {
            flash('error', 'Session invalide.');
            redirect('/contact');
        }

        $name = htmlspecialchars(trim($_POST['name'] ?? ''));
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
        $subject = htmlspecialchars(trim($_POST['subject'] ?? ''));
        $message = htmlspecialchars(trim($_POST['message'] ?? ''));

        if (empty($name) || empty($email) || empty($subject) || empty($message)) {
            flash('error', 'Veuillez remplir tous les champs.');
            redirect('/contact');
        }

        // Enregistrer dans la base de données
        $this->db->insert('bookings', [
            'user_id' => auth()['id'] ?? 0,
            'booking_type' => 'contact',
            'subject' => $subject . ' - De: ' . $name . ' (' . $email . ')',
            'message' => $message,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        flash('success', 'Votre message a été envoyé. Nous vous répondrons bientôt !');
        redirect('/contact');
    }

    public function search(): void {
        $query = $_GET['q'] ?? '';
        $results = [];

        if (strlen($query) >= 2) {
            $results['lessons'] = $this->lessonModel->search($query);
            $results['blog'] = $this->blogModel->search($query);
        }

        $this->viewWithLayout('public/search', 'main', [
            'title' => 'Recherche: ' . e($query),
            'query' => $query,
            'results' => $results,
        ]);
    }
}

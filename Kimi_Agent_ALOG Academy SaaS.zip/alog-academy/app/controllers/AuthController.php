<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Auth;
use App\Models\User;

class AuthController extends Controller {
    private Auth $auth;
    private User $userModel;

    public function __construct() {
        parent::__construct();
        $this->auth = Auth::getInstance();
        $this->userModel = new User();
    }

    /**
     * Page de connexion
     */
    public function loginForm(): void {
        if (is_logged_in()) {
            redirect(is_admin() ? '/admin/dashboard' : '/dashboard');
        }
        $this->viewWithLayout('auth/login', 'auth', [
            'title' => 'Connexion - ALOG Academy',
            'errors' => $this->getErrors(),
        ]);
    }

    /**
     * Traitement connexion
     */
    public function login(): void {
        if (!verify_csrf()) {
            flash('error', 'Session invalide. Veuillez rafraîchir la page.');
            redirect('/login');
        }

        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember_me']);

        if (empty($email) || empty($password)) {
            flash('error', 'Veuillez remplir tous les champs.');
            flash_old(['email' => $email]);
            redirect('/login');
        }

        $result = $this->auth->login($email, $password);

        if (!$result['success']) {
            flash('error', $result['errors'][0] ?? 'Erreur de connexion.');
            flash_old(['email' => $email]);
            redirect('/login');
        }

        if ($remember) {
            $this->auth->createRememberToken($result['user']['id']);
        }

        flash('success', 'Bienvenue, ' . $result['user']['fullname'] . ' !');
        redirect(is_admin() ? '/admin/dashboard' : '/dashboard');
    }

    /**
     * Page d'inscription
     */
    public function registerForm(): void {
        if (is_logged_in()) {
            redirect('/dashboard');
        }
        $this->viewWithLayout('auth/register', 'auth', [
            'title' => 'Inscription - ALOG Academy',
            'errors' => $this->getErrors(),
        ]);
    }

    /**
     * Traitement inscription
     */
    public function register(): void {
        if (!verify_csrf()) {
            flash('error', 'Session invalide.');
            redirect('/register');
        }

        $data = [
            'fullname' => $_POST['fullname'] ?? '',
            'email' => $_POST['email'] ?? '',
            'password' => $_POST['password'] ?? '',
            'password_confirm' => $_POST['password_confirm'] ?? '',
            'region' => $_POST['region'] ?? 'inconnu',
        ];

        $result = $this->auth->register($data);

        if (!$result['success']) {
            $_SESSION['errors'] = $result['errors'];
            flash_old($data);
            redirect('/register');
        }

        flash('success', 'Compte créé avec succès ! Connectez-vous maintenant.');
        redirect('/login');
    }

    /**
     * Déconnexion
     */
    public function logout(): void {
        $this->auth->logout();
        flash('success', 'Vous êtes déconnecté.');
        redirect('/');
    }

    /**
     * Mot de passe oublié - Formulaire
     */
    public function forgotForm(): void {
        $this->viewWithLayout('auth/forgot-password', 'auth', [
            'title' => 'Mot de passe oublié - ALOG Academy',
        ]);
    }

    /**
     * Traitement mot de passe oublié
     */
    public function forgot(): void {
        if (!verify_csrf()) {
            flash('error', 'Session invalide.');
            redirect('/forgot-password');
        }

        $email = $_POST['email'] ?? '';
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Veuillez entrer une adresse email valide.');
            redirect('/forgot-password');
        }

        $result = $this->auth->forgotPassword($email);

        if ($result['success']) {
            flash('success', 'Un lien de réinitialisation a été envoyé à votre email.');
        } else {
            flash('error', $result['errors'][0] ?? 'Erreur.');
        }

        redirect('/forgot-password');
    }

    /**
     * Réinitialisation mot de passe - Formulaire
     */
    public function resetForm(string $token): void {
        $this->viewWithLayout('auth/reset-password', 'auth', [
            'title' => 'Réinitialiser le mot de passe',
            'token' => $token,
        ]);
    }

    /**
     * Traitement réinitialisation
     */
    public function reset(): void {
        if (!verify_csrf()) {
            flash('error', 'Session invalide.');
            redirect('/');
        }

        $token = $_POST['token'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['password_confirm'] ?? '';

        if ($password !== $confirm) {
            flash('error', 'Les mots de passe ne correspondent pas.');
            redirect('/reset-password/' . $token);
        }

        $result = $this->auth->resetPassword($token, $password);

        if ($result['success']) {
            flash('success', 'Mot de passe réinitialisé avec succès ! Connectez-vous.');
            redirect('/login');
        } else {
            flash('error', $result['errors'][0] ?? 'Erreur.');
            redirect('/reset-password/' . $token);
        }
    }
}

<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;
use App\Models\Level;
use App\Models\Subject;
use App\Models\Lesson;
use App\Models\Quiz;
use App\Models\Ranking;
use App\Models\Subscription;
use App\Models\Payment;
use App\Models\Booking;
use App\Models\Notification;
use App\Models\BlogPost;

class StudentController extends Controller {
    private User $userModel;
    private Level $levelModel;
    private Subject $subjectModel;
    private Lesson $lessonModel;
    private Quiz $quizModel;
    private Ranking $rankingModel;
    private Subscription $subModel;
    private Payment $paymentModel;
    private Booking $bookingModel;
    private Notification $notifModel;
    private BlogPost $blogModel;

    public function __construct() {
        parent::__construct();
        $this->userModel = new User();
        $this->levelModel = new Level();
        $this->subjectModel = new Subject();
        $this->lessonModel = new Lesson();
        $this->quizModel = new Quiz();
        $this->rankingModel = new Ranking();
        $this->subModel = new Subscription();
        $this->paymentModel = new Payment();
        $this->bookingModel = new Booking();
        $this->notifModel = new Notification();
        $this->blogModel = new BlogPost();
    }

    // ==================== DASHBOARD ====================

    public function dashboard(): void {
        $userId = auth()['id'];
        $user = $this->userModel->find($userId);
        $stats = $this->userModel->getStats($userId);
        $recentXp = $this->db->fetchAll(
            "SELECT * FROM xp_logs WHERE user_id = :uid ORDER BY created_at DESC LIMIT 5",
            ['uid' => $userId]
        );
        $inProgress = $this->db->fetchAll(
            "SELECT lp.*, l.title, l.slug, s.name as subject_name FROM lesson_progressions lp
             JOIN lessons l ON lp.lesson_id = l.id
             JOIN subjects s ON l.subject_id = s.id
             WHERE lp.user_id = :uid AND lp.is_completed = 0 ORDER BY lp.last_accessed_at DESC LIMIT 5",
            ['uid' => $userId]
        );
        $rankInfo = $this->rankingModel->getUserRank($userId);
        $unreadNotifs = $this->notifModel->countUnread($userId);
        $activeSub = $this->subModel->getActive($userId);

        $this->viewWithLayout('student/dashboard', 'student', [
            'title' => 'Tableau de bord',
            'user' => $user,
            'stats' => $stats,
            'recentXp' => $recentXp,
            'inProgress' => $inProgress,
            'rankInfo' => $rankInfo,
            'unreadNotifs' => $unreadNotifs,
            'activeSub' => $activeSub,
        ]);
    }

    // ==================== LESSONS ====================

    public function levels(): void {
        $levels = $this->levelModel->getWithSubjects();
        $this->viewWithLayout('student/levels', 'student', [
            'title' => 'Niveaux',
            'levels' => $levels,
        ]);
    }

    public function subjects(string $levelSlug): void {
        $level = $this->levelModel->getBySlug($levelSlug);
        if (!$level) {
            http_response_code(404);
            $this->viewWithLayout('errors/404', 'main', ['title' => 'Niveau non trouvé']);
            return;
        }
        $subjects = $this->subjectModel->getByLevel($level['id']);
        $this->viewWithLayout('student/subjects', 'student', [
            'title' => $level['name'],
            'level' => $level,
            'subjects' => $subjects,
        ]);
    }

    public function lessons(string $subjectSlug): void {
        $subject = $this->subjectModel->getBySlug($subjectSlug);
        if (!$subject) {
            http_response_code(404);
            $this->viewWithLayout('errors/404', 'main', ['title' => 'Matière non trouvée']);
            return;
        }

        $userPlan = auth()['plan'] ?? 'FREE';
        $userXp = auth()['xp_total'] ?? 0;
        $lessons = $this->lessonModel->getAccessibleLessons($subject['id'], $userPlan, $userXp);

        // Progression de l'utilisateur
        $userId = auth()['id'];
        foreach ($lessons as &$lesson) {
            $lesson['progress'] = $this->lessonModel->getProgress($userId, $lesson['id']);
        }

        $this->viewWithLayout('student/lessons', 'student', [
            'title' => $subject['name'],
            'subject' => $subject,
            'lessons' => $lessons,
        ]);
    }

    public function lesson(string $lessonSlug): void {
        $lesson = $this->lessonModel->getBySlug($lessonSlug);
        if (!$lesson) {
            http_response_code(404);
            $this->viewWithLayout('errors/404', 'main', ['title' => 'Leçon non trouvée']);
            return;
        }

        $userId = auth()['id'];
        $userPlan = auth()['plan'] ?? 'FREE';
        $userXp = auth()['xp_total'] ?? 0;

        // Vérifier l'accès
        if (!\can_access_lesson($lesson['access_type'], $userPlan, $userXp)) {
            flash('error', 'Cette leçon nécessite un abonnement ' . $lesson['access_type'] . '.');
            redirect('/pricing');
        }

        // Mettre à jour la progression
        $progress = $this->lessonModel->getOrCreateProgress($userId, $lesson['id']);

        // Incrémenter les vues
        $this->lessonModel->incrementViews($lesson['id']);

        // Récupérer les quiz associés
        $quizzes = $this->quizModel->getByLesson($lesson['id']);

        // Commentaires
        $comments = $this->lessonModel->getComments($lesson['id']);

        // Leçons suivante et précédente
        $siblings = $this->db->fetchAll(
            "SELECT id, title, slug FROM lessons
             WHERE subject_id = :sid AND is_active = 1 ORDER BY sort_order ASC",
            ['sid' => $lesson['subject_id']]
        );

        $currentIndex = -1;
        foreach ($siblings as $i => $s) {
            if ($s['id'] === $lesson['id']) {
                $currentIndex = $i;
                break;
            }
        }

        $prevLesson = $currentIndex > 0 ? $siblings[$currentIndex - 1] : null;
        $nextLesson = $currentIndex < count($siblings) - 1 ? $siblings[$currentIndex + 1] : null;

        $this->viewWithLayout('student/lesson', 'student', [
            'title' => $lesson['title'],
            'lesson' => $lesson,
            'progress' => $progress,
            'quizzes' => $quizzes,
            'comments' => $comments,
            'prevLesson' => $prevLesson,
            'nextLesson' => $nextLesson,
        ]);
    }

    public function completeLesson(int $lessonId): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/dashboard');
        }

        $userId = auth()['id'];
        $lesson = $this->lessonModel->find($lessonId);

        if (!$lesson) {
            flash('error', 'Leçon introuvable.');
            redirect('/dashboard');
        }

        $skipped = isset($_POST['skip']);
        $result = $this->lessonModel->markComplete($userId, $lessonId, $skipped);

        if ($result['xp_earned'] > 0) {
            flash('success', 'Leçon terminée ! +' . $result['xp_earned'] . ' XP');
        } elseif ($skipped) {
            flash('info', 'Leçon passée. Aucun XP gagné.');
        } else {
            flash('info', 'Leçon déjà terminée.');
        }

        // Rediriger vers la leçon suivante ou le sujet
        $nextLessonId = $_POST['next_lesson'] ?? null;
        if ($nextLessonId) {
            redirect('/lesson/' . $nextLessonId);
        }
        redirect('/subjects/' . $lesson['subject_slug'] ?? '/dashboard');
    }

    public function addComment(int $lessonId): void {
        if (!verify_csrf()) {
            flash('error', 'Session invalide.');
            redirect('/lesson/' . $lessonId);
        }

        $content = trim($_POST['content'] ?? '');
        if (empty($content)) {
            flash('error', 'Le commentaire ne peut pas être vide.');
            redirect('/lesson/' . $lessonId);
        }

        $this->lessonModel->addComment(auth()['id'], $lessonId, $content);
        flash('success', 'Commentaire ajouté !');
        redirect('/lesson/' . $lessonId);
    }

    // ==================== QUIZZES ====================

    public function quizzes(): void {
        $page = (int)($_GET['page'] ?? 1);
        $quizzes = $this->quizModel->getActive();
        $userId = auth()['id'];

        foreach ($quizzes as &$quiz) {
            $quiz['attempts'] = $this->quizModel->getAttemptsCount($userId, $quiz['id']);
            $quiz['last_attempt'] = $this->quizModel->getLastAttempt($userId, $quiz['id']);
            $quiz['can_retake'] = $this->quizModel->canRetake($userId, $quiz['id']);
            $quiz['cooldown'] = !$quiz['can_retake'] ? $this->quizModel->getCooldownRemaining($userId, $quiz['id']) : 0;
        }

        $this->viewWithLayout('student/quizzes', 'student', [
            'title' => 'Quiz',
            'quizzes' => $quizzes,
        ]);
    }

    public function quiz(string $quizSlug): void {
        $quiz = $this->quizModel->getBySlug($quizSlug);
        if (!$quiz) {
            http_response_code(404);
            $this->viewWithLayout('errors/404', 'main', ['title' => 'Quiz non trouvé']);
            return;
        }

        $userId = auth()['id'];

        // Vérifier cooldown
        if (!$this->quizModel->canRetake($userId, $quiz['id'])) {
            $remaining = $this->quizModel->getCooldownRemaining($userId, $quiz['id']);
            flash('error', 'Vous devez attendre encore ' . ceil($remaining / 60) . ' minutes avant de réessayer.');
            redirect('/quizzes');
        }

        $questions = $this->quizModel->getQuestionsForStudent($quiz['id']);

        $this->viewWithLayout('student/quiz', 'student', [
            'title' => $quiz['title'],
            'quiz' => $quiz,
            'questions' => $questions,
        ]);
    }

    public function submitQuiz(int $quizId): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/quizzes');
        }

        if (!verify_csrf()) {
            flash('error', 'Session invalide.');
            redirect('/quizzes');
        }

        $userId = auth()['id'];
        $answers = $_POST['answers'] ?? [];
        $timeTaken = isset($_POST['time_taken']) ? (int)$_POST['time_taken'] : null;

        $result = $this->quizModel->submit($userId, $quizId, $answers, $timeTaken);

        if ($result['success']) {
            flash('success', $result['is_perfect']
                ? 'Score parfait ! +' . $result['xp_earned'] . ' XP'
                : 'Quiz terminé ! Score: ' . $result['percentage'] . '%');
            redirect('/quiz-result/' . $quizId);
        } else {
            flash('error', $result['error'] ?? 'Erreur lors de la soumission.');
            redirect('/quizzes');
        }
    }

    public function quizResult(int $quizId): void {
        $userId = auth()['id'];
        $lastAttempt = $this->quizModel->getLastAttempt($userId, $quizId);
        $quiz = $this->quizModel->find($quizId);

        if (!$lastAttempt || !$quiz) {
            redirect('/quizzes');
        }

        // Récupérer les questions avec les bonnes réponses pour la correction
        $questions = $this->quizModel->getQuestions($quizId, false);
        $userAnswers = json_decode($lastAttempt['answers'] ?? '{}', true);

        $this->viewWithLayout('student/quiz-result', 'student', [
            'title' => 'Résultat: ' . $quiz['title'],
            'quiz' => $quiz,
            'attempt' => $lastAttempt,
            'questions' => $questions,
            'userAnswers' => $userAnswers,
        ]);
    }

    // ==================== RANKING ====================

    public function rankings(): void {
        $type = $_GET['type'] ?? 'global';
        $region = $_GET['region'] ?? null;
        $userId = auth()['id'];

        if ($type === 'regional' && $region) {
            $leaderboard = $this->rankingModel->getRegionalLeaderboard($region);
        } elseif ($type === 'weekly') {
            $leaderboard = $this->rankingModel->getWeeklyLeaderboard();
        } elseif ($type === 'monthly') {
            $leaderboard = $this->rankingModel->getMonthlyLeaderboard();
        } else {
            $leaderboard = $this->rankingModel->getGlobalLeaderboard();
        }

        $userRank = $this->rankingModel->getUserRank($userId);
        $badges = $this->rankingModel->getBadges($userId);
        $regions = $this->rankingModel->getRegions();

        $this->viewWithLayout('student/rankings', 'student', [
            'title' => 'Classement',
            'leaderboard' => $leaderboard,
            'userRank' => $userRank,
            'badges' => $badges,
            'regions' => $regions,
            'currentType' => $type,
            'currentRegion' => $region,
        ]);
    }

    // ==================== PROFILE ====================

    public function profile(): void {
        $userId = auth()['id'];
        $user = $this->userModel->find($userId);
        $stats = $this->userModel->getStats($userId);
        $badges = $this->rankingModel->getBadges($userId);
        $rankInfo = $this->rankingModel->getUserRank($userId);

        $this->viewWithLayout('student/profile', 'student', [
            'title' => 'Mon profil',
            'user' => $user,
            'stats' => $stats,
            'badges' => $badges,
            'rankInfo' => $rankInfo,
            'errors' => $this->getErrors(),
        ]);
    }

    public function updateProfile(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/profile');
        }

        if (!verify_csrf()) {
            flash('error', 'Session invalide.');
            redirect('/profile');
        }

        $userId = auth()['id'];
        $data = [
            'fullname' => htmlspecialchars(trim($_POST['fullname'] ?? '')),
            'phone' => htmlspecialchars(trim($_POST['phone'] ?? '')),
            'city' => htmlspecialchars(trim($_POST['city'] ?? '')),
            'region' => htmlspecialchars(trim($_POST['region'] ?? '')),
            'school' => htmlspecialchars(trim($_POST['school'] ?? '')),
            'grade' => htmlspecialchars(trim($_POST['grade'] ?? '')),
            'bio' => htmlspecialchars(trim($_POST['bio'] ?? '')),
        ];

        // Upload avatar
        if (!empty($_FILES['avatar']['tmp_name'])) {
            $avatarPath = \upload_file($_FILES['avatar'], 'avatars', ['jpg', 'jpeg', 'png']);
            if ($avatarPath) {
                $data['avatar'] = $avatarPath;
            }
        }

        $this->userModel->update($userId, $data);

        // Mettre à jour la session
        $_SESSION['user']['fullname'] = $data['fullname'];
        if (isset($data['avatar'])) {
            $_SESSION['user']['avatar'] = $data['avatar'];
        }

        flash('success', 'Profil mis à jour avec succès !');
        redirect('/profile');
    }

    // ==================== SUBSCRIPTION ====================

    public function subscriptions(): void {
        $userId = auth()['id'];
        $activeSub = $this->subModel->getActive($userId);
        $history = $this->subModel->getHistory($userId);
        $payments = $this->paymentModel->getByUser($userId);

        $this->viewWithLayout('student/subscriptions', 'student', [
            'title' => 'Mes abonnements',
            'activeSub' => $activeSub,
            'history' => $history,
            'payments' => $payments,
        ]);
    }

    public function subscribe(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/pricing');
        }

        if (!verify_csrf()) {
            flash('error', 'Session invalide.');
            redirect('/pricing');
        }

        $plan = $_POST['plan'] ?? '';
        if (!in_array($plan, ['PRO', 'ULTRA'])) {
            flash('error', 'Plan invalide.');
            redirect('/pricing');
        }

        $whatsapp = htmlspecialchars(trim($_POST['whatsapp'] ?? ''));
        if (empty($whatsapp)) {
            flash('error', 'Veuillez entrer votre numéro WhatsApp.');
            redirect('/pricing');
        }

        // Upload la preuve de paiement
        $proofImage = null;
        if (!empty($_FILES['proof']['tmp_name'])) {
            $proofImage = \upload_file($_FILES['proof'], 'payments', ['jpg', 'jpeg', 'png', 'pdf']);
        }

        $this->paymentModel->submit(auth()['id'], $plan, $whatsapp, $proofImage);

        flash('success', 'Demande d\'abonnement envoyée ! Nous la validerons sous 24h.');
        redirect('/subscriptions');
    }

    // ==================== BOOKINGS ====================

    public function bookings(): void {
        $userId = auth()['id'];
        $bookings = $this->bookingModel->getByUser($userId);

        $this->viewWithLayout('student/bookings', 'student', [
            'title' => 'Mes réservations',
            'bookings' => $bookings,
        ]);
    }

    public function createBooking(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/bookings');
        }

        if (!verify_csrf()) {
            flash('error', 'Session invalide.');
            redirect('/bookings');
        }

        $data = [
            'booking_type' => $_POST['booking_type'] ?? 'tutoring',
            'subject' => htmlspecialchars(trim($_POST['subject'] ?? '')),
            'message' => htmlspecialchars(trim($_POST['message'] ?? '')),
            'preferred_date' => $_POST['preferred_date'] ?? null,
            'preferred_time' => $_POST['preferred_time'] ?? null,
        ];

        if (empty($data['subject'])) {
            flash('error', 'Veuillez indiquer le sujet.');
            redirect('/bookings');
        }

        $this->bookingModel->createBooking(auth()['id'], $data);
        flash('success', 'Demande de réservation envoyée !');
        redirect('/bookings');
    }

    public function cancelBooking(int $bookingId): void {
        $booking = $this->bookingModel->find($bookingId);
        if ($booking && $booking['user_id'] == auth()['id'] && $booking['status'] === 'pending') {
            $this->bookingModel->cancel($bookingId);
            flash('success', 'Réservation annulée.');
        } else {
            flash('error', 'Impossible d\'annuler cette réservation.');
        }
        redirect('/bookings');
    }

    // ==================== NOTIFICATIONS ====================

    public function notifications(): void {
        $userId = auth()['id'];
        $notifications = $this->notifModel->getByUser($userId, 50);
        $this->notifModel->markAllAsRead($userId);

        $this->viewWithLayout('student/notifications', 'student', [
            'title' => 'Notifications',
            'notifications' => $notifications,
        ]);
    }

    public function markNotificationRead(int $notificationId): void {
        $this->notifModel->markAsRead($notificationId);
        if ($this->isAjax()) {
            $this->json(['success' => true]);
        }
        redirect('/notifications');
    }

    // ==================== BLOG ====================

    public function blog(): void {
        $page = (int)($_GET['page'] ?? 1);
        $categoryId = isset($_GET['category']) ? (int)$_GET['category'] : null;
        $result = $this->blogModel->getPublished($page, 10, $categoryId);
        $categories = $this->blogModel->getCategories();

        $this->viewWithLayout('public/blog', 'main', [
            'title' => 'Blog - ALOG Academy',
            'posts' => $result['items'],
            'pagination' => $result['pagination'],
            'categories' => $categories,
            'currentCategory' => $categoryId,
        ]);
    }

    public function blogPost(string $slug): void {
        $post = $this->blogModel->getBySlug($slug);
        if (!$post) {
            http_response_code(404);
            $this->viewWithLayout('errors/404', 'main', ['title' => 'Article non trouvé']);
            return;
        }

        $this->blogModel->incrementViews($post['id']);
        $related = $this->blogModel->getByCategory($post['category_id'], 3);
        $categories = $this->blogModel->getCategories();

        $this->viewWithLayout('public/blog-post', 'main', [
            'title' => $post['title'],
            'post' => $post,
            'related' => $related,
            'categories' => $categories,
        ]);
    }

    // ==================== XP HISTORY ====================

    public function xpHistory(): void {
        $userId = auth()['id'];
        $page = (int)($_GET['page'] ?? 1);
        $perPage = 20;
        $total = $this->db->fetchColumn("SELECT COUNT(*) FROM xp_logs WHERE user_id = :uid", ['uid' => $userId]);
        $pag = \paginate($total, $page, $perPage);

        $logs = $this->db->fetchAll(
            "SELECT * FROM xp_logs WHERE user_id = :uid ORDER BY created_at DESC LIMIT {$pag['per_page']} OFFSET {$pag['offset']}",
            ['uid' => $userId]
        );

        $this->viewWithLayout('student/xp-history', 'student', [
            'title' => 'Historique XP',
            'logs' => $logs,
            'pagination' => $pag,
        ]);
    }
}

<?php
namespace App\Core;

/**
 * ALOG ACADEMY - Classe de base Model
 * Active Record pattern simplifié
 */
abstract class Model {
    protected Database $db;
    protected string $table = '';
    protected string $primaryKey = 'id';
    protected array $fillable = [];
    protected array $hidden = [];
    protected ?array $attributes = null;

    public function __construct(?int $id = null) {
        $this->db = Database::getInstance();
        if ($id !== null) {
            $this->find($id);
        }
    }

    /**
     * Récupère la connexion DB
     */
    public function getDb(): Database {
        return $this->db;
    }

    /**
     * Trouve un enregistrement par ID
     */
    public function find(int $id): ?array {
        $result = $this->db->fetch(
            "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id LIMIT 1",
            ['id' => $id]
        );
        $this->attributes = $result;
        return $result;
    }

    /**
     * Trouve par condition
     */
    public function findWhere(string $column, $value): ?array {
        $result = $this->db->fetch(
            "SELECT * FROM {$this->table} WHERE {$column} = :val LIMIT 1",
            ['val' => $value]
        );
        $this->attributes = $result;
        return $result;
    }

    /**
     * Récupère tous les enregistrements
     */
    public function all(string $orderBy = '', string $direction = 'ASC'): array {
        $sql = "SELECT * FROM {$this->table}";
        if ($orderBy) {
            $sql .= " ORDER BY {$orderBy} {$direction}";
        }
        return $this->db->fetchAll($sql);
    }

    /**
     * Récupère avec condition
     */
    public function where(string $column, $value, string $orderBy = '', string $direction = 'ASC'): array {
        $sql = "SELECT * FROM {$this->table} WHERE {$column} = :val";
        if ($orderBy) {
            $sql .= " ORDER BY {$orderBy} {$direction}";
        }
        return $this->db->fetchAll($sql, ['val' => $value]);
    }

    /**
     * Récupère avec WHERE custom
     */
    public function whereRaw(string $where, array $params = [], string $orderBy = '', string $direction = 'ASC'): array {
        $sql = "SELECT * FROM {$this->table} WHERE {$where}";
        if ($orderBy) {
            $sql .= " ORDER BY {$orderBy} {$direction}";
        }
        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Crée un enregistrement
     */
    public function create(array $data): int {
        $filtered = array_intersect_key($data, array_flip($this->fillable));
        $filtered['created_at'] = date('Y-m-d H:i:s');
        $filtered['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->insert($this->table, $filtered);
    }

    /**
     * Met à jour un enregistrement
     */
    public function update(int $id, array $data): int {
        $filtered = array_intersect_key($data, array_flip($this->fillable));
        $filtered['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->update(
            $this->table,
            $filtered,
            "{$this->primaryKey} = :id",
            ['id' => $id]
        );
    }

    /**
     * Supprime un enregistrement
     */
    public function delete(int $id): int {
        return $this->db->delete($this->table, "{$this->primaryKey} = :id", ['id' => $id]);
    }

    /**
     * Compte les enregistrements
     */
    public function count(string $where = '1=1', array $params = []): int {
        return $this->db->count($this->table, $where, $params);
    }

    /**
     * Pagination
     */
    public function paginate(int $page = 1, int $perPage = 10, string $orderBy = 'id', string $direction = 'DESC'): array {
        $total = $this->count();
        $pag = \paginate($total, $page, $perPage);
        $sql = "SELECT * FROM {$this->table} ORDER BY {$orderBy} {$direction} LIMIT {$pag['per_page']} OFFSET {$pag['offset']}";
        $items = $this->db->fetchAll($sql);
        return ['items' => $items, 'pagination' => $pag];
    }

    /**
     * Récupère les attributs
     */
    public function getAttributes(): ?array {
        return $this->attributes;
    }

    /**
     * Magic getter
     */
    public function __get(string $name) {
        return $this->attributes[$name] ?? null;
    }

    /**
     * Magic setter
     */
    public function __set(string $name, $value): void {
        if ($this->attributes === null) {
            $this->attributes = [];
        }
        $this->attributes[$name] = $value;
    }
}

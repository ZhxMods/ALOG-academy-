<?php
namespace App\Core;

/**
 * ALOG ACADEMY - Router MVC Léger
 * Gère les routes GET/POST avec paramètres et middleware
 */
class Router {
    private array $routes = [];
    private array $middlewares = [];
    private string $prefix = '';

    /**
     * Enregistre une route GET
     */
    public function get(string $path, $handler, string $name = ''): self {
        return $this->addRoute('GET', $path, $handler, $name);
    }

    /**
     * Enregistre une route POST
     */
    public function post(string $path, $handler, string $name = ''): self {
        return $this->addRoute('POST', $path, $handler, $name);
    }

    /**
     * Enregistre une route (toute méthode)
     */
    public function any(string $path, $handler, string $name = ''): self {
        return $this->addRoute('GET|POST', $path, $handler, $name);
    }

    /**
     * Groupe de routes avec préfixe
     */
    public function group(string $prefix, callable $callback): void {
        $oldPrefix = $this->prefix;
        $this->prefix .= rtrim($prefix, '/');
        $callback($this);
        $this->prefix = $oldPrefix;
    }

    /**
     * Middleware pour les routes suivantes
     */
    public function middleware(array $middlewares): self {
        $this->middlewares = $middlewares;
        return $this;
    }

    private function addRoute(string $method, string $path, $handler, string $name = ''): self {
        $fullPath = $this->prefix . '/' . trim($path, '/');
        $fullPath = $fullPath === '/' ? '/' : rtrim($fullPath, '/');

        $this->routes[] = [
            'method' => $method,
            'path' => $fullPath,
            'handler' => $handler,
            'name' => $name,
            'middlewares' => $this->middlewares,
        ];

        // Reset middlewares après utilisation
        $this->middlewares = [];

        return $this;
    }

    /**
     * Dispatch la requête vers le bon handler
     */
    public function dispatch(): void {
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $uri = str_replace(dirname($_SERVER['SCRIPT_NAME']) ?: '', '', $uri);
        $uri = '/' . ltrim($uri, '/');
        $uri = rtrim($uri, '/') ?: '/';

        // Supprimer le préfixe /public si présent
        $uri = preg_replace('#^/public#', '', $uri);
        $uri = $uri ?: '/';

        $method = $_SERVER['REQUEST_METHOD'];

        foreach ($this->routes as $route) {
            if (!$this->methodMatches($route['method'], $method)) {
                continue;
            }

            $pattern = $this->convertToRegex($route['path']);

            if (preg_match($pattern, $uri, $matches)) {
                // Extraction des paramètres nommés
                $params = [];
                foreach ($matches as $key => $value) {
                    if (is_string($key)) {
                        $params[$key] = $value;
                    }
                }

                // Exécution des middlewares
                foreach ($route['middlewares'] as $middleware) {
                    $this->runMiddleware($middleware);
                }

                // Exécution du handler
                $this->runHandler($route['handler'], $params);
                return;
            }
        }

        // Route non trouvée
        http_response_code(404);
        View::render('errors/404', ['title' => 'Page non trouvée']);
    }

    private function methodMatches(string $routeMethod, string $requestMethod): bool {
        return strpos($routeMethod, $requestMethod) !== false;
    }

    private function convertToRegex(string $path): string {
        // Convertit les paramètres {param} en regex
        $pattern = preg_replace('/\{(\w+)\}/', '(?P<$1>[^/]+)', $path);
        return '#^' . $pattern . '$#';
    }

    private function runMiddleware(string $middleware): void {
        $middlewareClass = "App\\Middleware\\" . ucfirst($middleware) . "Middleware";
        if (class_exists($middlewareClass)) {
            $instance = new $middlewareClass();
            if (method_exists($instance, 'handle')) {
                $instance->handle();
            }
        } else {
            // Middleware inline
            switch ($middleware) {
                case 'auth':
                    if (!is_logged_in()) {
                        flash('error', 'Veuillez vous connecter pour accéder à cette page.');
                        redirect('/login');
                    }
                    break;
                case 'guest':
                    if (is_logged_in()) {
                        redirect(is_admin() ? '/admin/dashboard' : '/dashboard');
                    }
                    break;
                case 'admin':
                    if (!is_logged_in() || !is_admin()) {
                        http_response_code(403);
                        View::render('errors/403', ['title' => 'Accès interdit']);
                        exit;
                    }
                    break;
                case 'superadmin':
                    if (!is_logged_in() || !is_super_admin()) {
                        http_response_code(403);
                        View::render('errors/403', ['title' => 'Accès interdit']);
                        exit;
                    }
                    break;
                case 'csrf':
                    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !verify_csrf()) {
                        http_response_code(419);
                        die('Session expirée. Veuillez rafraîchir la page.');
                    }
                    break;
            }
        }
    }

    private function runHandler($handler, array $params): void {
        if (is_callable($handler)) {
            call_user_func_array($handler, $params);
            return;
        }

        if (is_string($handler) && strpos($handler, '@') !== false) {
            [$controller, $method] = explode('@', $handler);
            $controllerClass = "App\\Controllers\\" . $controller;
            if (class_exists($controllerClass)) {
                $instance = new $controllerClass();
                if (method_exists($instance, $method)) {
                    call_user_func_array([$instance, $method], $params);
                    return;
                }
            }
        }

        if (is_array($handler) && count($handler) === 2) {
            [$controller, $method] = $handler;
            $controllerClass = is_string($controller) ? "App\\Controllers\\" . $controller : $controller;
            $instance = is_string($controllerClass) ? new $controllerClass() : $controller;
            if (method_exists($instance, $method)) {
                call_user_func_array([$instance, $method], $params);
                return;
            }
        }

        throw new \Exception("Handler invalide");
    }
}

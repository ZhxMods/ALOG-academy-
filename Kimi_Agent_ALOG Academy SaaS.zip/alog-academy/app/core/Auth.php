<?php
namespace App\Core;

use App\Models\User;

/**
 * ALOG ACADEMY - Système d'authentification
 * Gestion des sessions, connexion, inscription, sécurité
 */
class Auth {
    private Database $db;
    private static ?self $instance = null;

    private function __construct() {
        $this->db = Database::getInstance();
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Inscription d'un utilisateur
     */
    public function register(array $data): array {
        $errors = [];

        // Validation
        if (empty($data['fullname']) || strlen($data['fullname']) < 3) {
            $errors['fullname'] = 'Le nom complet doit contenir au moins 3 caractères.';
        }

        if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Adresse email invalide.';
        }

        if (empty($data['password']) || strlen($data['password']) < 6) {
            $errors['password'] = 'Le mot de passe doit contenir au moins 6 caractères.';
        }

        if ($data['password'] !== ($data['password_confirm'] ?? '')) {
            $errors['password_confirm'] = 'Les mots de passe ne correspondent pas.';
        }

        // Vérifier si l'email existe déjà
        $existing = $this->db->fetch(
            "SELECT id FROM users WHERE email = :email LIMIT 1",
            ['email' => $data['email']]
        );
        if ($existing) {
            $errors['email'] = 'Cette adresse email est déjà utilisée.';
        }

        if (!empty($errors)) {
            return ['success' => false, 'errors' => $errors];
        }

        // Créer l'utilisateur
        $userId = $this->db->insert('users', [
            'fullname' => htmlspecialchars(trim($data['fullname'])),
            'email' => strtolower(trim($data['email'])),
            'password' => password_hash($data['password'], PASSWORD_BCRYPT),
            'role' => ROLE_STUDENT,
            'plan' => PLAN_FREE,
            'xp_total' => 0,
            'level' => 1,
            'region' => $data['region'] ?? 'inconnu',
            'email_verified' => 0,
            'status' => 'active',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        // Logger l'inscription
        log_error("New user registered: {$data['email']} (ID: {$userId})");

        return ['success' => true, 'user_id' => $userId];
    }

    /**
     * Connexion
     */
    public function login(string $email, string $password): array {
        $errors = [];

        // Vérifier les tentatives de connexion
        $attempts = $this->getLoginAttempts($email);
        if ($attempts >= MAX_LOGIN_ATTEMPTS) {
            return [
                'success' => false,
                'errors' => ['Trop de tentatives. Veuillez réessayer dans 15 minutes.']
            ];
        }

        // Récupérer l'utilisateur
        $user = $this->db->fetch(
            "SELECT * FROM users WHERE email = :email LIMIT 1",
            ['email' => strtolower(trim($email))]
        );

        if (!$user || !password_verify($password, $user['password'])) {
            $this->incrementLoginAttempts($email);
            return [
                'success' => false,
                'errors' => ['Email ou mot de passe incorrect.']
            ];
        }

        // Vérifier le statut
        if ($user['status'] !== 'active') {
            return [
                'success' => false,
                'errors' => ['Votre compte a été désactivé. Contactez l\'administration.']
            ];
        }

        // Réinitialiser les tentatives
        $this->resetLoginAttempts($email);

        // Créer la session
        $this->createSession($user);

        // Bonus de connexion quotidienne
        $this->checkDailyLoginBonus($user['id']);

        // Mettre à jour last_login
        $this->db->update('users', ['last_login' => date('Y-m-d H:i:s')], 'id = :id', ['id' => $user['id']]);

        return ['success' => true, 'user' => $user];
    }

    /**
     * Déconnexion
     */
    public function logout(): void {
        // Supprimer le token remember_me s'il existe
        if (isset($_COOKIE['remember_me'])) {
            $this->db->delete('remember_tokens', 'token = :token', ['token' => $_COOKIE['remember_me']]);
            setcookie('remember_me', '', [
                'expires' => time() - 3600,
                'path' => '/',
                'httponly' => true,
                'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                'samesite' => 'Lax'
            ]);
        }

        session_destroy();
        $_SESSION = [];
    }

    /**
     * Crée une session utilisateur
     */
    public function createSession(array $user): void {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'fullname' => $user['fullname'],
            'email' => $user['email'],
            'role' => $user['role'],
            'plan' => $user['plan'],
            'xp_total' => $user['xp_total'],
            'level' => $user['level'],
            'avatar' => $user['avatar'] ?? null,
            'region' => $user['region'] ?? 'inconnu',
        ];
    }

    /**
     * Mot de passe oublié
     */
    public function forgotPassword(string $email): array {
        $user = $this->db->fetch(
            "SELECT id, fullname, email FROM users WHERE email = :email LIMIT 1",
            ['email' => strtolower(trim($email))]
        );

        if (!$user) {
            return ['success' => false, 'errors' => ['Aucun compte trouvé avec cet email.']];
        }

        // Générer un token
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

        // Supprimer les anciens tokens
        $this->db->delete('password_resets', 'email = :email', ['email' => $user['email']]);

        // Créer le nouveau token
        $this->db->insert('password_resets', [
            'email' => $user['email'],
            'token' => hash('sha256', $token),
            'expires_at' => $expires,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // TODO: Envoyer l'email avec le lien de réinitialisation
        // Pour l'instant, on retourne le token pour test
        return [
            'success' => true,
            'message' => 'Un lien de réinitialisation a été envoyé à votre email.',
            'token' => $token // Retirer en production
        ];
    }

    /**
     * Réinitialisation du mot de passe
     */
    public function resetPassword(string $token, string $newPassword): array {
        $hashedToken = hash('sha256', $token);

        $reset = $this->db->fetch(
            "SELECT * FROM password_resets WHERE token = :token AND expires_at > NOW() LIMIT 1",
            ['token' => $hashedToken]
        );

        if (!$reset) {
            return ['success' => false, 'errors' => ['Token invalide ou expiré.']];
        }

        if (strlen($newPassword) < 6) {
            return ['success' => false, 'errors' => ['Le mot de passe doit contenir au moins 6 caractères.']];
        }

        // Mettre à jour le mot de passe
        $this->db->update(
            'users',
            ['password' => password_hash($newPassword, PASSWORD_BCRYPT), 'updated_at' => date('Y-m-d H:i:s')],
            'email = :email',
            ['email' => $reset['email']]
        );

        // Supprimer le token
        $this->db->delete('password_resets', 'token = :token', ['token' => $hashedToken]);

        return ['success' => true, 'message' => 'Mot de passe réinitialisé avec succès.'];
    }

    /**
     * Vérifie si l'utilisateur est connecté
     */
    public function check(): bool {
        if (isset($_SESSION['user']) && !empty($_SESSION['user']['id'])) {
            return true;
        }

        // Vérifier le remember_me cookie
        if (isset($_COOKIE['remember_me'])) {
            return $this->checkRememberToken($_COOKIE['remember_me']);
        }

        return false;
    }

    /**
     * Utilisateur connecté
     */
    public function user(): ?array {
        return $_SESSION['user'] ?? null;
    }

    /**
     * Vérifie le token remember_me
     */
    private function checkRememberToken(string $token): bool {
        $stored = $this->db->fetch(
            "SELECT rt.*, u.* FROM remember_tokens rt 
             JOIN users u ON rt.user_id = u.id 
             WHERE rt.token = :token AND rt.expires_at > NOW() LIMIT 1",
            ['token' => hash('sha256', $token)]
        );

        if ($stored) {
            $this->createSession($stored);
            return true;
        }

        // Cookie invalide, le supprimer
        setcookie('remember_me', '', [
            'expires' => time() - 3600,
            'path' => '/',
            'httponly' => true,
            'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
            'samesite' => 'Lax'
        ]);

        return false;
    }

    /**
     * Crée un token remember_me
     */
    public function createRememberToken(int $userId): void {
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+30 days'));

        $this->db->insert('remember_tokens', [
            'user_id' => $userId,
            'token' => hash('sha256', $token),
            'expires_at' => $expires,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        setcookie('remember_me', $token, [
            'expires' => time() + (30 * 24 * 60 * 60),
            'path' => '/',
            'httponly' => true,
            'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
            'samesite' => 'Lax'
        ]);
    }

    /**
     * Gestion des tentatives de connexion (rate limiting)
     */
    private function getLoginAttempts(string $email): int {
        $key = 'login_attempts_' . md5($email);
        $attempts = $this->db->fetch(
            "SELECT attempts FROM login_attempts WHERE identifier = :id AND expires_at > NOW() LIMIT 1",
            ['id' => $key]
        );
        return $attempts ? (int)$attempts['attempts'] : 0;
    }

    private function incrementLoginAttempts(string $email): void {
        $key = 'login_attempts_' . md5($email);
        $existing = $this->db->fetch(
            "SELECT id FROM login_attempts WHERE identifier = :id LIMIT 1",
            ['id' => $key]
        );

        if ($existing) {
            $this->db->query(
                "UPDATE login_attempts SET attempts = attempts + 1, expires_at = DATE_ADD(NOW(), INTERVAL :cooldown SECOND) WHERE identifier = :id",
                ['cooldown' => LOGIN_COOLDOWN, 'id' => $key]
            );
        } else {
            $this->db->insert('login_attempts', [
                'identifier' => $key,
                'attempts' => 1,
                'expires_at' => date('Y-m-d H:i:s', time() + LOGIN_COOLDOWN),
            ]);
        }
    }

    private function resetLoginAttempts(string $email): void {
        $key = 'login_attempts_' . md5($email);
        $this->db->delete('login_attempts', 'identifier = :id', ['id' => $key]);
    }

    /**
     * Bonus de connexion quotidienne
     */
    private function checkDailyLoginBonus(int $userId): void {
        $today = date('Y-m-d');

        // Vérifier si déjà connecté aujourd'hui
        $alreadyLogged = $this->db->fetch(
            "SELECT id FROM xp_logs WHERE user_id = :uid AND source = 'daily_login' AND DATE(created_at) = :today LIMIT 1",
            ['uid' => $userId, 'today' => $today]
        );

        if (!$alreadyLogged) {
            // Ajouter l'XP
            $this->db->query(
                "UPDATE users SET xp_total = xp_total + :xp WHERE id = :id",
                ['xp' => XP_DAILY_LOGIN, 'id' => $userId]
            );

            // Logger l'XP
            $this->db->insert('xp_logs', [
                'user_id' => $userId,
                'amount' => XP_DAILY_LOGIN,
                'source' => 'daily_login',
                'description' => 'Bonus de connexion quotidienne',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            // Recalculer le niveau
            $newXp = $this->db->fetchColumn("SELECT xp_total FROM users WHERE id = :id", ['id' => $userId]);
            $newLevel = \xp_to_level((int)$newXp);
            $oldLevel = $this->db->fetchColumn("SELECT level FROM users WHERE id = :id", ['id' => $userId]);

            if ($newLevel > $oldLevel) {
                $this->db->update('users', ['level' => $newLevel], 'id = :id', ['id' => $userId]);

                // Notification level up
                $this->db->insert('notifications', [
                    'user_id' => $userId,
                    'type' => 'level_up',
                    'title' => 'Niveau supérieur !',
                    'message' => "Félicitations ! Vous avez atteint le niveau {$newLevel} : " . \level_name($newLevel),
                    'is_read' => 0,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }
        }
    }
}

<?php
namespace App\Core;

/**
 * ALOG ACADEMY - Classe de base Controller
 */
abstract class Controller {
    protected Database $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * Rend une vue
     */
    protected function view(string $view, array $data = []): void {
        View::render($view, $data);
    }

    /**
     * Rend une vue avec layout
     */
    protected function viewWithLayout(string $view, string $layout = 'main', array $data = []): void {
        View::renderWithLayout($view, $layout, $data);
    }

    /**
     * Réponse JSON (pour AJAX)
     */
    protected function json(array $data, int $status = 200): void {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data);
        exit;
    }

    /**
     * Redirection
     */
    protected function redirect(string $path): void {
        \redirect($path);
    }

    /**
     * Vérifie si la requête est AJAX
     */
    protected function isAjax(): bool {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    /**
     * Données POST validées
     */
    protected function validate(array $rules): array {
        $data = [];
        $errors = [];

        foreach ($rules as $field => $rule) {
            $value = $_POST[$field] ?? null;
            $ruleParts = explode('|', $rule);

            foreach ($ruleParts as $part) {
                if ($part === 'required' && (empty($value) || trim($value) === '')) {
                    $errors[$field] = "Ce champ est obligatoire.";
                    break;
                }
                if ($part === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors[$field] = "Adresse email invalide.";
                    break;
                }
                if (strpos($part, 'min:') === 0) {
                    $min = (int)substr($part, 4);
                    if (strlen($value) < $min) {
                        $errors[$field] = "Minimum {$min} caractères.";
                        break;
                    }
                }
                if (strpos($part, 'max:') === 0) {
                    $max = (int)substr($part, 4);
                    if (strlen($value) > $max) {
                        $errors[$field] = "Maximum {$max} caractères.";
                        break;
                    }
                }
                if ($part === 'numeric' && !is_numeric($value)) {
                    $errors[$field] = "Doit être un nombre.";
                    break;
                }
                if ($part === 'integer' && !filter_var($value, FILTER_VALIDATE_INT)) {
                    $errors[$field] = "Doit être un entier.";
                    break;
                }
                if ($part === 'url' && !filter_var($value, FILTER_VALIDATE_URL)) {
                    $errors[$field] = "URL invalide.";
                    break;
                }
                if ($part === 'match' && isset($_POST[$ruleParts[array_search('match', $ruleParts) + 1] ?? ''])) {
                    // Simplifié
                }
            }

            $data[$field] = $value;
        }

        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old'] = $_POST;
            return [];
        }

        return $data;
    }

    /**
     * Récupère les erreurs de validation
     */
    protected function getErrors(): array {
        $errors = $_SESSION['errors'] ?? [];
        unset($_SESSION['errors']);
        return $errors;
    }

    /**
     * Vérifie si des erreurs existent
     */
    protected function hasErrors(): bool {
        return !empty($_SESSION['errors']);
    }
}

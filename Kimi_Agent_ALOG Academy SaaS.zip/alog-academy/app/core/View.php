<?php
namespace App\Core;

/**
 * ALOG ACADEMY - View Renderer
 * Système de rendu de vues avec layouts
 */
class View {
    private static string $viewsPath = APP_PATH . '/views/';
    private static string $layoutsPath = APP_PATH . '/views/layouts/';
    private static string $partialsPath = APP_PATH . '/views/partials/';

    /**
     * Rend une vue simple
     */
    public static function render(string $view, array $data = []): void {
        extract($data);
        $viewFile = self::$viewsPath . str_replace('.', '/', $view) . '.php';

        if (!file_exists($viewFile)) {
            throw new \Exception("Vue introuvable: {$view}");
        }

        require $viewFile;
    }

    /**
     * Rend une vue avec layout
     */
    public static function renderWithLayout(string $view, string $layout = 'main', array $data = []): void {
        extract($data);

        // Capture le contenu de la vue
        ob_start();
        $viewFile = self::$viewsPath . str_replace('.', '/', $view) . '.php';

        if (!file_exists($viewFile)) {
            throw new \Exception("Vue introuvable: {$view}");
        }

        require $viewFile;
        $content = ob_get_clean();

        // Rend le layout avec le contenu
        $layoutFile = self::$layoutsPath . $layout . '.php';
        if (!file_exists($layoutFile)) {
            // Fallback vers le layout main
            $layoutFile = self::$layoutsPath . 'main.php';
        }

        require $layoutFile;
    }

    /**
     * Rend un partial
     */
    public static function partial(string $partial, array $data = []): void {
        extract($data);
        $partialFile = self::$partialsPath . str_replace('.', '/', $partial) . '.php';

        if (file_exists($partialFile)) {
            require $partialFile;
        }
    }

    /**
     * Définit le chemin des vues
     */
    public static function setViewsPath(string $path): void {
        self::$viewsPath = rtrim($path, '/') . '/';
    }
}

/**
 * ALOG ACADEMY - Admin JavaScript
 */

(function() {
    'use strict';

    // Sidebar toggle collapse
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('adminSidebar');

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
        });
    }

    // Active nav link
    const currentPath = window.location.pathname;
    document.querySelectorAll('.admin-sidebar .nav-link').forEach(function(link) {
        if (link.getAttribute('href') && currentPath.startsWith(link.getAttribute('href'))) {
            link.classList.add('active');
        }
    });
})();

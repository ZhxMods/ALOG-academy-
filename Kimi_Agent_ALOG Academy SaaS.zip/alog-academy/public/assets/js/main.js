/**
 * ALOG ACADEMY - JavaScript principal
 * Mode sombre, navigation, interactions
 */

(function() {
    'use strict';

    // ===== DARK MODE =====
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = document.getElementById('themeIcon');
    const html = document.documentElement;

    function getTheme() {
        return localStorage.getItem('alog-theme') || 'light';
    }

    function setTheme(theme) {
        localStorage.setItem('alog-theme', theme);
        html.setAttribute('data-bs-theme', theme);
        if (themeIcon) {
            themeIcon.className = theme === 'dark' ? 'bi bi-moon-stars-fill' : 'bi bi-sun-fill';
        }
    }

    // Init theme
    setTheme(getTheme());

    if (themeToggle) {
        themeToggle.addEventListener('click', function(e) {
            e.preventDefault();
            const current = getTheme();
            const next = current === 'dark' ? 'light' : 'dark';
            setTheme(next);
        });
    }

    // ===== TOGGLE PASSWORD =====
    document.querySelectorAll('.toggle-password').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const input = this.closest('.input-group').querySelector('input');
            const icon = this.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            }
        });
    });

    // ===== MOBILE SIDEBAR =====
    const sidebarToggle = document.getElementById('sidebarToggle');
    const studentSidebar = document.getElementById('studentSidebar');
    const adminSidebar = document.getElementById('adminSidebar');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            const sidebar = studentSidebar || adminSidebar;
            if (sidebar) {
                sidebar.classList.toggle('show');
            }
        });
    }

    // ===== AUTO DISMISS ALERTS =====
    document.querySelectorAll('.alert').forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 5000);
    });

    // ===== SMOOTH SCROLL =====
    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
        anchor.addEventListener('click', function(e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

    // ===== CONFIRM DELETE =====
    document.querySelectorAll('form[onsubmit*="confirm"]').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            if (!confirm('Êtes-vous sûr ?')) {
                e.preventDefault();
            }
        });
    });

    console.log('ALOG Academy loaded successfully');
})();

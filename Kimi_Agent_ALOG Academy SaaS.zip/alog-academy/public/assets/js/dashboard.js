/**
 * ALOG ACADEMY - Dashboard JavaScript
 */

(function() {
    'use strict';

    // Active sidebar link
    const currentPath = window.location.pathname;
    document.querySelectorAll('.sidebar-nav .nav-link').forEach(function(link) {
        if (link.getAttribute('href') && currentPath.startsWith(link.getAttribute('href'))) {
            link.classList.add('active');
        }
    });
})();

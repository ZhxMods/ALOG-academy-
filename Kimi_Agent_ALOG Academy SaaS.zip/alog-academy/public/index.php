<?php
/**
 * ALOG ACADEMY - Point d'entrée principal
 * Router frontal qui redirige vers le contrôleur approprié
 */

// Error reporting (disable in production)
if (getenv('APP_ENV') === 'development' || (defined('APP_ENV') && APP_ENV === 'development')) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Autoloader
spl_autoload_register(function ($class) {
    $prefixes = [
        'App\\\\Core\\\\' => __DIR__ . '/../app/core/',
        'App\\\\Models\\\\' => __DIR__ . '/../app/models/',
        'App\\\\Controllers\\\\' => __DIR__ . '/../app/controllers/',
        'App\\\\Helpers\\\\' => __DIR__ . '/../app/helpers/',
    ];

    foreach ($prefixes as $prefix => $baseDir) {
        $len = strlen($prefix);
        if (strncmp($prefix, $class . '\\', $len) === 0) {
            $relativeClass = substr($class, $len);
            $file = $baseDir . str_replace('\\\\', '/', $relativeClass) . '.php';
            if (file_exists($file)) {
                require $file;
                return;
            }
        }
    }
});

// Configurations
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

// Helper functions
require_once __DIR__ . '/../app/helpers/functions.php';

// Initialize Router
use App\Core\Router;
use App\Core\Database;
use App\Core\Auth;
use App\Core\View;

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Generate CSRF token if not exists
if (empty($_SESSION[CSRF_TOKEN_NAME])) {
    $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
}

// Initialize Database
Database::getInstance();

// Create Router and handle request
$router = new Router();

// Load routes
require_once __DIR__ . '/../routes/web.php';

// Dispatch
$router->dispatch();

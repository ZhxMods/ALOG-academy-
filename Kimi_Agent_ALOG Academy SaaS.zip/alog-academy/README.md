# ALOG ACADEMY (MAROC)

Plateforme éducative gamifiée SaaS pour étudiants marocains.

---

## STACK TECHNIQUE

- **Backend:** PHP 8+ (MVC personnalisé)
- **Base de données:** MySQL 8+ (PDO)
- **Frontend:** HTML5, CSS3, Bootstrap 5, Vanilla JavaScript
- **Architecture:** MVC léger optimisé free hosting

---

## ARCHITECTURE MVC

```
alog-academy/
├── app/
│   ├── controllers/     # Contrôleurs (Auth, Student, Admin, Home)
│   ├── models/          # Modèles (User, Lesson, Quiz, XP, etc.)
│   ├── views/           # Vues
│   │   ├── layouts/     # Layouts (main, auth, student, admin)
│   │   ├── partials/    # Partials (navbar, sidebar, footer)
│   │   ├── auth/        # Pages auth (login, register, forgot)
│   │   ├── public/      # Pages publiques (home, about, pricing, blog)
│   │   ├── student/     # Dashboard étudiant
│   │   └── admin/       # Dashboard admin
│   ├── core/            # Core (Router, Controller, Model, View, Auth, Database)
│   └── helpers/         # Fonctions globales
├── config/              # Configuration
├── routes/              # Définition des routes
├── database/            # Schéma SQL
├── public/              # Point d'entrée
│   └── assets/          # CSS, JS, images, uploads
└── storage/             # Logs, cache
```

---

## INSTALLATION

### 1. Upload des fichiers

Uploadez tous les fichiers sur votre hébergement (AeonFree, etc.).

### 2. Créer la base de données

1. Créez une base de données MySQL via le panel de votre hébergement
2. Importez le fichier `database/schema.sql` via phpMyAdmin

### 3. Configuration

Créez un fichier `.env` à la racine ou modifiez `config/database.php`:

```php
// Pour AeonFree, utilisez les variables d'environnement
define('DB_HOST', 'localhost');
define('DB_NAME', 'votre_db');
define('DB_USER', 'votre_user');
define('DB_PASS', 'votre_password');
```

Ou configurez via les variables d'environnement de votre hébergement.

### 4. Permissions

Assurez-vous que ces dossiers sont accessibles en écriture:
```bash
chmod 755 storage/
chmod 755 storage/logs/
chmod 755 storage/cache/
chmod 755 public/assets/uploads/
chmod 755 public/assets/uploads/avatars/
chmod 755 public/assets/uploads/payments/
```

### 5. URL rewriting

Le fichier `.htaccess` est déjà configuré dans `public/`. 
Pour AeonFree, assurez-vous que le mod_rewrite est activé.

---

## COMPTE ADMIN PAR DÉFAUT

Après l'import de la base de données, créez un admin via phpMyAdmin:

```sql
INSERT INTO users (fullname, email, password, role, plan, xp_total, level, status, created_at) 
VALUES ('Admin', 'admin@alogacademy.ma', '$2y$10$VotreHash', 'super_admin', 'ULTRA', 0, 1, 'active', NOW());
```

Générez un hash de mot de passe via PHP:
```php
echo password_hash('votre_mot_de_passe', PASSWORD_BCRYPT);
```

---

## FONCTIONNALITÉS

### Étudiant
- Inscription / Connexion sécurisée
- Dashboard avec progression XP
- Cours par niveau (Collège → Supérieur)
- Leçons avec vidéos YouTube, PDF, exercices
- Quiz interactifs (QCM, Vrai/Faux) avec correction
- Système XP avec niveaux et badges
- Classement global et régional
- Abonnements (FREE, PRO, ULTRA)
- Paiement par WhatsApp
- Réservations de cours
- Notifications en temps réel
- Blog éducatif
- Mode sombre/clair
- Profil personnalisable

### Admin
- Dashboard analytics
- Gestion des utilisateurs
- Gestion des niveaux, matières, leçons
- Gestion des quiz et questions
- Validation des paiements
- Gestion des réservations
- Gestion du blog
- Classements et statistiques
- Annonces
- Paramètres du site

---

## SÉCURITÉ

- Protection CSRF sur tous les formulaires
- Password hashing avec bcrypt
- PDO prepared statements
- Protection XSS
- Rate limiting sur la connexion
- Session sécurisée (httponly, secure)
- Upload validation

---

## LICENCE

Propriétaire - ALOG Academy Maroc

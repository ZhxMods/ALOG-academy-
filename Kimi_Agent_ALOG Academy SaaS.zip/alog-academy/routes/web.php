<?php
/**
 * ALOG ACADEMY - Routes
 * Toutes les routes de l'application
 */

use App\Core\Router;

/** @var Router $router */

// ==================== PUBLIC ROUTES ====================

$router->get('/', [App\Controllers\HomeController::class, 'index'], 'home');
$router->get('/about', [App\Controllers\HomeController::class, 'about'], 'about');
$router->get('/pricing', [App\Controllers\HomeController::class, 'pricing'], 'pricing');
$router->get('/contact', [App\Controllers\HomeController::class, 'contact'], 'contact');
$router->post('/contact', [App\Controllers\HomeController::class, 'sendContact']);
$router->get('/search', [App\Controllers\HomeController::class, 'search'], 'search');

// Blog (public)
$router->get('/blog', [App\Controllers\StudentController::class, 'blog'], 'blog');
$router->get('/blog/{slug}', [App\Controllers\StudentController::class, 'blogPost'], 'blog-post');

// Auth (guest only)
$router->group('', function($router) {
    $router->middleware(['guest']);
    $router->get('/login', [App\Controllers\AuthController::class, 'loginForm'], 'login');
    $router->post('/login', [App\Controllers\AuthController::class, 'login']);
    $router->get('/register', [App\Controllers\AuthController::class, 'registerForm'], 'register');
    $router->post('/register', [App\Controllers\AuthController::class, 'register']);
    $router->get('/forgot-password', [App\Controllers\AuthController::class, 'forgotForm'], 'forgot');
    $router->post('/forgot-password', [App\Controllers\AuthController::class, 'forgot']);
    $router->get('/reset-password/{token}', [App\Controllers\AuthController::class, 'resetForm'], 'reset');
    $router->post('/reset-password', [App\Controllers\AuthController::class, 'reset']);
});

// Logout
$router->get('/logout', [App\Controllers\AuthController::class, 'logout'], 'logout');

// ==================== STUDENT ROUTES (auth required) ====================

$router->group('', function($router) {
    $router->middleware(['auth']);

    // Dashboard
    $router->get('/dashboard', [App\Controllers\StudentController::class, 'dashboard'], 'dashboard');

    // Lessons
    $router->get('/levels', [App\Controllers\StudentController::class, 'levels'], 'levels');
    $router->get('/levels/{slug}', [App\Controllers\StudentController::class, 'subjects'], 'subjects');
    $router->get('/subjects/{slug}', [App\Controllers\StudentController::class, 'lessons'], 'lessons');
    $router->get('/lesson/{slug}', [App\Controllers\StudentController::class, 'lesson'], 'lesson');
    $router->post('/lesson/{id}/complete', [App\Controllers\StudentController::class, 'completeLesson'], 'complete-lesson');
    $router->post('/lesson/{id}/comment', [App\Controllers\StudentController::class, 'addComment'], 'add-comment');

    // Quizzes
    $router->get('/quizzes', [App\Controllers\StudentController::class, 'quizzes'], 'quizzes');
    $router->get('/quiz/{slug}', [App\Controllers\StudentController::class, 'quiz'], 'quiz');
    $router->post('/quiz/{id}/submit', [App\Controllers\StudentController::class, 'submitQuiz'], 'submit-quiz');
    $router->get('/quiz-result/{id}', [App\Controllers\StudentController::class, 'quizResult'], 'quiz-result');

    // Rankings
    $router->get('/rankings', [App\Controllers\StudentController::class, 'rankings'], 'rankings');

    // Profile
    $router->get('/profile', [App\Controllers\StudentController::class, 'profile'], 'profile');
    $router->post('/profile/update', [App\Controllers\StudentController::class, 'updateProfile'], 'update-profile');

    // Subscriptions
    $router->get('/subscriptions', [App\Controllers\StudentController::class, 'subscriptions'], 'subscriptions');
    $router->post('/subscribe', [App\Controllers\StudentController::class, 'subscribe'], 'subscribe');

    // Bookings
    $router->get('/bookings', [App\Controllers\StudentController::class, 'bookings'], 'bookings');
    $router->post('/bookings/create', [App\Controllers\StudentController::class, 'createBooking'], 'create-booking');
    $router->post('/bookings/{id}/cancel', [App\Controllers\StudentController::class, 'cancelBooking'], 'cancel-booking');

    // Notifications
    $router->get('/notifications', [App\Controllers\StudentController::class, 'notifications'], 'notifications');
    $router->post('/notifications/{id}/read', [App\Controllers\StudentController::class, 'markNotificationRead'], 'mark-notification-read');

    // XP History
    $router->get('/xp-history', [App\Controllers\StudentController::class, 'xpHistory'], 'xp-history');
});

// ==================== ADMIN ROUTES ====================

$router->group('/admin', function($router) {
    $router->middleware(['admin']);

    // Dashboard
    $router->get('/dashboard', [App\Controllers\AdminController::class, 'dashboard'], 'admin-dashboard');

    // Users
    $router->get('/users', [App\Controllers\AdminController::class, 'users'], 'admin-users');
    $router->get('/users/{id}', [App\Controllers\AdminController::class, 'userDetail'], 'admin-user-detail');
    $router->post('/users/{id}/update', [App\Controllers\AdminController::class, 'updateUser'], 'admin-update-user');
    $router->post('/users/{id}/delete', [App\Controllers\AdminController::class, 'deleteUser'], 'admin-delete-user');

    // Levels
    $router->get('/levels', [App\Controllers\AdminController::class, 'levels'], 'admin-levels');
    $router->post('/levels/create', [App\Controllers\AdminController::class, 'createLevel'], 'admin-create-level');
    $router->post('/levels/{id}/update', [App\Controllers\AdminController::class, 'updateLevel'], 'admin-update-level');

    // Subjects
    $router->get('/subjects', [App\Controllers\AdminController::class, 'subjects'], 'admin-subjects');
    $router->post('/subjects/create', [App\Controllers\AdminController::class, 'createSubject'], 'admin-create-subject');
    $router->post('/subjects/{id}/update', [App\Controllers\AdminController::class, 'updateSubject'], 'admin-update-subject');

    // Lessons
    $router->get('/lessons', [App\Controllers\AdminController::class, 'lessons'], 'admin-lessons');
    $router->post('/lessons/create', [App\Controllers\AdminController::class, 'createLesson'], 'admin-create-lesson');
    $router->post('/lessons/{id}/update', [App\Controllers\AdminController::class, 'updateLesson'], 'admin-update-lesson');
    $router->post('/lessons/{id}/delete', [App\Controllers\AdminController::class, 'deleteLesson'], 'admin-delete-lesson');

    // Quizzes
    $router->get('/quizzes', [App\Controllers\AdminController::class, 'quizzes'], 'admin-quizzes');
    $router->post('/quizzes/create', [App\Controllers\AdminController::class, 'createQuiz'], 'admin-create-quiz');
    $router->post('/quizzes/{id}/update', [App\Controllers\AdminController::class, 'updateQuiz'], 'admin-update-quiz');
    $router->post('/quizzes/{id}/delete', [App\Controllers\AdminController::class, 'deleteQuiz'], 'admin-delete-quiz');

    // Payments
    $router->get('/payments', [App\Controllers\AdminController::class, 'payments'], 'admin-payments');
    $router->post('/payments/{id}/approve', [App\Controllers\AdminController::class, 'approvePayment'], 'admin-approve-payment');
    $router->post('/payments/{id}/reject', [App\Controllers\AdminController::class, 'rejectPayment'], 'admin-reject-payment');

    // Bookings
    $router->get('/bookings', [App\Controllers\AdminController::class, 'bookings'], 'admin-bookings');
    $router->post('/bookings/{id}/approve', [App\Controllers\AdminController::class, 'approveBooking'], 'admin-approve-booking');
    $router->post('/bookings/{id}/reject', [App\Controllers\AdminController::class, 'rejectBooking'], 'admin-reject-booking');
    $router->post('/bookings/{id}/complete', [App\Controllers\AdminController::class, 'completeBooking'], 'admin-complete-booking');

    // Blog
    $router->get('/blog', [App\Controllers\AdminController::class, 'blogPosts'], 'admin-blog');
    $router->post('/blog/create', [App\Controllers\AdminController::class, 'createBlogPost'], 'admin-create-blog');
    $router->post('/blog/{id}/update', [App\Controllers\AdminController::class, 'updateBlogPost'], 'admin-update-blog');
    $router->post('/blog/{id}/delete', [App\Controllers\AdminController::class, 'deleteBlogPost'], 'admin-delete-blog');

    // Rankings
    $router->get('/rankings', [App\Controllers\AdminController::class, 'rankings'], 'admin-rankings');

    // Announcements
    $router->get('/announcements', [App\Controllers\AdminController::class, 'announcements'], 'admin-announcements');
    $router->post('/announcements/create', [App\Controllers\AdminController::class, 'createAnnouncement'], 'admin-create-announcement');
    $router->post('/announcements/{id}/delete', [App\Controllers\AdminController::class, 'deleteAnnouncement'], 'admin-delete-announcement');

    // Analytics
    $router->get('/analytics', [App\Controllers\AdminController::class, 'analytics'], 'admin-analytics');

    // Settings
    $router->get('/settings', [App\Controllers\AdminController::class, 'settings'], 'admin-settings');
    $router->post('/settings/update', [App\Controllers\AdminController::class, 'updateSettings'], 'admin-update-settings');
});

return $router;

<?php
/**
 * Sitemap XML dynamique - ALOG ACADEMY
 * Placez ce fichier a la racine /public/ ou renommez en sitemap.php
 */

header('Content-Type: application/xml; charset=utf-8');

echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>https://votredomaine.aeonfree.com/</loc>
        <priority>1.0</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc>https://votredomaine.aeonfree.com/a-propos</loc>
        <priority>0.8</priority>
    </url>
    <url>
        <loc>https://votredomaine.aeonfree.com/services</loc>
        <priority>0.8</priority>
    </url>
    <url>
        <loc>https://votredomaine.aeonfree.com/tarifs</loc>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>https://votredomaine.aeonfree.com/blog</loc>
        <priority>0.8</priority>
    </url>
    <url>
        <loc>https://votredomaine.aeonfree.com/faq</loc>
        <priority>0.7</priority>
    </url>
    <url>
        <loc>https://votredomaine.aeonfree.com/contact</loc>
        <priority>0.7</priority>
    </url>
    <url>
        <loc>https://votredomaine.aeonfree.com/login</loc>
        <priority>0.5</priority>
    </url>
    <url>
        <loc>https://votredomaine.aeonfree.com/inscription</loc>
        <priority>0.5</priority>
    </url>
</urlset>

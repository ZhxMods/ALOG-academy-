/* ALOG ACADEMY - Admin JavaScript */

document.addEventListener('DOMContentLoaded', function() {
    // Auto-dismiss alerts
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const closeBtn = alert.querySelector('.btn-close');
            if (closeBtn) {
                closeBtn.click();
            }
        }, 5000);
    });

    // Mobile sidebar toggle
    const sidebarToggle = document.querySelector('[data-bs-toggle="offcanvas"]');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            const offcanvas = document.getElementById('adminSidebar');
            if (offcanvas) {
                const bsOffcanvas = new bootstrap.Offcanvas(offcanvas);
                bsOffcanvas.toggle();
            }
        });
    }
});

<?php
/**
 * Script d'installation - A executer une seule fois puis supprimer
 * Ce script cree le compte admin par defaut
 */

require __DIR__ . '/config/config.php';

echo "=== ALOG ACADEMY - Installation ===\n\n";

$db = App\Core\Database::getInstance();

// Verifier si un admin existe deja
$stmt = $db->query("SELECT COUNT(*) FROM admins");
$count = (int)$stmt->fetchColumn();

if ($count > 0) {
    echo "[INFO] Un compte admin existe deja.\n";
    echo "[INFO] Pour des raisons de securite, ce script doit etre supprime.\n";
    exit;
}

// Creer le super admin par defaut
$defaultEmail = 'admin@alog.ma';
$defaultPassword = 'Admin@2024!';
$hash = password_hash($defaultPassword, PASSWORD_ARGON2ID);

$stmt = $db->prepare("INSERT INTO admins (first_name, last_name, email, password_hash, role_id, status) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->execute(['Super', 'Admin', $defaultEmail, $hash, 3, 'active']);

echo "[SUCCESS] Compte admin cree avec succes !\n";
echo "Email: {$defaultEmail}\n";
echo "Mot de passe: {$defaultPassword}\n\n";
echo "[IMPORTANT] SUPPRIMEZ CE FICHIER (install.php) IMMEDIATEMENT !\n";
echo "[IMPORTANT] Changez le mot de passe apres la premiere connexion.\n";

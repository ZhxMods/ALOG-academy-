# ALOG ACADEMY

## Plateforme Educative pour Etudiants Marocains

ALOG ACADEMY est une plateforme d'apprentissage en ligne complete et legere, optimisee pour l'hebergement gratuit (AeonFree, InfinityFree, etc.).

---

## STACK TECHNIQUE

- **PHP 8+** avec architecture MVC legere
- **MySQL** via PDO avec prepared statements
- **Bootstrap 5** CDN pour le frontend responsive
- **Vanilla JavaScript** uniquement
- **Bootstrap Icons** pour les icones
- **Google Fonts (Inter)** pour la typographie

---

## ARCHITECTURE MVC

```
alog_academy/
├── app/
│   ├── controllers/       # Controleurs (Auth, Student, Admin, Public)
│   ├── models/              # Modeles (User, Lesson, Quiz, etc.)
│   ├── views/               # Vues (layouts, partials, pages)
│   │   ├── layouts/
│   │   ├── partials/
│   │   ├── auth/
│   │   ├── student/
│   │   ├── admin/
│   │   ├── public/
│   │   └── errors/
│   ├── core/                # Classes MVC (Router, BaseController, BaseModel, Database)
│   └── helpers/             # Helpers (Session, Validation, Security, Middleware)
├── config/
│   ├── config.php           # Configuration principale
│   └── autoload.php         # Autoloader PSR-4
├── public/
│   ├── assets/
│   │   ├── css/             # alog.css, admin.css
│   │   ├── js/              # alog.js, admin.js
│   │   └── images/
│   ├── uploads/             # Fichiers uploades (paiements, profils)
│   ├── index.php            # Point d'entree
│   ├── .htaccess            # Rewrite rules
│   ├── robots.txt           # SEO
│   └── sitemap.xml          # Plan du site
├── routes/
│   └── web.php              # Definition des routes
├── storage/
│   └── alog_academy_schema.sql  # Schema complet
└── .htaccess                # Redirection vers public/
```

---

## INSTALLATION

### 1. Base de donnees

1. Creez une base de donnees MySQL dans votre cPanel
2. Importez le fichier `storage/alog_academy_schema.sql` via phpMyAdmin
3. Le schema inclut toutes les tables, indexes, vues et donnees initiales (regions, roles)

### 2. Configuration

Modifiez `/config/config.php` :

```php
define('BASE_URL', 'https://votredomaine.aeonfree.com');
define('DB_HOST', 'localhost');
define('DB_NAME', 'votre_db');
define('DB_USER', 'votre_user');
define('DB_PASS', 'votre_password');
define('WHATSAPP_NUMBER', '+212600000000');
```

### 3. Upload des fichiers

1. Compressez le dossier `alog_academy/` en ZIP
2. Uploadez via le gestionnaire de fichiers cPanel dans `public_html/`
3. Extrayez le ZIP
4. Assurez-vous que `.htaccess` est a la racine et dans `/public/`

### 4. Creation du compte admin

Executez cette requete SQL dans phpMyAdmin pour creer un admin :

```sql
INSERT INTO admins (first_name, last_name, email, password_hash, role_id, status)
VALUES ('Super', 'Admin', 'admin@alog.ma', '$argon2id$v=19$m=65536,t=4,p=3$...', 3, 'active');
```

Pour generer un hash de mot de passe, utilisez ce script PHP temporaire :

```php
<?php
echo password_hash('votre_mot_de_passe', PASSWORD_ARGON2ID);
?>
```

### 5. SSL (Recommande)

Activez le certificat SSL gratuit Let's Encrypt dans cPanel > SSL/TLS

---

## FONCTIONNALITES

### Etudiants
- Inscription / Connexion securisee
- Dashboard avec statistiques XP
- Cours video (YouTube embed)
- PDF telechargeables
- Quiz avec correction
- Systeme XP et niveaux
- Classement national et regional
- Abonnements (Free, Pro 49 MAD, Ultra 99 MAD)
- Paiement WhatsApp manuel avec upload de preuve
- Reservations (tutorat, orientation, coaching)
- Blog educatif
- Notifications
- Mode sombre/clair

### Administrateurs
- Dashboard analytique
- Gestion des utilisateurs (ban/actif)
- Validation manuelle des paiements
- CRUD Niveaux / Matieres / Lecons / Quiz
- Gestion des reservations
- Gestion du blog
- Parametres du site

---

## SECURITE

- Hashage Argon2id des mots de passe
- Sessions securisees (httponly, secure, samesite)
- Protection CSRF sur tous les formulaires
- Prepared PDO statements (anti SQL injection)
- Validation serveur-side
- Rate limiting (anti brute force)
- Upload securise avec validation MIME
- Protection XSS via htmlspecialchars

---

## OPTIMISATIONS FREE HOSTING

- Pas de framework lourd (Laravel/Symfony)
- Pas de Node.js ou React
- Assets via CDN (Bootstrap, Icons, Fonts)
- Requetes SQL optimisees avec indexes
- Lazy loading des images
- Compression gzip via .htaccess
- Mise en cache des assets statiques
- Pas de WebSocket
- Minimal AJAX

---

## LICENCE

Proprietaire - ALOG ACADEMY

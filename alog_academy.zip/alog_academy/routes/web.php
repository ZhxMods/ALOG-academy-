<?php
/**
 * Routes ALOG ACADEMY
 */

use App\Core\Router;
use App\Helpers\AuthMiddleware;
use App\Helpers\AdminMiddleware;

$router = new Router();

// ===== PUBLIC =====
$router->get('', 'PublicController', 'home');
$router->get('a-propos', 'PublicController', 'about');
$router->get('services', 'PublicController', 'services');
$router->get('tarifs', 'PublicController', 'pricing');
$router->get('blog', 'PublicController', 'blog');
$router->get('blog/{slug}', 'PublicController', 'blogPost');
$router->get('faq', 'PublicController', 'faq');
$router->get('contact', 'PublicController', 'contact');
$router->post('contact', 'PublicController', 'contact');
$router->get('mode-sombre', 'PublicController', 'toggleDarkMode');

// ===== AUTH =====
$router->get('login', 'AuthController', 'login');
$router->post('login', 'AuthController', 'login');
$router->get('inscription', 'AuthController', 'register');
$router->post('inscription', 'AuthController', 'register');
$router->get('mot-de-passe-oublie', 'AuthController', 'forgotPassword');
$router->post('mot-de-passe-oublie', 'AuthController', 'forgotPassword');
$router->get('logout', 'AuthController', 'logout');

// ===== STUDENT =====
$router->get('dashboard', 'StudentController', 'dashboard', [AuthMiddleware::class]);
$router->get('cours', 'StudentController', 'lessons', [AuthMiddleware::class]);
$router->get('cours/{slug}', 'StudentController', 'lessonDetail', [AuthMiddleware::class]);
$router->post('cours/complete', 'StudentController', 'completeLesson', [AuthMiddleware::class]);
$router->get('quiz/{id}', 'StudentController', 'quiz', [AuthMiddleware::class]);
$router->post('quiz/submit', 'StudentController', 'submitQuiz', [AuthMiddleware::class]);
$router->get('classement', 'StudentController', 'rankings', [AuthMiddleware::class]);
$router->get('profil', 'StudentController', 'profile', [AuthMiddleware::class]);
$router->post('profil', 'StudentController', 'updateProfile', [AuthMiddleware::class]);
$router->get('abonnements', 'StudentController', 'subscriptions', [AuthMiddleware::class]);
$router->post('abonnements', 'StudentController', 'subscribe', [AuthMiddleware::class]);
$router->post('abonnements/proof', 'StudentController', 'uploadPaymentProof', [AuthMiddleware::class]);
$router->get('reservations', 'StudentController', 'bookings', [AuthMiddleware::class]);
$router->post('reservations', 'StudentController', 'createBooking', [AuthMiddleware::class]);
$router->get('notifications', 'StudentController', 'notifications', [AuthMiddleware::class]);

// ===== ADMIN =====
$router->get('admin/login', 'AdminController', 'login');
$router->post('admin/login', 'AdminController', 'login');
$router->get('admin/logout', 'AdminController', 'logout');
$router->get('admin/dashboard', 'AdminController', 'dashboard', [AdminMiddleware::class]);
$router->get('admin/utilisateurs', 'AdminController', 'users', [AdminMiddleware::class]);
$router->post('admin/utilisateurs/status', 'AdminController', 'updateUserStatus', [AdminMiddleware::class]);
$router->get('admin/paiements', 'AdminController', 'payments', [AdminMiddleware::class]);
$router->post('admin/paiements/approuver', 'AdminController', 'approvePayment', [AdminMiddleware::class]);
$router->post('admin/paiements/refuser', 'AdminController', 'rejectPayment', [AdminMiddleware::class]);
$router->get('admin/niveaux', 'AdminController', 'levels', [AdminMiddleware::class]);
$router->post('admin/niveaux', 'AdminController', 'saveLevel', [AdminMiddleware::class]);
$router->get('admin/matieres', 'AdminController', 'subjects', [AdminMiddleware::class]);
$router->get('admin/lecons', 'AdminController', 'lessons', [AdminMiddleware::class]);
$router->post('admin/lecons', 'AdminController', 'saveLesson', [AdminMiddleware::class]);
$router->get('admin/quiz', 'AdminController', 'quizzes', [AdminMiddleware::class]);
$router->get('admin/reservations', 'AdminController', 'bookings', [AdminMiddleware::class]);
$router->post('admin/reservations', 'AdminController', 'updateBooking', [AdminMiddleware::class]);
$router->get('admin/blog', 'AdminController', 'blog', [AdminMiddleware::class]);
$router->post('admin/blog', 'AdminController', 'saveBlogPost', [AdminMiddleware::class]);
$router->get('admin/parametres', 'AdminController', 'settings', [AdminMiddleware::class]);
$router->post('admin/parametres', 'AdminController', 'saveSettings', [AdminMiddleware::class]);

return $router;

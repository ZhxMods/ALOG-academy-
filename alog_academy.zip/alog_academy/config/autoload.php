<?php
/**
 * Autoloader PSR-4 simplifié
 */
spl_autoload_register(function (string $class) {
    $prefix = 'App\';
    $base_dir = APP_PATH . '/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

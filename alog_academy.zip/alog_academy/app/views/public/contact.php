<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="h2 fw-bold">Contactez-nous</h1>
            <p class="text-muted">Une question ? Nous sommes la pour vous aider</p>
        </div>

        <div class="row justify-content-center g-5">
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-4">Informations de contact</h5>

                        <div class="d-flex align-items-start gap-3 mb-4">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-3 d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px">
                                <i class="bi bi-whatsapp"></i>
                            </div>
                            <div>
                                <div class="fw-medium">WhatsApp</div>
                                <a href="https://wa.me/<?= str_replace('+', '', WHATSAPP_NUMBER) ?>" class="text-muted text-decoration-none" target="_blank"><?= WHATSAPP_NUMBER ?></a>
                            </div>
                        </div>

                        <div class="d-flex align-items-start gap-3 mb-4">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-3 d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px">
                                <i class="bi bi-envelope"></i>
                            </div>
                            <div>
                                <div class="fw-medium">Email</div>
                                <span class="text-muted">contact@alogacademy.ma</span>
                            </div>
                        </div>

                        <div class="d-flex align-items-start gap-3">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-3 d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px">
                                <i class="bi bi-clock"></i>
                            </div>
                            <div>
                                <div class="fw-medium">Disponibilite</div>
                                <span class="text-muted">Lun - Sam : 9h00 - 18h00</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <?php if (!empty($success)): ?>
                            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                        <?php endif; ?>
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?= BASE_URL ?>/contact">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                            <div class="mb-3">
                                <label class="form-label fw-medium">Nom</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-medium">Email</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-medium">Message</label>
                                <textarea name="message" class="form-control" rows="5" required></textarea>
                            </div>

                            <button type="submit" class="btn btn-alog-primary w-100">
                                <i class="bi bi-send me-2"></i>Envoyer le message
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

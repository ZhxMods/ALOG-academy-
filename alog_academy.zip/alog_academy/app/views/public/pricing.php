<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="h2 fw-bold">Nos Tarifs</h1>
            <p class="text-muted">Choisissez le plan adapte a vos besoins</p>
        </div>

        <div class="row justify-content-center g-4">
            <div class="col-md-4">
                <div class="card pricing-card border-0 shadow-sm h-100">
                    <div class="card-body p-4 text-center">
                        <div class="mb-3">
                            <span class="badge bg-secondary bg-opacity-10 text-secondary">GRATUIT</span>
                        </div>
                        <h3 class="fw-bold">Free</h3>
                        <div class="display-5 fw-bold text-primary my-3">0 <small class="fs-4">MAD</small></div>
                        <p class="text-muted small">Pour decouvrir la plateforme</p>

                        <hr class="my-4">

                        <ul class="list-unstyled text-start text-muted small mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Acces aux cours gratuits</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Quiz limites</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Classement regional</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Blog access</li>
                            <li class="mb-2 text-decoration-line-through text-muted"><i class="bi bi-x-circle text-muted me-2"></i>PDF premium</li>
                            <li class="mb-2 text-decoration-line-through text-muted"><i class="bi bi-x-circle text-muted me-2"></i>Sans publicite</li>
                        </ul>

                        <a href="<?= BASE_URL ?>/inscription" class="btn btn-outline-primary w-100">Commencer</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card pricing-card border-primary shadow h-100">
                    <div class="card-header bg-primary text-white text-center py-3">
                        <span class="fw-bold">PLUS POPULAIRE</span>
                    </div>
                    <div class="card-body p-4 text-center">
                        <div class="mb-3">
                            <span class="badge bg-primary bg-opacity-10 text-primary">PRO</span>
                        </div>
                        <h3 class="fw-bold">Pro</h3>
                        <div class="display-5 fw-bold text-primary my-3"><?= $price_pro ?> <small class="fs-4">MAD/mois</small></div>
                        <p class="text-muted small">Pour les etudiants serieux</p>

                        <hr class="my-4">

                        <ul class="list-unstyled text-start text-muted small mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Tous les cours</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Quiz illimites</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>PDF premium</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Sans publicite</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Classement national</li>
                            <li class="mb-2 text-decoration-line-through text-muted"><i class="bi bi-x-circle text-muted me-2"></i>Coaching</li>
                        </ul>

                        <a href="<?= BASE_URL ?>/inscription" class="btn btn-primary w-100">S'abonner</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card pricing-card border-0 shadow-sm h-100">
                    <div class="card-body p-4 text-center">
                        <div class="mb-3">
                            <span class="badge bg-dark bg-opacity-10 text-dark">ULTRA</span>
                        </div>
                        <h3 class="fw-bold">Ultra</h3>
                        <div class="display-5 fw-bold text-primary my-3"><?= $price_ultra ?> <small class="fs-4">MAD/mois</small></div>
                        <p class="text-muted small">Experience complete</p>

                        <hr class="my-4">

                        <ul class="list-unstyled text-start text-muted small mb-4">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Acces complet</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Contenu exclusif</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Support premium</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Coaching groupe</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Priorite reservations</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Telechargements illimites</li>
                        </ul>

                        <a href="<?= BASE_URL ?>/inscription" class="btn btn-outline-primary w-100">S'abonner</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center mt-5">
            <div class="card border-0 shadow-sm d-inline-block">
                <div class="card-body px-4 py-3">
                    <i class="bi bi-whatsapp text-success fs-4 me-2"></i>
                    <span class="fw-medium">Paiement par WhatsApp:</span>
                    <a href="https://wa.me/<?= str_replace('+', '', WHATSAPP_NUMBER) ?>" class="text-decoration-none fw-bold ms-2" target="_blank"><?= WHATSAPP_NUMBER ?></a>
                </div>
            </div>
        </div>
    </div>
</section>

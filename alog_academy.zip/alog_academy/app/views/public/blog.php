<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="h2 fw-bold">Blog ALOG ACADEMY</h1>
            <p class="text-muted">Conseils, methodes et motivation pour reussir</p>
        </div>

        <?php if (!empty($categories)): ?>
        <div class="d-flex flex-wrap justify-content-center gap-2 mb-4">
            <a href="<?= BASE_URL ?>/blog" class="btn btn-sm <?= empty($current_category) ? 'btn-primary' : 'btn-outline-primary' ?>">Tous</a>
            <?php foreach ($categories as $cat): ?>
                <a href="<?= BASE_URL ?>/blog?category=<?= urlencode($cat) ?>" class="btn btn-sm <?= ($current_category ?? '') === $cat ? 'btn-primary' : 'btn-outline-primary' ?>"><?= htmlspecialchars($cat) ?></a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="row g-4">
            <?php foreach ($posts as $post): ?>
            <div class="col-md-6 col-lg-4">
                <article class="card blog-card h-100 border-0 shadow-sm">
                    <?php if (!empty($post['featured_image'])): ?>
                        <img src="<?= htmlspecialchars($post['featured_image']) ?>" class="card-img-top" style="height:200px;object-fit:cover" alt="" loading="lazy">
                    <?php else: ?>
                        <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height:200px">
                            <i class="bi bi-journal-text text-primary" style="font-size:3rem"></i>
                        </div>
                    <?php endif; ?>
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="badge bg-secondary bg-opacity-10 text-secondary"><?= htmlspecialchars($post['category'] ?? 'General') ?></span>
                            <small class="text-muted"><?= $post['reading_time'] ?> min</small>
                        </div>
                        <h5 class="fw-bold mb-2"><?= htmlspecialchars($post['title']) ?></h5>
                        <p class="text-muted small"><?= htmlspecialchars(substr($post['excerpt'] ?? strip_tags($post['content']), 0, 140)) ?>...</p>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <small class="text-muted">Par <?= htmlspecialchars($post['author_name'] . ' ' . $post['author_lastname']) ?></small>
                            <a href="<?= BASE_URL ?>/blog/<?= $post['slug'] ?>" class="btn btn-sm btn-primary">Lire</a>
                        </div>
                    </div>
                </article>
            </div>
            <?php endforeach; ?>
        </div>

        <?php if ($total_pages > 1): ?>
        <nav class="mt-5">
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                    <a class="page-link" href="<?= BASE_URL ?>/blog?page=<?= $i ?><?= $current_category ? '&category=' . urlencode($current_category) : '' ?>"><?= $i ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</section>

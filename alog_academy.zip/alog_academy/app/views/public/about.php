<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h1 class="display-5 fw-bold mb-4">A Propos d'ALOG ACADEMY</h1>
                <p class="lead text-muted mb-5">
                    ALOG ACADEMY est une plateforme educative numerique dediee aux etudiants marocains. Notre mission est de democratiser l'acces a une education de qualite pour tous.
                </p>
            </div>
        </div>

        <div class="row g-4 mt-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <h4 class="fw-bold mb-3"><i class="bi bi-bullseye text-primary me-2"></i>Notre Mission</h4>
                        <p class="text-muted">Offrir a chaque etudiant marocain les outils necessaires pour reussir son parcours scolaire grace a des ressources pedagogiques modernes, accessibles et interactives.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <h4 class="fw-bold mb-3"><i class="bi bi-eye text-primary me-2"></i>Notre Vision</h4>
                        <p class="text-muted">Devenir la reference nationale de l'education digitale et accompagner la reussite de plus d'un million d'etudiants d'ici 2030.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

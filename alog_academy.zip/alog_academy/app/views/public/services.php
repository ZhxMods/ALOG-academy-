<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="h2 fw-bold">Nos Services</h1>
            <p class="text-muted">Des outils complets pour votre reussite</p>
        </div>

        <div class="row g-4">
            <div class="col-md-6 col-lg-4">
                <div class="card service-card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="service-icon bg-primary bg-opacity-10 text-primary rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:48px;height:48px">
                            <i class="bi bi-collection-play fs-5"></i>
                        </div>
                        <h5 class="fw-bold">Bibliotheque de Cours</h5>
                        <p class="text-muted small">Des centaines de cours video organises par niveau et matiere, avec supports PDF telechargeables.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="card service-card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="service-icon bg-success bg-opacity-10 text-success rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:48px;height:48px">
                            <i class="bi bi-clipboard-check fs-5"></i>
                        </div>
                        <h5 class="fw-bold">Quiz Interactifs</h5>
                        <p class="text-muted small">Testez vos connaissances avec des quiz a choix multiples et vrai/faux avec corrections detaillees.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="card service-card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="service-icon bg-info bg-opacity-10 text-info rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:48px;height:48px">
                            <i class="bi bi-trophy fs-5"></i>
                        </div>
                        <h5 class="fw-bold">Classements</h5>
                        <p class="text-muted small">Comparez vos progres avec les autres etudiants au niveau national et regional.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="card service-card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="service-icon bg-warning bg-opacity-10 text-warning rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:48px;height:48px">
                            <i class="bi bi-calendar-event fs-5"></i>
                        </div>
                        <h5 class="fw-bold">Reservations</h5>
                        <p class="text-muted small">Reservez des séances de tutorat, orientation ou coaching avec nos experts.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="card service-card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="service-icon bg-danger bg-opacity-10 text-danger rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:48px;height:48px">
                            <i class="bi bi-journal-bookmark fs-5"></i>
                        </div>
                        <h5 class="fw-bold">Blog Educatif</h5>
                        <p class="text-muted small">Conseils de revision, methodes de travail, orientation et motivation pour reussir.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="card service-card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="service-icon bg-secondary bg-opacity-10 text-secondary rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:48px;height:48px">
                            <i class="bi bi-phone fs-5"></i>
                        </div>
                        <h5 class="fw-bold">100% Mobile</h5>
                        <p class="text-muted small">Apprenez n'importe ou, n'importe quand depuis votre smartphone ou tablette.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Hero Section -->
<section class="hero-section py-5 py-lg-7">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <div class="badge bg-primary bg-opacity-10 text-primary mb-3 px-3 py-2">
                    <i class="bi bi-stars me-1"></i>Plateforme educative #1 au Maroc
                </div>
                <h1 class="display-4 fw-bold mb-3">
                    Reussissez vos examens avec <span class="text-primary">ALOG ACADEMY</span>
                </h1>
                <p class="lead text-muted mb-4">
                    Cours video, quiz interactifs, et suivi de progression pour les etudiants marocains. Commencez gratuitement dès aujourd'hui !
                </p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="<?= BASE_URL ?>/inscription" class="btn btn-alog-primary btn-lg px-4">
                        <i class="bi bi-rocket-takeoff me-2"></i>Commencer Gratuitement
                    </a>
                    <a href="<?= BASE_URL ?>/cours" class="btn btn-outline-primary btn-lg px-4">
                        <i class="bi bi-play-circle me-2"></i>Explorer les Cours
                    </a>
                </div>

                <div class="d-flex gap-4 mt-4 pt-3">
                    <div>
                        <div class="h4 fw-bold text-primary mb-0">+10K</div>
                        <small class="text-muted">Etudiants</small>
                    </div>
                    <div>
                        <div class="h4 fw-bold text-primary mb-0">+500</div>
                        <small class="text-muted">Lecons</small>
                    </div>
                    <div>
                        <div class="h4 fw-bold text-primary mb-0">+1000</div>
                        <small class="text-muted">Quiz</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 text-center">
                <div class="hero-image-wrapper">
                    <div class="bg-primary bg-opacity-10 rounded-4 p-4 d-inline-block">
                        <i class="bi bi-mortarboard-fill display-1 text-primary"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features -->
<section class="py-5 bg-body-tertiary">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="h3 fw-bold">Pourquoi choisir ALOG ACADEMY ?</h2>
            <p class="text-muted">Une plateforme complete pour votre reussite scolaire</p>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm feature-card">
                    <div class="card-body p-4 text-center">
                        <div class="feature-icon bg-primary bg-opacity-10 text-primary rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:56px;height:56px">
                            <i class="bi bi-play-btn fs-4"></i>
                        </div>
                        <h5 class="fw-bold">Cours Video</h5>
                        <p class="text-muted small mb-0">Accedez a des centaines de cours video expliques par des enseignants qualifies.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm feature-card">
                    <div class="card-body p-4 text-center">
                        <div class="feature-icon bg-success bg-opacity-10 text-success rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:56px;height:56px">
                            <i class="bi bi-controller fs-4"></i>
                        </div>
                        <h5 class="fw-bold">Gamification</h5>
                        <p class="text-muted small mb-0">Gagnez des XP, montez de niveau et comparez-vous au classement national.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm feature-card">
                    <div class="card-body p-4 text-center">
                        <div class="feature-icon bg-warning bg-opacity-10 text-warning rounded-3 d-inline-flex align-items-center justify-content-center mb-3" style="width:56px;height:56px">
                            <i class="bi bi-file-earmark-pdf fs-4"></i>
                        </div>
                        <h5 class="fw-bold">PDF & Exercices</h5>
                        <p class="text-muted small mb-0">Telechargez des fiches de cours et exercices corriges au format PDF.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Cours Recents -->
<section class="py-5">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h3 fw-bold mb-0">Cours Recents</h2>
                <p class="text-muted small">Nouveautes de la semaine</p>
            </div>
            <a href="<?= BASE_URL ?>/cours" class="btn btn-outline-primary btn-sm">Voir tout <i class="bi bi-arrow-right ms-1"></i></a>
        </div>

        <div class="row g-4">
            <?php foreach ($featured_lessons as $lesson): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card lesson-card h-100 border-0 shadow-sm">
                    <div class="card-img-top position-relative bg-light" style="height:180px">
                        <?php if (!empty($lesson['thumbnail_url'])): ?>
                            <img src="<?= htmlspecialchars($lesson['thumbnail_url']) ?>" class="w-100 h-100 object-fit-cover rounded-top" alt="">
                        <?php else: ?>
                            <div class="d-flex align-items-center justify-content-center h-100">
                                <i class="bi bi-play-circle text-primary" style="font-size:3rem"></i>
                            </div>
                        <?php endif; ?>
                        <span class="badge bg-dark position-absolute top-2 start-2 m-2">
                            <?= strtoupper($lesson['access_type']) ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title fw-bold"><?= htmlspecialchars($lesson['title']) ?></h5>
                        <p class="card-text text-muted small"><?= htmlspecialchars(substr($lesson['description'] ?? '', 0, 100)) ?>...</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-primary bg-opacity-10 text-primary">+<?= $lesson['xp_reward'] ?> XP</span>
                            <a href="<?= BASE_URL ?>/cours/<?= $lesson['slug'] ?>" class="btn btn-sm btn-primary">Voir le cours</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Pricing CTA -->
<section class="py-5 bg-primary bg-opacity-5">
    <div class="container text-center">
        <h2 class="h3 fw-bold mb-3">Passez a la vitesse superieure</h2>
        <p class="text-muted mb-4">Des abonnements accessibles pour tous les budgets</p>
        <div class="row justify-content-center g-4">
            <div class="col-md-4">
                <div class="card pricing-card border-0 shadow-sm">
                    <div class="card-body p-4 text-center">
                        <h5 class="fw-bold">GRATUIT</h5>
                        <div class="h2 fw-bold my-3">0 <small class="fs-6">MAD</small></div>
                        <ul class="list-unstyled text-muted small mb-4">
                            <li><i class="bi bi-check text-success me-2"></i>Cours limites</li>
                            <li><i class="bi bi-check text-success me-2"></i>Quiz basiques</li>
                            <li><i class="bi bi-check text-success me-2"></i>Classement regional</li>
                        </ul>
                        <a href="<?= BASE_URL ?>/inscription" class="btn btn-outline-primary w-100">Commencer</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card pricing-card border-primary shadow">
                    <div class="card-header bg-primary text-white py-2">
                        <small class="fw-bold">POPULAIRE</small>
                    </div>
                    <div class="card-body p-4 text-center">
                        <h5 class="fw-bold">PRO</h5>
                        <div class="h2 fw-bold my-3">49 <small class="fs-6">MAD/mois</small></div>
                        <ul class="list-unstyled text-muted small mb-4">
                            <li><i class="bi bi-check text-success me-2"></i>Tous les cours</li>
                            <li><i class="bi bi-check text-success me-2"></i>Quiz illimites</li>
                            <li><i class="bi bi-check text-success me-2"></i>PDF premium</li>
                            <li><i class="bi bi-check text-success me-2"></i>Sans publicite</li>
                        </ul>
                        <a href="<?= BASE_URL ?>/inscription" class="btn btn-primary w-100">S'abonner</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card pricing-card border-0 shadow-sm">
                    <div class="card-body p-4 text-center">
                        <h5 class="fw-bold">ULTRA</h5>
                        <div class="h2 fw-bold my-3">99 <small class="fs-6">MAD/mois</small></div>
                        <ul class="list-unstyled text-muted small mb-4">
                            <li><i class="bi bi-check text-success me-2"></i>Acces complet</li>
                            <li><i class="bi bi-check text-success me-2"></i>Contenu exclusif</li>
                            <li><i class="bi bi-check text-success me-2"></i>Support premium</li>
                            <li><i class="bi bi-check text-success me-2"></i>Coaching groupe</li>
                        </ul>
                        <a href="<?= BASE_URL ?>/inscription" class="btn btn-outline-primary w-100">S'abonner</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Blog Section -->
<section class="py-5">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h3 fw-bold mb-0">Conseils & Articles</h2>
                <p class="text-muted small">Boostez vos revisions</p>
            </div>
            <a href="<?= BASE_URL ?>/blog" class="btn btn-outline-primary btn-sm">Tous les articles <i class="bi bi-arrow-right ms-1"></i></a>
        </div>

        <div class="row g-4">
            <?php foreach ($recent_posts as $post): ?>
            <div class="col-md-4">
                <article class="card blog-card h-100 border-0 shadow-sm">
                    <?php if (!empty($post['featured_image'])): ?>
                        <img src="<?= htmlspecialchars($post['featured_image']) ?>" class="card-img-top" style="height:180px;object-fit:cover" alt="">
                    <?php endif; ?>
                    <div class="card-body p-4">
                        <span class="badge bg-secondary bg-opacity-10 text-secondary mb-2"><?= htmlspecialchars($post['category'] ?? 'General') ?></span>
                        <h5 class="fw-bold mb-2"><?= htmlspecialchars($post['title']) ?></h5>
                        <p class="text-muted small"><?= htmlspecialchars(substr($post['excerpt'] ?? strip_tags($post['content']), 0, 120)) ?>...</p>
                        <a href="<?= BASE_URL ?>/blog/<?= $post['slug'] ?>" class="text-decoration-none fw-medium small">Lire la suite <i class="bi bi-arrow-right"></i></a>
                    </div>
                </article>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="h2 fw-bold">Questions Frequemment Posees</h1>
            <p class="text-muted">Trouvez rapidement une reponse a vos questions</p>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                Comment puis-je m'inscrire sur ALOG ACADEMY ?
                            </button>
                        </h2>
                        <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                Cliquez sur "S'inscrire" en haut de page, remplissez le formulaire avec vos informations personnelles, et validez. L'inscription est gratuite et prend moins d'une minute.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                Comment fonctionne le systeme d'abonnement ?
                            </button>
                        </h2>
                        <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                Nous proposons 3 plans : Gratuit (acces limite), Pro (49 MAD/mois) avec tous les cours et quiz, et Ultra (99 MAD/mois) avec coaching et contenu exclusif. Le paiement se fait via WhatsApp avec validation manuelle.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                Comment fonctionne le systeme de XP et niveaux ?
                            </button>
                        </h2>
                        <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                Vous gagnez des XP en terminant des lecons (+50 XP), en reussissant des quiz (+30 XP), et en vous connectant quotidiennement (+10 XP). En accumulant des XP, vous montez de niveau et debloquez du contenu exclusif.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                Puis-je acceder aux cours sur mon telephone ?
                            </button>
                        </h2>
                        <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                Oui ! ALOG ACADEMY est entierement responsive. Vous pouvez apprendre depuis votre smartphone, tablette ou ordinateur sans aucun probleme.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                                Comment se fait le paiement et la validation ?
                            </button>
                        </h2>
                        <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted">
                                Apres avoir choisi votre plan, vous effectuez le paiement via WhatsApp sur le numero indique. Vous telechargez ensuite la preuve de paiement dans votre espace, et notre equipe valide manuellement sous 24h.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

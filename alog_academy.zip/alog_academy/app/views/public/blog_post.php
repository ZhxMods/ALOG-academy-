<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <article class="blog-article">
                    <nav aria-label="breadcrumb" class="mb-3">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/">Accueil</a></li>
                            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/blog">Blog</a></li>
                            <li class="breadcrumb-item active"><?= htmlspecialchars(substr($post['title'], 0, 30)) ?>...</li>
                        </ol>
                    </nav>

                    <?php if (!empty($post['featured_image'])): ?>
                        <img src="<?= htmlspecialchars($post['featured_image']) ?>" class="img-fluid rounded-4 mb-4 w-100" style="max-height:400px;object-fit:cover" alt="">
                    <?php endif; ?>

                    <div class="d-flex align-items-center gap-3 mb-3">
                        <span class="badge bg-primary bg-opacity-10 text-primary"><?= htmlspecialchars($post['category'] ?? 'General') ?></span>
                        <span class="text-muted small"><i class="bi bi-clock me-1"></i><?= $post['reading_time'] ?> min de lecture</span>
                        <span class="text-muted small"><i class="bi bi-eye me-1"></i><?= $post['views_count'] ?> vues</span>
                    </div>

                    <h1 class="fw-bold mb-3"><?= htmlspecialchars($post['title']) ?></h1>

                    <div class="d-flex align-items-center gap-2 mb-4 pb-3 border-bottom">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width:40px;height:40px">
                            <?= strtoupper(substr($post['author_name'], 0, 1)) ?>
                        </div>
                        <div>
                            <div class="fw-medium"><?= htmlspecialchars($post['author_name'] . ' ' . $post['author_lastname']) ?></div>
                            <div class="text-muted small"><?= date('d M Y', strtotime($post['published_at'])) ?></div>
                        </div>
                    </div>

                    <div class="blog-content">
                        <?= $post['content'] ?>
                    </div>
                </article>

                <?php if (!empty($related)): ?>
                <div class="mt-5 pt-4 border-top">
                    <h4 class="fw-bold mb-4">Articles similaires</h4>
                    <div class="row g-3">
                        <?php foreach ($related as $rel): ?>
                        <div class="col-md-4">
                            <a href="<?= BASE_URL ?>/blog/<?= $rel['slug'] ?>" class="text-decoration-none">
                                <div class="card border-0 shadow-sm h-100">
                                    <?php if (!empty($rel['featured_image'])): ?>
                                        <img src="<?= htmlspecialchars($rel['featured_image']) ?>" class="card-img-top" style="height:120px;object-fit:cover" alt="">
                                    <?php endif; ?>
                                    <div class="card-body p-3">
                                        <h6 class="fw-bold text-dark"><?= htmlspecialchars($rel['title']) ?></h6>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

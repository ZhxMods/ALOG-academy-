<section class="py-4">
    <div class="container">
        <!-- Welcome Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 fw-bold mb-1">Bonjour, <?= htmlspecialchars($user['first_name'] ?? 'Etudiant') ?> !</h1>
                <p class="text-muted mb-0">Voici votre progression aujourd'hui</p>
            </div>
            <div class="d-flex align-items-center gap-2">
                <?php if (!empty($stats['subscription']['plan_type']) && $stats['subscription']['plan_type'] !== 'free'): ?>
                    <span class="badge bg-warning text-dark">
                        <i class="bi bi-star-fill me-1"></i><?= strtoupper($stats['subscription']['plan_type']) ?>
                    </span>
                <?php endif; ?>
                <?php if ($stats['unread_notifications'] > 0): ?>
                    <a href="<?= BASE_URL ?>/notifications" class="btn btn-outline-secondary btn-sm position-relative">
                        <i class="bi bi-bell"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size:0.6rem">
                            <?= $stats['unread_notifications'] ?>
                        </span>
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row g-3 mb-4">
            <div class="col-6 col-md-3">
                <div class="card stat-card border-0 shadow-sm h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-3 d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                                <i class="bi bi-lightning-charge fs-5"></i>
                            </div>
                            <div>
                                <div class="h5 fw-bold mb-0"><?= $stats['level']['total_xp'] ?? 0 ?></div>
                                <small class="text-muted">XP Total</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card stat-card border-0 shadow-sm h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-success bg-opacity-10 text-success rounded-3 d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                                <i class="bi bi-trophy fs-5"></i>
                            </div>
                            <div>
                                <div class="h5 fw-bold mb-0">Niv. <?= $stats['level']['current_level'] ?? 1 ?></div>
                                <small class="text-muted"><?= ($stats['level']['xp_to_next_level'] ?? 0) > 0 ? ($stats['level']['xp_to_next_level'] . ' XP restants') : 'Niveau max' ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card stat-card border-0 shadow-sm h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-info bg-opacity-10 text-info rounded-3 d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                                <i class="bi bi-check-circle fs-5"></i>
                            </div>
                            <div>
                                <div class="h5 fw-bold mb-0"><?= $stats['completed_lessons'] ?></div>
                                <small class="text-muted">Lecons finies</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card stat-card border-0 shadow-sm h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-warning bg-opacity-10 text-warning rounded-3 d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                                <i class="bi bi-clipboard-check fs-5"></i>
                            </div>
                            <div>
                                <div class="h5 fw-bold mb-0"><?= $stats['quizzes_taken'] ?></div>
                                <small class="text-muted">Quiz passes</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Left Column -->
            <div class="col-lg-8">
                <?php if ($continue_lesson): ?>
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                                <i class="bi bi-play-fill fs-4"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-0">Continuer votre apprentissage</h5>
                                <p class="text-muted small mb-0">Reprenez la ou vous vous etes arrete</p>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center bg-light rounded-3 p-3">
                            <div>
                                <div class="fw-bold"><?= htmlspecialchars($continue_lesson['title']) ?></div>
                                <small class="text-muted"><?= htmlspecialchars($continue_lesson['subject_name'] ?? '') ?> - <?= htmlspecialchars($continue_lesson['level_name'] ?? '') ?></small>
                            </div>
                            <a href="<?= BASE_URL ?>/cours/<?= $continue_lesson['slug'] ?>" class="btn btn-primary">
                                <i class="bi bi-play-fill me-1"></i>Continuer
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white border-0 pt-4 px-4">
                        <h5 class="fw-bold mb-0"><i class="bi bi-clock-history me-2 text-primary"></i>Activite recente</h5>
                    </div>
                    <div class="card-body px-4 pb-4">
                        <?php if (!empty($recent_activity)): ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($recent_activity as $act): ?>
                                <div class="list-group-item px-0 d-flex align-items-center gap-3">
                                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:36px;height:36px">
                                        <i class="bi bi-plus-lg"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="fw-medium small"><?= htmlspecialchars($act['description']) ?></div>
                                        <small class="text-muted">+<?= $act['xp_amount'] ?> XP</small>
                                    </div>
                                    <small class="text-muted"><?= date('d/m H:i', strtotime($act['created_at'])) ?></small>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted text-center py-4 mb-0">Aucune activite recente. Commencez un cours !</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
                        <h5 class="fw-bold mb-0"><i class="bi bi-book me-2 text-primary"></i>Nouveaux cours</h5>
                        <a href="<?= BASE_URL ?>/cours" class="btn btn-sm btn-outline-primary">Voir tout</a>
                    </div>
                    <div class="card-body px-4 pb-4">
                        <div class="row g-3">
                            <?php foreach ($latest_lessons as $lesson): ?>
                            <div class="col-md-6">
                                <a href="<?= BASE_URL ?>/cours/<?= $lesson['slug'] ?>" class="text-decoration-none">
                                    <div class="card lesson-card-sm border-0 shadow-sm h-100">
                                        <div class="card-body p-3">
                                            <span class="badge bg-<?= $lesson['access_type'] === 'free' ? 'success' : 'primary' ?> bg-opacity-10 text-<?= $lesson['access_type'] === 'free' ? 'success' : 'primary' ?> mb-2">
                                                <?= strtoupper($lesson['access_type']) ?>
                                            </span>
                                            <h6 class="fw-bold text-dark mb-1"><?= htmlspecialchars($lesson['title']) ?></h6>
                                            <small class="text-muted">+<?= $lesson['xp_reward'] ?> XP</small>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column - Leaderboard -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-0 pt-4 px-4">
                        <h5 class="fw-bold mb-0"><i class="bi bi-trophy me-2 text-warning"></i>Top Classement</h5>
                    </div>
                    <div class="card-body px-4 pb-4">
                        <?php if (!empty($global_top)): ?>
                            <div class="list-group list-group-flush">
                                <?php foreach (array_slice($global_top, 0, 10) as $index => $top): ?>
                                <div class="list-group-item px-0 d-flex align-items-center gap-3">
                                    <div class="rank-badge fw-bold <?= $index < 3 ? 'text-warning' : 'text-muted' ?>" style="width:24px">
                                        <?= $top['global_rank'] ?>
                                    </div>
                                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:36px;height:36px;font-size:0.8rem">
                                        <?= strtoupper(substr($top['first_name'], 0, 1) . substr($top['last_name'], 0, 1)) ?>
                                    </div>
                                    <div class="flex-grow-1 min-width-0">
                                        <div class="fw-medium small text-truncate"><?= htmlspecialchars($top['first_name'] . ' ' . $top['last_name']) ?></div>
                                        <small class="text-muted">Niv. <?= $top['current_level'] ?></small>
                                    </div>
                                    <div class="fw-bold text-primary small"><?= $top['total_xp'] ?> XP</div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="text-center mt-3">
                                <a href="<?= BASE_URL ?>/classement" class="btn btn-sm btn-outline-primary">Voir tout le classement</a>
                            </div>
                        <?php else: ?>
                            <p class="text-muted text-center py-4 mb-0">Aucune donnee de classement</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-4">
    <div class="container">
        <h1 class="h3 fw-bold mb-4">Mes Reservations</h1>

        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-0 pt-4 px-4">
                        <h5 class="fw-bold mb-0">Nouvelle reservation</h5>
                    </div>
                    <div class="card-body px-4 pb-4">
                        <form method="POST" action="<?= BASE_URL ?>/reservations">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                            <div class="mb-3">
                                <label class="form-label">Type</label>
                                <select name="booking_type" class="form-select" required>
                                    <option value="tutoring">Tutorat</option>
                                    <option value="orientation">Orientation</option>
                                    <option value="coaching">Coaching</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Date souhaitee</label>
                                <input type="date" name="preferred_date" class="form-control" required min="<?= date('Y-m-d') ?>">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Heure preferee</label>
                                <input type="time" name="preferred_time" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">WhatsApp</label>
                                <input type="tel" name="whatsapp" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="3"></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">Demander une reservation</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-0 pt-4 px-4">
                        <h5 class="fw-bold mb-0">Historique</h5>
                    </div>
                    <div class="card-body px-4 pb-4">
                        <?php if (!empty($bookings)): ?>
                            <div class="table-responsive">
                                <table class="table table-hover align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Type</th>
                                            <th>Date</th>
                                            <th>Heure</th>
                                            <th>Statut</th>
                                            <th>Notes admin</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($bookings as $booking): ?>
                                        <tr>
                                            <td><?= ucfirst($booking['booking_type']) ?></td>
                                            <td><?= date('d/m/Y', strtotime($booking['preferred_date'])) ?></td>
                                            <td><?= $booking['preferred_time'] ?: '-' ?></td>
                                            <td>
                                                <?php if ($booking['status'] === 'pending'): ?>
                                                    <span class="badge bg-warning text-dark">En attente</span>
                                                <?php elseif ($booking['status'] === 'approved'): ?>
                                                    <span class="badge bg-success">Approuve</span>
                                                <?php elseif ($booking['status'] === 'rejected'): ?>
                                                    <span class="badge bg-danger">Refuse</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Termine</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-muted small"><?= htmlspecialchars($booking['admin_notes'] ?? '-') ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted text-center py-4 mb-0">Aucune reservation</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

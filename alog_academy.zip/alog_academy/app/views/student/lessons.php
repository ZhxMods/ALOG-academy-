<section class="py-4">
    <div class="container">
        <h1 class="h3 fw-bold mb-1">Mes Cours</h1>
        <p class="text-muted mb-4">Explorez les lecons disponibles pour votre niveau</p>

        <?php if (!empty($lessons_by_subject)): ?>
            <?php foreach ($lessons_by_subject as $subjectData): ?>
            <div class="mb-4">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="rounded-2 d-flex align-items-center justify-content-center" style="width:36px;height:36px;background:<?= $subjectData['subject']['color'] ?? '#2563eb' ?>20;color:<?= $subjectData['subject']['color'] ?? '#2563eb' ?>">
                        <i class="bi bi-<?= $subjectData['subject']['icon'] ?? 'book' ?>"></i>
                    </div>
                    <h4 class="fw-bold mb-0"><?= htmlspecialchars($subjectData['subject']['name']) ?></h4>
                </div>

                <div class="row g-3">
                    <?php foreach ($subjectData['lessons'] as $lesson): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card lesson-card h-100 border-0 shadow-sm <?= $lesson['is_completed'] ? 'border-success' : '' ?>">
                            <div class="card-img-top position-relative bg-light" style="height:160px">
                                <?php if (!empty($lesson['thumbnail_url'])): ?>
                                    <img src="<?= htmlspecialchars($lesson['thumbnail_url']) ?>" class="w-100 h-100 object-fit-cover rounded-top" alt="" loading="lazy">
                                <?php else: ?>
                                    <div class="d-flex align-items-center justify-content-center h-100">
                                        <i class="bi bi-play-circle text-primary" style="font-size:2.5rem"></i>
                                    </div>
                                <?php endif; ?>
                                <span class="badge bg-dark position-absolute top-0 start-0 m-2"><?= strtoupper($lesson['access_type']) ?></span>
                                <?php if ($lesson['is_completed']): ?>
                                    <span class="badge bg-success position-absolute top-0 end-0 m-2"><i class="bi bi-check-lg"></i></span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body p-3">
                                <h6 class="fw-bold mb-1"><?= htmlspecialchars($lesson['title']) ?></h6>
                                <p class="text-muted small mb-2"><?= htmlspecialchars(substr($lesson['description'] ?? '', 0, 80)) ?>...</p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="badge bg-primary bg-opacity-10 text-primary small">+<?= $lesson['xp_reward'] ?> XP</span>
                                    <a href="<?= BASE_URL ?>/cours/<?= $lesson['slug'] ?>" class="btn btn-sm btn-primary">
                                        <?= $lesson['is_completed'] ? 'Revoir' : 'Commencer' ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="text-center py-5">
                <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:80px;height:80px">
                    <i class="bi bi-book text-muted" style="font-size:2rem"></i>
                </div>
                <h5 class="text-muted">Aucun cours disponible pour votre niveau</h5>
                <p class="text-muted">Contactez l'administration pour plus d'informations.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

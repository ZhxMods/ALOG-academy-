<section class="py-4">
    <div class="container">
        <nav aria-label="breadcrumb" class="mb-3">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/cours">Cours</a></li>
                <li class="breadcrumb-item active"><?= htmlspecialchars(substr($lesson['title'], 0, 40)) ?>...</li>
            </ol>
        </nav>

        <div class="row g-4">
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-2 mb-3">
                            <span class="badge bg-primary"><?= strtoupper($lesson['access_type']) ?></span>
                            <span class="badge bg-primary bg-opacity-10 text-primary">+<?= $lesson['xp_reward'] ?> XP</span>
                            <?php if ($progress['is_completed'] ?? false): ?>
                                <span class="badge bg-success"><i class="bi bi-check-lg me-1"></i>Termine</span>
                            <?php endif; ?>
                        </div>

                        <h1 class="h3 fw-bold mb-3"><?= htmlspecialchars($lesson['title']) ?></h1>
                        <p class="text-muted"><?= htmlspecialchars($lesson['description'] ?? '') ?></p>

                        <?php if (!empty($lesson['video_url'])): ?>
                        <div class="ratio ratio-16x9 rounded-3 overflow-hidden mb-4 bg-dark">
                            <iframe src="<?= htmlspecialchars($lesson['video_url']) ?>" title="<?= htmlspecialchars($lesson['title']) ?>" allowfullscreen loading="lazy"></iframe>
                        </div>
                        <?php endif; ?>

                        <div class="d-flex flex-wrap gap-2">
                            <?php if (!empty($lesson['pdf_url'])): ?>
                                <a href="<?= htmlspecialchars($lesson['pdf_url']) ?>" target="_blank" class="btn btn-outline-primary">
                                    <i class="bi bi-file-earmark-pdf me-2"></i>Voir le PDF
                                </a>
                            <?php endif; ?>
                            <?php if (!empty($lesson['exercise_pdf_url'])): ?>
                                <a href="<?= htmlspecialchars($lesson['exercise_pdf_url']) ?>" target="_blank" class="btn btn-outline-success">
                                    <i class="bi bi-file-earmark-text me-2"></i>Exercices
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Complete Lesson -->
                <?php if (!($progress['is_completed'] ?? false)): ?>
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3">Terminer cette lecon</h5>
                        <p class="text-muted small">Marquez cette lecon comme terminee pour gagner <?= $lesson['xp_reward'] ?> XP.</p>
                        <form method="POST" action="<?= BASE_URL ?>/cours/complete">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                            <input type="hidden" name="lesson_id" value="<?= $lesson['id'] ?>">
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-success">
                                    <i class="bi bi-check-lg me-2"></i>Marquer comme terminee
                                </button>
                                <button type="submit" name="skipped" value="1" class="btn btn-outline-secondary">
                                    Passer
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Quiz -->
                <?php if ($quiz): ?>
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <div class="bg-warning bg-opacity-10 text-warning rounded-3 d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                                <i class="bi bi-question-circle fs-4"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-0">Quiz: <?= htmlspecialchars($quiz['title']) ?></h5>
                                <small class="text-muted"><?= $quiz['xp_reward'] ?> XP a gagner</small>
                            </div>
                        </div>
                        <a href="<?= BASE_URL ?>/quiz/<?= $quiz['id'] ?>" class="btn btn-primary w-100">
                            <i class="bi bi-play-fill me-2"></i>Commencer le Quiz
                        </a>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3">Progression</h5>
                        <div class="progress mb-2" style="height:8px">
                            <div class="progress-bar bg-success" style="width:<?= $progress['progress_percent'] ?? 0 ?>%"></div>
                        </div>
                        <small class="text-muted"><?= $progress['progress_percent'] ?? 0 ?>% complete</small>

                        <hr class="my-3">

                        <div class="d-flex justify-content-between small mb-1">
                            <span class="text-muted">Statut</span>
                            <span class="fw-medium <?= ($progress['is_completed'] ?? false) ? 'text-success' : 'text-muted' ?>">
                                <?= ($progress['is_completed'] ?? false) ? 'Termine' : 'En cours' ?>
                            </span>
                        </div>
                        <div class="d-flex justify-content-between small mb-1">
                            <span class="text-muted">Type d'acces</span>
                            <span class="fw-medium"><?= strtoupper($lesson['access_type']) ?></span>
                        </div>
                        <div class="d-flex justify-content-between small">
                            <span class="text-muted">Recompense</span>
                            <span class="fw-medium text-primary">+<?= $lesson['xp_reward'] ?> XP</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

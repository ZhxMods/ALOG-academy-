<section class="py-4">
    <div class="container">
        <h1 class="h3 fw-bold mb-4"><i class="bi bi-trophy me-2 text-warning"></i>Classement</h1>

        <ul class="nav nav-pills mb-4" id="rankingTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#global" type="button">
                    <i class="bi bi-globe me-1"></i>National
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" data-bs-toggle="pill" data-bs-target="#regional" type="button">
                    <i class="bi bi-geo-alt me-1"></i>Regional
                </button>
            </li>
        </ul>

        <div class="tab-content">
            <div class="tab-pane fade show active" id="global">
                <div class="card border-0 shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">#</th>
                                    <th>Etudiant</th>
                                    <th>Region</th>
                                    <th>Niveau</th>
                                    <th>XP</th>
                                    <th>Lecons</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($global_top as $rank): ?>
                                <tr <?= ($rank['id'] ?? 0) == ($user['id'] ?? 0) ? 'class="table-primary"' : '' ?>>
                                    <td class="ps-4 fw-bold"><?= $rank['global_rank'] ?></td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:32px;height:32px;font-size:0.75rem">
                                                <?= strtoupper(substr($rank['first_name'] ?? '', 0, 1) . substr($rank['last_name'] ?? '', 0, 1)) ?>
                                            </div>
                                            <span class="fw-medium"><?= htmlspecialchars(($rank['first_name'] ?? '') . ' ' . ($rank['last_name'] ?? '')) ?></span>
                                        </div>
                                    </td>
                                    <td><?= htmlspecialchars($rank['region_name'] ?? '-') ?></td>
                                    <td><span class="badge bg-primary bg-opacity-10 text-primary">Niv. <?= $rank['current_level'] ?></span></td>
                                    <td class="fw-bold text-primary"><?= $rank['total_xp'] ?></td>
                                    <td><?= $rank['completed_lessons'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="regional">
                <?php if (!empty($regional_top)): ?>
                <div class="card border-0 shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">#</th>
                                    <th>Etudiant</th>
                                    <th>Niveau</th>
                                    <th>XP</th>
                                    <th>Lecons</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($regional_top as $rank): ?>
                                <tr <?= ($rank['id'] ?? 0) == ($user['id'] ?? 0) ? 'class="table-primary"' : '' ?>>
                                    <td class="ps-4 fw-bold"><?= $rank['regional_rank'] ?></td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:32px;height:32px;font-size:0.75rem">
                                                <?= strtoupper(substr($rank['first_name'] ?? '', 0, 1) . substr($rank['last_name'] ?? '', 0, 1)) ?>
                                            </div>
                                            <span class="fw-medium"><?= htmlspecialchars(($rank['first_name'] ?? '') . ' ' . ($rank['last_name'] ?? '')) ?></span>
                                        </div>
                                    </td>
                                    <td><span class="badge bg-primary bg-opacity-10 text-primary">Niv. <?= $rank['current_level'] ?></span></td>
                                    <td class="fw-bold text-primary"><?= $rank['total_xp'] ?></td>
                                    <td><?= $rank['completed_lessons'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php else: ?>
                <div class="text-center py-5">
                    <p class="text-muted">Aucune donnee regionale disponible.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 text-center">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-5">
                        <div class="result-icon mb-4">
                            <?php if ($passed): ?>
                                <div class="bg-success bg-opacity-10 text-success rounded-circle d-inline-flex align-items-center justify-content-center" style="width:100px;height:100px">
                                    <i class="bi bi-trophy fs-1"></i>
                                </div>
                            <?php else: ?>
                                <div class="bg-warning bg-opacity-10 text-warning rounded-circle d-inline-flex align-items-center justify-content-center" style="width:100px;height:100px">
                                    <i class="bi bi-arrow-repeat fs-1"></i>
                                </div>
                            <?php endif; ?>
                        </div>

                        <h2 class="fw-bold mb-2"><?= $passed ? 'Felicitations !' : 'Presque !' ?></h2>
                        <p class="text-muted mb-4"><?= $passed ? 'Vous avez reussi ce quiz.' : 'Vous pouvez reessayer apres le delai de cooldown.' ?></p>

                        <div class="score-circle mb-4">
                            <div class="h1 fw-bold mb-0 <?= $passed ? 'text-success' : 'text-warning' ?>"><?= $score ?>%</div>
                            <small class="text-muted"><?= $correct ?>/<?= $total ?> correct</small>
                        </div>

                        <?php if ($xp_earned > 0): ?>
                        <div class="alert alert-success">
                            <i class="bi bi-lightning-charge me-2"></i>+<?= $xp_earned ?> XP gagnes !
                        </div>
                        <?php endif; ?>

                        <div class="d-flex gap-2 justify-content-center mt-4">
                            <a href="<?= BASE_URL ?>/dashboard" class="btn btn-primary">
                                <i class="bi bi-grid me-2"></i>Dashboard
                            </a>
                            <a href="<?= BASE_URL ?>/cours" class="btn btn-outline-primary">
                                <i class="bi bi-book me-2"></i>Cours
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

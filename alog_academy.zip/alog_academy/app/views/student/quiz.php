<section class="py-4">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="mb-4">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/dashboard">Dashboard</a></li>
                            <li class="breadcrumb-item active">Quiz</li>
                        </ol>
                    </nav>
                    <h1 class="h3 fw-bold"><?= htmlspecialchars($quiz['title']) ?></h1>
                    <p class="text-muted"><?= htmlspecialchars($quiz['description'] ?? '') ?></p>
                    <div class="d-flex gap-2">
                        <span class="badge bg-primary bg-opacity-10 text-primary"><?= count($questions) ?> questions</span>
                        <span class="badge bg-warning bg-opacity-10 text-warning"><?= $quiz['xp_reward'] ?> XP</span>
                        <span class="badge bg-info bg-opacity-10 text-info"><?= $quiz['passing_score'] ?>% pour reussir</span>
                    </div>
                </div>

                <form method="POST" action="<?= BASE_URL ?>/quiz/submit" id="quizForm">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    <input type="hidden" name="quiz_id" value="<?= $quiz['id'] ?>">

                    <?php foreach ($questions as $index => $question): ?>
                    <div class="card quiz-question border-0 shadow-sm mb-3">
                        <div class="card-body p-4">
                            <div class="d-flex gap-3 mb-3">
                                <span class="question-number bg-primary text-white rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:32px;height:32px">
                                    <?= $index + 1 ?>
                                </span>
                                <h6 class="fw-bold mb-0 pt-1"><?= htmlspecialchars($question['question_text']) ?></h6>
                            </div>

                            <div class="ms-5">
                                <?php foreach ($question['answers'] as $answer): ?>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="answers[<?= $question['id'] ?>]" id="q<?= $question['id'] ?>_a<?= $answer['id'] ?>" value="<?= $answer['id'] ?>" required>
                                    <label class="form-check-label" for="q<?= $question['id'] ?>_a<?= $answer['id'] ?>">
                                        <?= htmlspecialchars($answer['answer_text']) ?>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="bi bi-check-lg me-2"></i>Soumettre mes reponses
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

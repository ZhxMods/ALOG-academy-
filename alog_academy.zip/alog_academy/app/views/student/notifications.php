<section class="py-4">
    <div class="container">
        <h1 class="h3 fw-bold mb-4">Notifications</h1>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <?php if (!empty($notifications)): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($notifications as $notif): ?>
                        <div class="list-group-item p-4 d-flex align-items-start gap-3 <?= $notif['is_read'] ? '' : 'bg-primary bg-opacity-5' ?>">
                            <div class="bg-<?= match($notif['type']) {
                                'xp' => 'success',
                                'level_up' => 'warning',
                                'payment_approved' => 'success',
                                'quiz_result' => 'info',
                                default => 'primary'
                            } ?> bg-opacity-10 text-<?= match($notif['type']) {
                                'xp' => 'success',
                                'level_up' => 'warning',
                                'payment_approved' => 'success',
                                'quiz_result' => 'info',
                                default => 'primary'
                            } ?> rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px">
                                <i class="bi bi-<?= match($notif['type']) {
                                    'xp' => 'lightning-charge',
                                    'level_up' => 'trophy',
                                    'payment_approved' => 'check-circle',
                                    'quiz_result' => 'clipboard-check',
                                    default => 'bell'
                                } ?>"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between align-items-start">
                                    <h6 class="fw-bold mb-1"><?= htmlspecialchars($notif['title']) ?></h6>
                                    <small class="text-muted"><?= date('d/m H:i', strtotime($notif['created_at'])) ?></small>
                                </div>
                                <p class="text-muted small mb-0"><?= htmlspecialchars($notif['message'] ?? '') ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:64px;height:64px">
                            <i class="bi bi-bell text-muted" style="font-size:1.5rem"></i>
                        </div>
                        <p class="text-muted">Aucune notification</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

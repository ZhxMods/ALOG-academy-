<section class="py-4">
    <div class="container">
        <h1 class="h3 fw-bold mb-4">Mes Abonnements</h1>

        <!-- Current Plan -->
        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="card pricing-card border-0 shadow-sm h-100 <?= ($active['plan_type'] ?? '') === 'free' ? 'border-primary' : '' ?>">
                    <div class="card-body p-4 text-center">
                        <h5 class="fw-bold">GRATUIT</h5>
                        <div class="h3 fw-bold text-primary my-2">0 <small class="fs-6">MAD</small></div>
                        <ul class="list-unstyled text-muted small text-start mb-3">
                            <li><i class="bi bi-check text-success me-2"></i>Cours limites</li>
                            <li><i class="bi bi-check text-success me-2"></i>Quiz basiques</li>
                        </ul>
                        <?php if (($active['plan_type'] ?? 'free') === 'free'): ?>
                            <span class="badge bg-success">Actif</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card pricing-card border-0 shadow-sm h-100 <?= ($active['plan_type'] ?? '') === 'pro' ? 'border-primary shadow' : '' ?>">
                    <div class="card-body p-4 text-center">
                        <h5 class="fw-bold">PRO</h5>
                        <div class="h3 fw-bold text-primary my-2"><?= $price_pro ?> <small class="fs-6">MAD/mois</small></div>
                        <ul class="list-unstyled text-muted small text-start mb-3">
                            <li><i class="bi bi-check text-success me-2"></i>Tous les cours</li>
                            <li><i class="bi bi-check text-success me-2"></i>Quiz illimites</li>
                            <li><i class="bi bi-check text-success me-2"></i>Sans publicite</li>
                        </ul>
                        <?php if (($active['plan_type'] ?? '') === 'pro'): ?>
                            <span class="badge bg-success">Actif</span>
                        <?php else: ?>
                            <form method="POST" action="<?= BASE_URL ?>/abonnements">
                                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                <input type="hidden" name="plan_type" value="pro">
                                <button type="submit" class="btn btn-outline-primary w-100 btn-sm">S'abonner</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card pricing-card border-0 shadow-sm h-100 <?= ($active['plan_type'] ?? '') === 'ultra' ? 'border-primary shadow' : '' ?>">
                    <div class="card-body p-4 text-center">
                        <h5 class="fw-bold">ULTRA</h5>
                        <div class="h3 fw-bold text-primary my-2"><?= $price_ultra ?> <small class="fs-6">MAD/mois</small></div>
                        <ul class="list-unstyled text-muted small text-start mb-3">
                            <li><i class="bi bi-check text-success me-2"></i>Acces complet</li>
                            <li><i class="bi bi-check text-success me-2"></i>Coaching groupe</li>
                            <li><i class="bi bi-check text-success me-2"></i>Support premium</li>
                        </ul>
                        <?php if (($active['plan_type'] ?? '') === 'ultra'): ?>
                            <span class="badge bg-success">Actif</span>
                        <?php else: ?>
                            <form method="POST" action="<?= BASE_URL ?>/abonnements">
                                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                <input type="hidden" name="plan_type" value="ultra">
                                <button type="submit" class="btn btn-outline-primary w-100 btn-sm">S'abonner</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Payment Proof Upload -->
        <?php if (!empty($payments)): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-0 pt-4 px-4">
                <h5 class="fw-bold mb-0"><i class="bi bi-credit-card me-2 text-primary"></i>Mes paiements</h5>
            </div>
            <div class="card-body px-4 pb-4">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Plan</th>
                                <th>Montant</th>
                                <th>Statut</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($payments as $payment): ?>
                            <tr>
                                <td><span class="badge bg-primary"><?= strtoupper($payment['plan_type']) ?></span></td>
                                <td><?= $payment['amount'] ?> MAD</td>
                                <td>
                                    <?php if ($payment['status'] === 'pending'): ?>
                                        <span class="badge bg-warning text-dark">En attente</span>
                                    <?php elseif ($payment['status'] === 'approved'): ?>
                                        <span class="badge bg-success">Approuve</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Refuse</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= date('d/m/Y', strtotime($payment['created_at'])) ?></td>
                                <td>
                                    <?php if ($payment['status'] === 'pending' && empty($payment['proof_image'])): ?>
                                        <form method="POST" action="<?= BASE_URL ?>/abonnements/proof" enctype="multipart/form-data" class="d-flex gap-2">
                                            <input type="hidden" name="payment_id" value="<?= $payment['id'] ?>">
                                            <input type="file" name="proof" class="form-control form-control-sm" accept="image/*" required>
                                            <button type="submit" class="btn btn-sm btn-primary">Envoyer</button>
                                        </form>
                                    <?php elseif (!empty($payment['proof_image'])): ?>
                                        <span class="badge bg-info">Preuve envoyee</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- WhatsApp Payment Info -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-success bg-opacity-10 text-success rounded-3 d-flex align-items-center justify-content-center" style="width:56px;height:56px">
                        <i class="bi bi-whatsapp fs-3"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold mb-1">Paiement par WhatsApp</h5>
                        <p class="text-muted mb-0">Effectuez votre paiement sur WhatsApp puis telechargez la preuve ici.</p>
                    </div>
                    <a href="https://wa.me/<?= str_replace('+', '', WHATSAPP_NUMBER) ?>?text=Bonjour,%20je%20souhaite%20m'abonner%20a%20ALOG%20ACADEMY" class="btn btn-success ms-auto" target="_blank">
                        <i class="bi bi-whatsapp me-2"></i>Payer
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

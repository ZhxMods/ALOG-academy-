<section class="py-4">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-4 mb-4">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:80px;height:80px;font-size:2rem">
                                <?= strtoupper(substr($user['first_name'], 0, 1)) ?>
                            </div>
                            <div>
                                <h3 class="fw-bold mb-1"><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></h3>
                                <p class="text-muted mb-0"><?= htmlspecialchars($user['email']) ?></p>
                                <span class="badge bg-primary bg-opacity-10 text-primary mt-1">Niveau <?= $stats['level']['current_level'] ?? 1 ?></span>
                            </div>
                        </div>

                        <div class="row g-3 mb-4">
                            <div class="col-6 col-md-3 text-center">
                                <div class="h4 fw-bold text-primary mb-0"><?= $stats['level']['total_xp'] ?? 0 ?></div>
                                <small class="text-muted">XP Total</small>
                            </div>
                            <div class="col-6 col-md-3 text-center">
                                <div class="h4 fw-bold text-success mb-0"><?= $stats['completed_lessons'] ?></div>
                                <small class="text-muted">Lecons</small>
                            </div>
                            <div class="col-6 col-md-3 text-center">
                                <div class="h4 fw-bold text-warning mb-0"><?= $stats['quizzes_taken'] ?></div>
                                <small class="text-muted">Quiz</small>
                            </div>
                            <div class="col-6 col-md-3 text-center">
                                <div class="h4 fw-bold text-info mb-0"><?= $stats['average_score'] ?>%</div>
                                <small class="text-muted">Moyenne</small>
                            </div>
                        </div>

                        <form method="POST" action="<?= BASE_URL ?>/profil">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Prenom</label>
                                    <input type="text" name="first_name" class="form-control" value="<?= htmlspecialchars($user['first_name']) ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Nom</label>
                                    <input type="text" name="last_name" class="form-control" value="<?= htmlspecialchars($user['last_name']) ?>">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Telephone</label>
                                <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                            </div>

                            <div class="mb-4">
                                <label class="form-label">Bio</label>
                                <textarea name="bio" class="form-control" rows="3"><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-lg me-2"></i>Mettre a jour
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Blog</h4>
        <p class="text-muted small mb-0">Gestion des articles</p>
    </div>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#blogModal">
        <i class="bi bi-plus-lg me-1"></i>Ajouter
    </button>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th class="ps-4">ID</th><th>Titre</th><th>Categorie</th><th>Vues</th><th>Statut</th></tr>
            </thead>
            <tbody>
                <?php foreach ($posts as $post): ?>
                <tr>
                    <td class="ps-4"><?= $post['id'] ?></td>
                    <td class="fw-medium"><?= htmlspecialchars($post['title']) ?></td>
                    <td><span class="badge bg-secondary bg-opacity-10 text-secondary"><?= htmlspecialchars($post['category'] ?? '-') ?></span></td>
                    <td><?= $post['views_count'] ?></td>
                    <td><span class="badge bg-<?= match($post['status']) { 'published' => 'success', 'draft' => 'warning', default => 'secondary' } ?>"><?= ucfirst($post['status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="blogModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Nouvel article</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?= BASE_URL ?>/admin/blog">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    <div class="mb-3">
                        <label class="form-label">Titre</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Categorie</label>
                            <select name="category" class="form-select">
                                <option value="Conseils Bac">Conseils Bac</option>
                                <option value="Methodes de Revision">Methodes de Revision</option>
                                <option value="Orientation">Orientation</option>
                                <option value="Motivation">Motivation</option>
                                <option value="Productivite">Productivite</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Image URL</label>
                            <input type="url" name="featured_image" class="form-control">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Resume</label>
                        <textarea name="excerpt" class="form-control" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Contenu (HTML supporte)</label>
                        <textarea name="content" class="form-control" rows="6" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Statut</label>
                        <select name="status" class="form-select">
                            <option value="draft">Brouillon</option>
                            <option value="published">Publier</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Publier</button>
                </div>
            </form>
        </div>
    </div>
</div>

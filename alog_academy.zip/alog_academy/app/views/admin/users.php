<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Utilisateurs</h4>
        <p class="text-muted small mb-0">Gestion des etudiants inscrits</p>
    </div>
    <form method="GET" action="<?= BASE_URL ?>/admin/utilisateurs" class="d-flex gap-2">
        <input type="text" name="search" class="form-control form-control-sm" placeholder="Rechercher..." value="<?= htmlspecialchars($search ?? '') ?>">
        <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-search"></i></button>
    </form>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-4">ID</th>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Telephone</th>
                    <th>Inscription</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td class="ps-4"><?= $u['id'] ?></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:32px;height:32px;font-size:0.75rem">
                                <?= strtoupper(substr($u['first_name'], 0, 1) . substr($u['last_name'], 0, 1)) ?>
                            </div>
                            <span class="fw-medium"><?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']) ?></span>
                        </div>
                    </td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td><?= htmlspecialchars($u['phone'] ?? '-') ?></td>
                    <td><?= date('d/m/Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <?php if ($u['status'] === 'active'): ?>
                            <span class="badge bg-success">Actif</span>
                        <?php elseif ($u['status'] === 'banned'): ?>
                            <span class="badge bg-danger">Banni</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Inactif</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="POST" action="<?= BASE_URL ?>/admin/utilisateurs/status" class="d-inline">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <select name="status" class="form-select form-select-sm d-inline w-auto" onchange="this.form.submit()">
                                <option value="active" <?= $u['status'] === 'active' ? 'selected' : '' ?>>Actif</option>
                                <option value="inactive" <?= $u['status'] === 'inactive' ? 'selected' : '' ?>>Inactif</option>
                                <option value="banned" <?= $u['status'] === 'banned' ? 'selected' : '' ?>>Banni</option>
                            </select>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if ($total_pages > 1): ?>
    <div class="card-footer bg-white border-0">
        <nav>
            <ul class="pagination justify-content-center mb-0">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                    <a class="page-link" href="<?= BASE_URL ?>/admin/utilisateurs?page=<?= $i ?><?= $search ? '&search=' . urlencode($search) : '' ?>"><?= $i ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

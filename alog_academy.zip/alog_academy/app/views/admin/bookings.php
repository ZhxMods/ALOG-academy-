<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Reservations</h4>
        <p class="text-muted small mb-0">Gestion des demandes de tutorat et coaching</p>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-4">ID</th>
                    <th>Utilisateur</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>WhatsApp</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $booking): ?>
                <tr>
                    <td class="ps-4"><?= $booking['id'] ?></td>
                    <td class="fw-medium"><?= htmlspecialchars(($booking['first_name'] ?? '') . ' ' . ($booking['last_name'] ?? '')) ?></td>
                    <td><?= ucfirst($booking['booking_type']) ?></td>
                    <td><?= date('d/m/Y', strtotime($booking['preferred_date'])) ?> <?= $booking['preferred_time'] ? 'a ' . $booking['preferred_time'] : '' ?></td>
                    <td><?= htmlspecialchars($booking['whatsapp'] ?? '-') ?></td>
                    <td>
                        <?php if ($booking['status'] === 'pending'): ?>
                            <span class="badge bg-warning text-dark">En attente</span>
                        <?php elseif ($booking['status'] === 'approved'): ?>
                            <span class="badge bg-success">Approuve</span>
                        <?php elseif ($booking['status'] === 'rejected'): ?>
                            <span class="badge bg-danger">Refuse</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Termine</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="POST" action="<?= BASE_URL ?>/admin/reservations" class="d-flex gap-1">
                            <input type="hidden" name="booking_id" value="<?= $booking['id'] ?>">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                            <select name="status" class="form-select form-select-sm w-auto" onchange="this.form.submit()">
                                <option value="pending" <?= $booking['status'] === 'pending' ? 'selected' : '' ?>>En attente</option>
                                <option value="approved" <?= $booking['status'] === 'approved' ? 'selected' : '' ?>>Approuver</option>
                                <option value="rejected" <?= $booking['status'] === 'rejected' ? 'selected' : '' ?>>Refuser</option>
                                <option value="completed" <?= $booking['status'] === 'completed' ? 'selected' : '' ?>>Termine</option>
                            </select>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

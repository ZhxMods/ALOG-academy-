<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Matieres</h4>
        <p class="text-muted small mb-0">Gestion des matieres par niveau</p>
    </div>
    <button class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Ajouter</button>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th class="ps-4">ID</th><th>Nom</th><th>Niveau</th><th>Couleur</th><th>Statut</th></tr>
            </thead>
            <tbody>
                <?php foreach ($subjects as $subject): ?>
                <tr>
                    <td class="ps-4"><?= $subject['id'] ?></td>
                    <td class="fw-medium"><?= htmlspecialchars($subject['name']) ?></td>
                    <td><?= htmlspecialchars($levels[array_search($subject['level_id'], array_column($levels, 'id'))]['name'] ?? '-') ?></td>
                    <td><span class="badge" style="background:<?= $subject['color'] ?>"><?= $subject['color'] ?></span></td>
                    <td><span class="badge bg-<?= $subject['status'] === 'active' ? 'success' : 'secondary' ?>"><?= ucfirst($subject['status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Parametres</h4>
        <p class="text-muted small mb-0">Configuration du site</p>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <form method="POST" action="<?= BASE_URL ?>/admin/parametres">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

            <h6 class="fw-bold mb-3">General</h6>
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label">Nom du site</label>
                    <input type="text" name="settings[site_name]" class="form-control" value="<?= htmlspecialchars($settings[array_search('site_name', array_column($settings, 'setting_key'))]['setting_value'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Slogan</label>
                    <input type="text" name="settings[site_tagline]" class="form-control" value="<?= htmlspecialchars($settings[array_search('site_tagline', array_column($settings, 'setting_key'))]['setting_value'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">WhatsApp</label>
                    <input type="text" name="settings[whatsapp_number]" class="form-control" value="<?= htmlspecialchars($settings[array_search('whatsapp_number', array_column($settings, 'setting_key'))]['setting_value'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email contact</label>
                    <input type="email" name="settings[contact_email]" class="form-control" value="<?= htmlspecialchars($settings[array_search('contact_email', array_column($settings, 'setting_key'))]['setting_value'] ?? '') ?>">
                </div>
            </div>

            <h6 class="fw-bold mb-3">Tarifs</h6>
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label">Prix PRO (MAD)</label>
                    <input type="number" name="settings[price_pro]" class="form-control" value="<?= htmlspecialchars($settings[array_search('price_pro', array_column($settings, 'setting_key'))]['setting_value'] ?? '49') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Prix ULTRA (MAD)</label>
                    <input type="number" name="settings[price_ultra]" class="form-control" value="<?= htmlspecialchars($settings[array_search('price_ultra', array_column($settings, 'setting_key'))]['setting_value'] ?? '99') ?>">
                </div>
            </div>

            <h6 class="fw-bold mb-3">XP</h6>
            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <label class="form-label">XP connexion</label>
                    <input type="number" name="settings[xp_login_daily]" class="form-control" value="<?= htmlspecialchars($settings[array_search('xp_login_daily', array_column($settings, 'setting_key'))]['setting_value'] ?? '10') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">XP lecon</label>
                    <input type="number" name="settings[xp_lesson_complete]" class="form-control" value="<?= htmlspecialchars($settings[array_search('xp_lesson_complete', array_column($settings, 'setting_key'))]['setting_value'] ?? '50') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">XP quiz</label>
                    <input type="number" name="settings[xp_quiz_pass]" class="form-control" value="<?= htmlspecialchars($settings[array_search('xp_quiz_pass', array_column($settings, 'setting_key'))]['setting_value'] ?? '30') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">XP parfait</label>
                    <input type="number" name="settings[xp_quiz_perfect]" class="form-control" value="<?= htmlspecialchars($settings[array_search('xp_quiz_perfect', array_column($settings, 'setting_key'))]['setting_value'] ?? '50') ?>">
                </div>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save me-2"></i>Enregistrer les parametres
            </button>
        </form>
    </div>
</div>

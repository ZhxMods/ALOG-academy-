<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Lecons</h4>
        <p class="text-muted small mb-0">Gestion du contenu educatif</p>
    </div>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#lessonModal">
        <i class="bi bi-plus-lg me-1"></i>Ajouter
    </button>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-4">ID</th>
                    <th>Titre</th>
                    <th>Matiere</th>
                    <th>Acces</th>
                    <th>XP</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lessons as $lesson): ?>
                <tr>
                    <td class="ps-4"><?= $lesson['id'] ?></td>
                    <td class="fw-medium"><?= htmlspecialchars($lesson['title']) ?></td>
                    <td><?= htmlspecialchars($subjects[array_search($lesson['subject_id'], array_column($subjects, 'id'))]['name'] ?? '-') ?></td>
                    <td><span class="badge bg-<?= match($lesson['access_type']) { 'free' => 'success', 'pro' => 'primary', 'ultra' => 'dark', default => 'warning' } ?>"><?= strtoupper($lesson['access_type']) ?></span></td>
                    <td><?= $lesson['xp_reward'] ?></td>
                    <td><span class="badge bg-<?= $lesson['status'] === 'active' ? 'success' : ($lesson['status'] === 'draft' ? 'warning' : 'secondary') ?>"><?= ucfirst($lesson['status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="lessonModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Ajouter une lecon</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?= BASE_URL ?>/admin/lecons">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Titre</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Matiere</label>
                            <select name="subject_id" class="form-select" required>
                                <?php foreach ($subjects as $subj): ?>
                                <option value="<?= $subj['id'] ?>"><?= htmlspecialchars($subj['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="2"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">URL Video YouTube</label>
                            <input type="url" name="video_url" class="form-control" placeholder="https://youtube.com/embed/...">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">URL PDF</label>
                            <input type="url" name="pdf_url" class="form-control" placeholder="https://github.com/...">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">XP Recompense</label>
                            <input type="number" name="xp_reward" class="form-control" value="50">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Type d'acces</label>
                            <select name="access_type" class="form-select">
                                <option value="free">Gratuit</option>
                                <option value="pro">Pro</option>
                                <option value="ultra">Ultra</option>
                                <option value="xp_purchase">Achat XP</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Statut</label>
                            <select name="status" class="form-select">
                                <option value="draft">Brouillon</option>
                                <option value="active">Actif</option>
                                <option value="inactive">Inactif</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
</div>

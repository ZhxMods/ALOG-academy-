<div class="row g-4 mb-4">
    <div class="col-md-3 col-6">
        <div class="card stat-card-admin border-0 shadow-sm h-100">
            <div class="card-body p-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-primary bg-opacity-10 text-primary rounded-3 d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                        <i class="bi bi-people fs-5"></i>
                    </div>
                    <div>
                        <div class="h4 fw-bold mb-0"><?= $stats['total_users'] ?></div>
                        <small class="text-muted">Utilisateurs</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card stat-card-admin border-0 shadow-sm h-100">
            <div class="card-body p-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-success bg-opacity-10 text-success rounded-3 d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                        <i class="bi bi-credit-card fs-5"></i>
                    </div>
                    <div>
                        <div class="h4 fw-bold mb-0"><?= $stats['active_subscriptions'] ?></div>
                        <small class="text-muted">Abonnements actifs</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card stat-card-admin border-0 shadow-sm h-100">
            <div class="card-body p-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-warning bg-opacity-10 text-warning rounded-3 d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                        <i class="bi bi-wallet fs-5"></i>
                    </div>
                    <div>
                        <div class="h4 fw-bold mb-0"><?= $stats['pending_payments'] ?></div>
                        <small class="text-muted">Paiements en attente</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card stat-card-admin border-0 shadow-sm h-100">
            <div class="card-body p-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-info bg-opacity-10 text-info rounded-3 d-flex align-items-center justify-content-center" style="width:48px;height:48px">
                        <i class="bi bi-person-plus fs-5"></i>
                    </div>
                    <div>
                        <div class="h4 fw-bold mb-0"><?= $stats['today_registrations'] ?></div>
                        <small class="text-muted">Inscriptions aujourd'hui</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
                <h5 class="fw-bold mb-0"><i class="bi bi-people me-2 text-primary"></i>Inscriptions recentes</h5>
                <a href="<?= BASE_URL ?>/admin/utilisateurs" class="btn btn-sm btn-outline-primary">Voir tout</a>
            </div>
            <div class="card-body px-4 pb-4">
                <?php if (!empty($recent_users)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>Nom</th><th>Email</th><th>Date</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_users as $u): ?>
                            <tr>
                                <td><?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']) ?></td>
                                <td><?= htmlspecialchars($u['email']) ?></td>
                                <td><?= date('d/m/Y', strtotime($u['created_at'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <p class="text-muted text-center py-4 mb-0">Aucune inscription recente</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
                <h5 class="fw-bold mb-0"><i class="bi bi-credit-card me-2 text-warning"></i>Paiements en attente</h5>
                <a href="<?= BASE_URL ?>/admin/paiements" class="btn btn-sm btn-outline-primary">Voir tout</a>
            </div>
            <div class="card-body px-4 pb-4">
                <?php if (!empty($pending_payments)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>Utilisateur</th><th>Plan</th><th>Montant</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pending_payments as $p): ?>
                            <tr>
                                <td><?= htmlspecialchars($p['first_name'] . ' ' . $p['last_name']) ?></td>
                                <td><span class="badge bg-primary"><?= strtoupper($p['plan_type']) ?></span></td>
                                <td><?= $p['amount'] ?> MAD</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <p class="text-muted text-center py-4 mb-0">Aucun paiement en attente</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
        <h5 class="fw-bold mb-0"><i class="bi bi-calendar-check me-2 text-info"></i>Reservations en attente</h5>
        <a href="<?= BASE_URL ?>/admin/reservations" class="btn btn-sm btn-outline-primary">Voir tout</a>
    </div>
    <div class="card-body px-4 pb-4">
        <?php if (!empty($pending_bookings)): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr><th>Utilisateur</th><th>Type</th><th>Date</th><th>WhatsApp</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($pending_bookings as $b): ?>
                    <tr>
                        <td><?= htmlspecialchars($b['first_name'] . ' ' . $b['last_name']) ?></td>
                        <td><?= ucfirst($b['booking_type']) ?></td>
                        <td><?= date('d/m/Y', strtotime($b['preferred_date'])) ?></td>
                        <td><?= htmlspecialchars($b['whatsapp'] ?? '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <p class="text-muted text-center py-4 mb-0">Aucune reservation en attente</p>
        <?php endif; ?>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Validation des Paiements</h4>
        <p class="text-muted small mb-0">Approuvez ou refusez les paiements WhatsApp</p>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-4">ID</th>
                    <th>Utilisateur</th>
                    <th>Plan</th>
                    <th>Montant</th>
                    <th>Preuve</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($payments as $p): ?>
                <tr>
                    <td class="ps-4"><?= $p['id'] ?></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:32px;height:32px;font-size:0.75rem">
                                <?= strtoupper(substr($p['first_name'] ?? '', 0, 1)) ?>
                            </div>
                            <span class="fw-medium"><?= htmlspecialchars(($p['first_name'] ?? '') . ' ' . ($p['last_name'] ?? '')) ?></span>
                        </div>
                    </td>
                    <td><span class="badge bg-primary"><?= strtoupper($p['plan_type']) ?></span></td>
                    <td class="fw-bold"><?= $p['amount'] ?> MAD</td>
                    <td>
                        <?php if (!empty($p['proof_image'])): ?>
                            <a href="<?= BASE_URL ?>/<?= $p['proof_image'] ?>" target="_blank" class="btn btn-sm btn-outline-info">
                                <i class="bi bi-image me-1"></i>Voir
                            </a>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark">En attente</span>
                        <?php endif; ?>
                    </td>
                    <td><?= date('d/m/Y H:i', strtotime($p['created_at'])) ?></td>
                    <td>
                        <?php if ($p['status'] === 'pending'): ?>
                            <form method="POST" action="<?= BASE_URL ?>/admin/paiements/approuver" class="d-inline">
                                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-success me-1" onclick="return confirm('Approuver ce paiement ?')">
                                    <i class="bi bi-check-lg"></i>
                                </button>
                            </form>
                            <form method="POST" action="<?= BASE_URL ?>/admin/paiements/refuser" class="d-inline">
                                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Refuser ce paiement ?')">
                                    <i class="bi bi-x-lg"></i>
                                </button>
                            </form>
                        <?php elseif ($p['status'] === 'approved'): ?>
                            <span class="badge bg-success">Approuve</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Refuse</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

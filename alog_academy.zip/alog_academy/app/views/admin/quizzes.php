<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">Quiz</h4>
        <p class="text-muted small mb-0">Gestion des evaluations</p>
    </div>
    <button class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Ajouter</button>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th class="ps-4">ID</th><th>Titre</th><th>Lecon</th><th>Score min</th><th>XP</th><th>Statut</th></tr>
            </thead>
            <tbody>
                <?php foreach ($quizzes as $quiz): ?>
                <tr>
                    <td class="ps-4"><?= $quiz['id'] ?></td>
                    <td class="fw-medium"><?= htmlspecialchars($quiz['title']) ?></td>
                    <td><?= $quiz['lesson_id'] ? 'Lecon #' . $quiz['lesson_id'] : '-' ?></td>
                    <td><?= $quiz['passing_score'] ?>%</td>
                    <td><?= $quiz['xp_reward'] ?></td>
                    <td><span class="badge bg-<?= $quiz['status'] === 'active' ? 'success' : 'warning' ?>"><?= ucfirst($quiz['status']) ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Footer ALOG ACADEMY -->
<footer class="footer-alog py-5 mt-auto">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="d-flex align-items-center mb-3">
                    <i class="bi bi-mortarboard-fill fs-3 me-2 text-primary"></i>
                    <span class="fs-4 fw-bold">ALOG ACADEMY</span>
                </div>
                <p class="text-muted">La plateforme educative moderne pour les etudiants marocains. Cours video, quiz gamifies, et suivi de progression.</p>
                <div class="d-flex gap-3 mt-3">
                    <a href="#" class="social-link"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="social-link"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="social-link"><i class="bi bi-youtube"></i></a>
                    <a href="https://wa.me/<?= str_replace('+', '', WHATSAPP_NUMBER) ?>" class="social-link" target="_blank"><i class="bi bi-whatsapp"></i></a>
                </div>
            </div>

            <div class="col-lg-2 col-6">
                <h6 class="fw-bold mb-3">Liens</h6>
                <ul class="list-unstyled footer-links">
                    <li><a href="<?= BASE_URL ?>/">Accueil</a></li>
                    <li><a href="<?= BASE_URL ?>/cours">Cours</a></li>
                    <li><a href="<?= BASE_URL ?>/tarifs">Tarifs</a></li>
                    <li><a href="<?= BASE_URL ?>/blog">Blog</a></li>
                </ul>
            </div>

            <div class="col-lg-2 col-6">
                <h6 class="fw-bold mb-3">Support</h6>
                <ul class="list-unstyled footer-links">
                    <li><a href="<?= BASE_URL ?>/faq">FAQ</a></li>
                    <li><a href="<?= BASE_URL ?>/contact">Contact</a></li>
                    <li><a href="<?= BASE_URL ?>/a-propos">A Propos</a></li>
                </ul>
            </div>

            <div class="col-lg-4">
                <h6 class="fw-bold mb-3">Contact WhatsApp</h6>
                <p class="text-muted">Questions sur les abonnements ?</p>
                <a href="https://wa.me/<?= str_replace('+', '', WHATSAPP_NUMBER) ?>" class="btn btn-success w-100" target="_blank">
                    <i class="bi bi-whatsapp me-2"></i><?= WHATSAPP_NUMBER ?>
                </a>
            </div>
        </div>

        <hr class="my-4">

        <div class="text-center text-muted">
            <small>&copy; <?= date('Y') ?> ALOG ACADEMY. Tous droits reserves.</small>
        </div>
    </div>
</footer>

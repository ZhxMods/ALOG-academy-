<!-- Navbar ALOG ACADEMY -->
<nav class="navbar navbar-expand-lg navbar-alog sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="<?= BASE_URL ?>/">
            <div class="brand-icon me-2">
                <i class="bi bi-mortarboard-fill"></i>
            </div>
            <div class="brand-text">
                <span class="fw-bold">ALOG</span>
                <small class="d-block text-xs">ACADEMY</small>
            </div>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>/">Accueil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>/cours">Cours</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>/classement">Classement</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>/blog">Blog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>/tarifs">Tarifs</a>
                </li>
            </ul>

            <div class="d-flex align-items-center gap-2">
                <a href="<?= BASE_URL ?>/mode-sombre" class="btn btn-sm btn-outline-secondary" title="Mode sombre">
                    <i class="bi bi-<?= ($dark_mode ?? false) ? 'sun' : 'moon' ?>"></i>
                </a>

                <?php if (isset($user) && $user): ?>
                    <div class="dropdown">
                        <a class="btn btn-alog-primary dropdown-toggle d-flex align-items-center gap-2" href="#" data-bs-toggle="dropdown">
                            <?php if (!empty($user['profile_image'])): ?>
                                <img src="<?= BASE_URL ?>/<?= $user['profile_image'] ?>" class="rounded-circle" width="28" height="28" alt="">
                            <?php else: ?>
                                <div class="avatar-sm bg-white text-primary rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width:28px;height:28px">
                                    <?= strtoupper(substr($user['first_name'], 0, 1)) ?>
                                </div>
                            <?php endif; ?>
                            <span class="d-none d-sm-inline"><?= htmlspecialchars($user['first_name']) ?></span>
                            <?php if (($unread_notifications ?? 0) > 0): ?>
                                <span class="badge bg-danger"><?= $unread_notifications ?></span>
                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/dashboard"><i class="bi bi-grid me-2"></i>Tableau de bord</a></li>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/profil"><i class="bi bi-person me-2"></i>Mon Profil</a></li>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/abonnements"><i class="bi bi-credit-card me-2"></i>Abonnements</a></li>
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>/notifications"><i class="bi bi-bell me-2"></i>Notifications</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/logout"><i class="bi bi-box-arrow-right me-2"></i>Deconnexion</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>/login" class="btn btn-outline-primary">Connexion</a>
                    <a href="<?= BASE_URL ?>/inscription" class="btn btn-alog-primary">Inscription</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- Admin Navbar -->
<nav class="admin-navbar navbar navbar-expand-lg bg-body-tertiary border-bottom">
    <div class="container-fluid">
        <button class="btn btn-sm d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#adminSidebar">
            <i class="bi bi-list fs-5"></i>
        </button>

        <span class="navbar-text ms-auto">
            <?php if (isset($admin)): ?>
                <span class="d-flex align-items-center gap-2">
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:32px;height:32px">
                        <?= strtoupper(substr($admin['first_name'], 0, 1)) ?>
                    </div>
                    <span class="fw-medium d-none d-sm-inline"><?= htmlspecialchars($admin['first_name'] . ' ' . $admin['last_name']) ?></span>
                </span>
            <?php endif; ?>
        </span>
    </div>
</nav>

<!-- Mobile Sidebar Offcanvas -->
<div class="offcanvas offcanvas-start d-lg-none" tabindex="-1" id="adminSidebar">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">ALOG Admin</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body">
        <ul class="nav nav-pills flex-column gap-1">
            <li><a href="<?= BASE_URL ?>/admin/dashboard" class="nav-link"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
            <li><a href="<?= BASE_URL ?>/admin/utilisateurs" class="nav-link"><i class="bi bi-people me-2"></i>Utilisateurs</a></li>
            <li><a href="<?= BASE_URL ?>/admin/paiements" class="nav-link"><i class="bi bi-credit-card me-2"></i>Paiements</a></li>
            <li><a href="<?= BASE_URL ?>/admin/niveaux" class="nav-link"><i class="bi bi-layers me-2"></i>Niveaux</a></li>
            <li><a href="<?= BASE_URL ?>/admin/matieres" class="nav-link"><i class="bi bi-book me-2"></i>Matieres</a></li>
            <li><a href="<?= BASE_URL ?>/admin/lecons" class="nav-link"><i class="bi bi-play-circle me-2"></i>Lecons</a></li>
            <li><a href="<?= BASE_URL ?>/admin/quiz" class="nav-link"><i class="bi bi-question-circle me-2"></i>Quiz</a></li>
            <li><a href="<?= BASE_URL ?>/admin/blog" class="nav-link"><i class="bi bi-journal-text me-2"></i>Blog</a></li>
            <li><a href="<?= BASE_URL ?>/admin/reservations" class="nav-link"><i class="bi bi-calendar-check me-2"></i>Reservations</a></li>
            <li><a href="<?= BASE_URL ?>/admin/parametres" class="nav-link"><i class="bi bi-gear me-2"></i>Parametres</a></li>
        </ul>
    </div>
</div>

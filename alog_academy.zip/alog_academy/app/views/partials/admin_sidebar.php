<!-- Admin Sidebar -->
<aside class="admin-sidebar d-none d-lg-flex flex-column">
    <div class="p-3 border-bottom">
        <a href="<?= BASE_URL ?>/admin/dashboard" class="d-flex align-items-center text-decoration-none">
            <i class="bi bi-mortarboard-fill fs-4 me-2 text-primary"></i>
            <span class="fw-bold">ALOG Admin</span>
        </a>
    </div>

    <nav class="flex-grow-1 p-3">
        <ul class="nav nav-pills flex-column gap-1">
            <li><a href="<?= BASE_URL ?>/admin/dashboard" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/dashboard') ? 'active' : '' ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
            <li><a href="<?= BASE_URL ?>/admin/utilisateurs" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/utilisateurs') ? 'active' : '' ?>"><i class="bi bi-people me-2"></i>Utilisateurs</a></li>
            <li><a href="<?= BASE_URL ?>/admin/paiements" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/paiements') ? 'active' : '' ?>"><i class="bi bi-credit-card me-2"></i>Paiements</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a href="<?= BASE_URL ?>/admin/niveaux" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/niveaux') ? 'active' : '' ?>"><i class="bi bi-layers me-2"></i>Niveaux</a></li>
            <li><a href="<?= BASE_URL ?>/admin/matieres" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/matieres') ? 'active' : '' ?>"><i class="bi bi-book me-2"></i>Matieres</a></li>
            <li><a href="<?= BASE_URL ?>/admin/lecons" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/lecons') ? 'active' : '' ?>"><i class="bi bi-play-circle me-2"></i>Lecons</a></li>
            <li><a href="<?= BASE_URL ?>/admin/quiz" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/quiz') ? 'active' : '' ?>"><i class="bi bi-question-circle me-2"></i>Quiz</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a href="<?= BASE_URL ?>/admin/blog" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/blog') ? 'active' : '' ?>"><i class="bi bi-journal-text me-2"></i>Blog</a></li>
            <li><a href="<?= BASE_URL ?>/admin/reservations" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/reservations') ? 'active' : '' ?>"><i class="bi bi-calendar-check me-2"></i>Reservations</a></li>
            <li><a href="<?= BASE_URL ?>/admin/parametres" class="nav-link <?= str_contains($_SERVER['REQUEST_URI'], '/admin/parametres') ? 'active' : '' ?>"><i class="bi bi-gear me-2"></i>Parametres</a></li>
        </ul>
    </nav>

    <div class="p-3 border-top">
        <a href="<?= BASE_URL ?>/admin/logout" class="btn btn-outline-danger w-100 btn-sm">
            <i class="bi bi-box-arrow-right me-2"></i>Deconnexion
        </a>
    </div>
</aside>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4 p-md-5 text-center">
                        <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:64px;height:64px">
                            <i class="bi bi-key fs-2"></i>
                        </div>
                        <h2 class="h4 fw-bold">Mot de passe oublie</h2>
                        <p class="text-muted small">Entrez votre email pour recevoir un lien de reinitialisation</p>

                        <?php if (!empty($message)): ?>
                            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
                        <?php endif; ?>
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?= BASE_URL ?>/mot-de-passe-oublie">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                            <div class="mb-3">
                                <input type="email" name="email" class="form-control form-control-lg" placeholder="votre@email.com" required>
                            </div>
                            <button type="submit" class="btn btn-alog-primary w-100 btn-lg">Envoyer le lien</button>
                        </form>

                        <div class="mt-3">
                            <a href="<?= BASE_URL ?>/login" class="small text-decoration-none">Retour a la connexion</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

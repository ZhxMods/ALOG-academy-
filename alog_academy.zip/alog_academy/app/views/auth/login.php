<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4 p-md-5">
                        <div class="text-center mb-4">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:64px;height:64px">
                                <i class="bi bi-person-circle fs-2"></i>
                            </div>
                            <h2 class="h4 fw-bold">Connexion</h2>
                            <p class="text-muted small">Connectez-vous a votre compte ALOG ACADEMY</p>
                        </div>

                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?= BASE_URL ?>/login">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                            <div class="mb-3">
                                <label class="form-label fw-medium">Email</label>
                                <input type="email" name="email" class="form-control form-control-lg" placeholder="votre@email.com" required autofocus>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-medium">Mot de passe</label>
                                <input type="password" name="password" class="form-control form-control-lg" placeholder="••••••••" required>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <div class="form-check">
                                    <input type="checkbox" name="remember_me" class="form-check-input" id="remember">
                                    <label class="form-check-label small" for="remember">Se souvenir de moi</label>
                                </div>
                                <a href="<?= BASE_URL ?>/mot-de-passe-oublie" class="small text-decoration-none">Mot de passe oublie?</a>
                            </div>

                            <button type="submit" class="btn btn-alog-primary w-100 btn-lg mb-3">
                                <i class="bi bi-box-arrow-in-right me-2"></i>Se connecter
                            </button>
                        </form>

                        <div class="text-center">
                            <p class="text-muted small mb-0">Pas encore de compte? <a href="<?= BASE_URL ?>/inscription" class="text-decoration-none fw-medium">S'inscrire</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4 p-md-5">
                        <div class="text-center mb-4">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:64px;height:64px">
                                <i class="bi bi-person-plus fs-2"></i>
                            </div>
                            <h2 class="h4 fw-bold">Inscription</h2>
                            <p class="text-muted small">Rejoignez ALOG ACADEMY gratuitement</p>
                        </div>

                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0 small">
                                    <?php foreach ($errors as $err): ?>
                                        <li><?= htmlspecialchars($err) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="<?= BASE_URL ?>/inscription">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Prenom</label>
                                    <input type="text" name="first_name" class="form-control" value="<?= htmlspecialchars($old['first_name'] ?? '') ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Nom</label>
                                    <input type="text" name="last_name" class="form-control" value="<?= htmlspecialchars($old['last_name'] ?? '') ?>" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-medium">Email</label>
                                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($old['email'] ?? '') ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-medium">Telephone</label>
                                <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($old['phone'] ?? '') ?>" placeholder="+212 6XX XXX XXX">
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-medium">Date de naissance</label>
                                <input type="date" name="birth_date" class="form-control" value="<?= htmlspecialchars($old['birth_date'] ?? '') ?>">
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Region</label>
                                    <select name="region_id" class="form-select" required>
                                        <option value="">Choisir...</option>
                                        <?php foreach ($regions as $region): ?>
                                            <option value="<?= $region['id'] ?>" <?= ($old['region_id'] ?? '') == $region['id'] ? 'selected' : '' ?>><?= htmlspecialchars($region['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Niveau scolaire</label>
                                    <select name="school_level_id" class="form-select" required>
                                        <option value="">Choisir...</option>
                                        <?php foreach ($levels as $level): ?>
                                            <option value="<?= $level['id'] ?>" <?= ($old['school_level_id'] ?? '') == $level['id'] ? 'selected' : '' ?>><?= htmlspecialchars($level['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-medium">Mot de passe</label>
                                <input type="password" name="password" class="form-control" required>
                                <div class="form-text small">Min. 8 caracteres, 1 majuscule, 1 minuscule, 1 chiffre</div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-medium">Confirmer le mot de passe</label>
                                <input type="password" name="confirm_password" class="form-control" required>
                            </div>

                            <button type="submit" class="btn btn-alog-primary w-100 btn-lg mb-3">
                                <i class="bi bi-person-plus me-2"></i>S'inscrire
                            </button>
                        </form>

                        <div class="text-center">
                            <p class="text-muted small mb-0">Deja membre? <a href="<?= BASE_URL ?>/login" class="text-decoration-none fw-medium">Se connecter</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

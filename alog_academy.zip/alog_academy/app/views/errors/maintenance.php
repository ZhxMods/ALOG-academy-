<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance - ALOG ACADEMY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; min-height: 100vh; display: flex; align-items: center; background: #f8fafc; }
    </style>
</head>
<body>
    <div class="container text-center">
        <div class="mb-4">
            <i class="bi bi-tools text-primary" style="font-size:4rem"></i>
        </div>
        <h2 class="h3 fw-bold mb-3">Maintenance en cours</h2>
        <p class="text-muted mb-4">ALOG ACADEMY est momentanement indisponible pour maintenance.<br>Revenez dans quelques minutes.</p>
        <button onclick="location.reload()" class="btn btn-outline-primary">Reessayer</button>
    </div>
</body>
</html>

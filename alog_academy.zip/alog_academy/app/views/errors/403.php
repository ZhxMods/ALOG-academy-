<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acces interdit - 403</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; min-height: 100vh; display: flex; align-items: center; background: #f8fafc; }
        .error-code { font-size: 8rem; font-weight: 800; line-height: 1; color: #ef4444; }
    </style>
</head>
<body>
    <div class="container text-center">
        <div class="error-code mb-3">403</div>
        <h2 class="h3 fw-bold mb-3">Acces interdit</h2>
        <p class="text-muted mb-4">Vous n'avez pas les permissions necessaires pour acceder a cette page.</p>
        <a href="<?= BASE_URL ?>/" class="btn btn-primary btn-lg"><i class="bi bi-house me-2"></i>Retour a l'accueil</a>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="fr" data-bs-theme="<?= ($dark_mode ?? false) ? 'dark' : 'light' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= htmlspecialchars($meta_title ?? SITE_NAME) ?></title>
    <meta name="description" content="<?= htmlspecialchars($meta_desc ?? DEFAULT_META_DESC) ?>">
    <meta name="keywords" content="cours en ligne, education, maroc, etudiants, bac, cours video, quiz">
    <meta name="author" content="ALOG ACADEMY">

    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= htmlspecialchars($meta_title ?? SITE_NAME) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($meta_desc ?? DEFAULT_META_DESC) ?>">
    <meta property="og:url" content="<?= BASE_URL ?><?= $_SERVER['REQUEST_URI'] ?>">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($meta_title ?? SITE_NAME) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($meta_desc ?? DEFAULT_META_DESC) ?>">

    <!-- Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?= BASE_URL ?>/assets/css/alog.css" rel="stylesheet">

    <link rel="canonical" href="<?= BASE_URL ?><?= $_SERVER['REQUEST_URI'] ?>">
</head>
<body>
    <?php require APP_PATH . '/views/partials/navbar.php'; ?>

    <main>
        <?php
        $flash = $this->getFlash();
        if ($flash):
        ?>
        <div class="container mt-3">
            <div class="alert alert-<?= $flash['type'] === 'error' ? 'danger' : ($flash['type'] === 'info' ? 'info' : 'success') ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </div>
        <?php endif; ?>

        <?php require $viewFile; ?>
    </main>

    <?php require APP_PATH . '/views/partials/footer.php'; ?>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="<?= BASE_URL ?>/assets/js/alog.js"></script>
</body>
</html>

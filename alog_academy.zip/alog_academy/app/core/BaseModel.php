<?php
declare(strict_types=1);

namespace App\Core;

use PDO;

/**
 * Classe BaseModel - Modèle de base avec méthodes CRUD communes
 */
class BaseModel
{
    protected PDO $db;
    protected string $table = '';
    protected string $primaryKey = 'id';

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function findBy(string $column, $value): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE {$column} = ? LIMIT 1");
        $stmt->execute([$value]);
        return $stmt->fetch() ?: null;
    }

    public function findAll(array $orderBy = [], int $limit = 0, int $offset = 0): array
    {
        $sql = "SELECT * FROM {$this->table}";
        if (!empty($orderBy)) {
            $sql .= " ORDER BY " . implode(', ', array_map(fn($k, $v) => "$k $v", array_keys($orderBy), $orderBy));
        }
        if ($limit > 0) {
            $sql .= " LIMIT {$limit}";
            if ($offset > 0) {
                $sql .= " OFFSET {$offset}";
            }
        }
        return $this->db->query($sql)->fetchAll();
    }

    public function findWhere(array $conditions, array $orderBy = [], int $limit = 0): array
    {
        $where = [];
        $values = [];
        foreach ($conditions as $key => $value) {
            $where[] = "{$key} = ?";
            $values[] = $value;
        }
        $sql = "SELECT * FROM {$this->table} WHERE " . implode(' AND ', $where);
        if (!empty($orderBy)) {
            $sql .= " ORDER BY " . implode(', ', array_map(fn($k, $v) => "$k $v", array_keys($orderBy), $orderBy));
        }
        if ($limit > 0) {
            $sql .= " LIMIT {$limit}";
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($values);
        return $stmt->fetchAll();
    }

    public function create(array $data): int
    {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $stmt = $this->db->prepare("INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})");
        $stmt->execute(array_values($data));
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        $set = implode(', ', array_map(fn($k) => "{$k} = ?", array_keys($data)));
        $data[$this->primaryKey] = $id;
        $stmt = $this->db->prepare("UPDATE {$this->table} SET {$set} WHERE {$this->primaryKey} = ?");
        return $stmt->execute(array_values($data));
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE {$this->primaryKey} = ?");
        return $stmt->execute([$id]);
    }

    public function count(array $conditions = []): int
    {
        $sql = "SELECT COUNT(*) FROM {$this->table}";
        if (!empty($conditions)) {
            $where = [];
            $values = [];
            foreach ($conditions as $key => $value) {
                $where[] = "{$key} = ?";
                $values[] = $value;
            }
            $sql .= " WHERE " . implode(' AND ', $where);
            $stmt = $this->db->prepare($sql);
            $stmt->execute($values);
        } else {
            $stmt = $this->db->query($sql);
        }
        return (int)$stmt->fetchColumn();
    }
}

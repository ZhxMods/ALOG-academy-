<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Classe BaseController - Contrôleur de base
 */
class BaseController
{
    protected array $data = [];
    protected ?array $user = null;
    protected ?array $admin = null;

    public function __construct()
    {
        $this->data['site_name'] = SITE_NAME;
        $this->data['site_tagline'] = SITE_TAGLINE;
        $this->data['base_url'] = BASE_URL;
        $this->data['csrf_token'] = $this->generateCsrfToken();
        $this->data['meta_title'] = DEFAULT_META_TITLE;
        $this->data['meta_desc'] = DEFAULT_META_DESC;
        $this->data['dark_mode'] = $_SESSION['dark_mode'] ?? false;
        $this->data['unread_notifications'] = 0;

        if (isset($_SESSION['user_id'])) {
            $this->loadUser();
        }
        if (isset($_SESSION['admin_id'])) {
            $this->loadAdmin();
        }
    }

    protected function generateCsrfToken(): string
    {
        if (empty($_SESSION[CSRF_TOKEN_NAME])) {
            $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        }
        return $_SESSION[CSRF_TOKEN_NAME];
    }

    protected function verifyCsrfToken(string $token): bool
    {
        return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
    }

    protected function loadUser(): void
    {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT u.*, r.name as role_name, ul.current_level, ul.total_xp 
                              FROM users u 
                              LEFT JOIN roles r ON u.role_id = r.id 
                              LEFT JOIN user_levels ul ON u.id = ul.user_id 
                              WHERE u.id = ? AND u.status = 'active' LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        $this->user = $stmt->fetch() ?: null;
        $this->data['user'] = $this->user;
    }

    protected function loadAdmin(): void
    {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT a.*, r.name as role_name FROM admins a LEFT JOIN roles r ON a.role_id = r.id WHERE a.id = ? AND a.status = 'active' LIMIT 1");
        $stmt->execute([$_SESSION['admin_id']]);
        $this->admin = $stmt->fetch() ?: null;
        $this->data['admin'] = $this->admin;
    }

    protected function view(string $view, array $data = []): void
    {
        $this->data = array_merge($this->data, $data);
        extract($this->data);

        $viewFile = APP_PATH . '/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            require APP_PATH . '/views/layouts/main.php';
        } else {
            die("Vue introuvable: " . $view);
        }
    }

    protected function adminView(string $view, array $data = []): void
    {
        $this->data = array_merge($this->data, $data);
        extract($this->data);

        $viewFile = APP_PATH . '/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            require APP_PATH . '/views/layouts/admin.php';
        } else {
            die("Vue admin introuvable: " . $view);
        }
    }

    protected function jsonResponse(array $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data);
        exit;
    }

    protected function redirect(string $url): void
    {
        header("Location: " . BASE_URL . "/" . ltrim($url, '/'));
        exit;
    }

    protected function setFlash(string $type, string $message): void
    {
        $_SESSION['flash'] = ['type' => $type, 'message' => $message];
    }

    protected function getFlash(): ?array
    {
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        return $flash;
    }

    protected function isLoggedIn(): bool
    {
        return isset($_SESSION['user_id']) && $this->user !== null;
    }

    protected function isAdmin(): bool
    {
        return isset($_SESSION['admin_id']) && $this->admin !== null;
    }

    protected function requireAuth(): void
    {
        if (!$this->isLoggedIn()) {
            $this->setFlash('error', 'Veuillez vous connecter pour accéder à cette page.');
            $this->redirect('/login');
        }
    }

    protected function requireAdmin(): void
    {
        if (!$this->isAdmin()) {
            http_response_code(403);
            require APP_PATH . '/views/errors/403.php';
            exit;
        }
    }

    protected function requireSuperAdmin(): void
    {
        if (!$this->isAdmin() || $this->admin['role_name'] !== 'super_admin') {
            http_response_code(403);
            require APP_PATH . '/views/errors/403.php';
            exit;
        }
    }
}

<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Classe Router - Système de routage léger
 */
class Router
{
    private array $routes = [];
    private array $params = [];
    private array $middlewares = [];

    public function add(string $route, string $controller, string $action, string $method = 'GET', array $middleware = []): void
    {
        $route = preg_replace('/\//', '\/', $route);
        $route = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[a-zA-Z0-9_-]+)', $route);
        $route = '/^' . $route . '$/';

        $this->routes[$method][$route] = [
            'controller' => $controller,
            'action' => $action,
            'middleware' => $middleware
        ];
    }

    public function get(string $route, string $controller, string $action, array $middleware = []): void
    {
        $this->add($route, $controller, $action, 'GET', $middleware);
    }

    public function post(string $route, string $controller, string $action, array $middleware = []): void
    {
        $this->add($route, $controller, $action, 'POST', $middleware);
    }

    public function match(string $url, string $method): bool
    {
        if (!isset($this->routes[$method])) {
            return false;
        }

        foreach ($this->routes[$method] as $route => $params) {
            if (preg_match($route, $url, $matches)) {
                foreach ($matches as $key => $match) {
                    if (is_string($key)) {
                        $this->params[$key] = $match;
                    }
                }
                $this->params['controller'] = $params['controller'];
                $this->params['action'] = $params['action'];
                $this->params['middleware'] = $params['middleware'] ?? [];
                return true;
            }
        }
        return false;
    }

    public function dispatch(): void
    {
        $url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $url = str_replace(dirname($_SERVER['SCRIPT_NAME']), '', $url);
        $url = trim($url, '/');
        $method = $_SERVER['REQUEST_METHOD'];

        if ($this->match($url, $method)) {
            // Exécuter les middlewares
            foreach ($this->params['middleware'] as $middlewareClass) {
                $middleware = new $middlewareClass();
                $middleware->handle();
            }

            $controllerClass = "App\Controllers\" . $this->params['controller'];
            if (!class_exists($controllerClass)) {
                $this->send404();
                return;
            }

            $controller = new $controllerClass();
            $action = $this->params['action'];

            if (!method_exists($controller, $action)) {
                $this->send404();
                return;
            }

            call_user_func_array([$controller, $action], [$this->params]);
        } else {
            $this->send404();
        }
    }

    private function send404(): void
    {
        http_response_code(404);
        require APP_PATH . '/views/errors/404.php';
    }

    public function getParams(): array
    {
        return $this->params;
    }
}

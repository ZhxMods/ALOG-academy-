<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Branch extends BaseModel
{
    protected string $table = 'branches';

    public function getByLevel(int $levelId): array
    {
        return $this->findWhere(['level_id' => $levelId, 'status' => 'active'], ['order_position' => 'ASC']);
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class XPLog extends BaseModel
{
    protected string $table = 'xp_logs';

    public function add(int $userId, int $amount, string $type, ?int $refId = null, string $desc = ''): void
    {
        $this->create([
            'user_id' => $userId,
            'xp_amount' => $amount,
            'action_type' => $type,
            'reference_id' => $refId,
            'description' => $desc
        ]);
    }

    public function getTodayLoginXP(int $userId): int
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT COALESCE(SUM(xp_amount), 0) FROM xp_logs WHERE user_id = ? AND action_type = 'daily_login' AND DATE(created_at) = CURDATE()");
        $stmt->execute([$userId]);
        return (int)$stmt->fetchColumn();
    }

    public function getTotalByUser(int $userId): int
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT COALESCE(SUM(xp_amount), 0) FROM xp_logs WHERE user_id = ?");
        $stmt->execute([$userId]);
        return (int)$stmt->fetchColumn();
    }
}

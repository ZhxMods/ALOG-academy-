<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Admin extends BaseModel
{
    protected string $table = 'admins';

    public function findByEmail(string $email): ?array
    {
        return $this->findBy('email', $email);
    }

    public function updateLastLogin(int $id): void
    {
        $this->update($id, ['last_login' => date('Y-m-d H:i:s')]);
    }

    public function getStats(): array
    {
        $db = \App\Core\Database::getInstance();

        return [
            'total_users' => (int)$db->query("SELECT COUNT(*) FROM users WHERE status = 'active'")->fetchColumn(),
            'total_lessons' => (int)$db->query("SELECT COUNT(*) FROM lessons WHERE status = 'active'")->fetchColumn(),
            'active_subscriptions' => (int)$db->query("SELECT COUNT(*) FROM subscriptions WHERE status = 'active' AND plan_type != 'free'")->fetchColumn(),
            'pending_payments' => (int)$db->query("SELECT COUNT(*) FROM payments WHERE status = 'pending'")->fetchColumn(),
            'today_registrations' => (int)$db->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn(),
            'total_quizzes' => (int)$db->query("SELECT COUNT(*) FROM quizzes WHERE status = 'active'")->fetchColumn(),
            'total_bookings' => (int)$db->query("SELECT COUNT(*) FROM bookings WHERE status = 'pending'")->fetchColumn(),
            'total_xp_today' => (int)($db->query("SELECT COALESCE(SUM(xp_amount), 0) FROM xp_logs WHERE DATE(created_at) = CURDATE()")->fetchColumn() ?: 0)
        ];
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Ranking extends BaseModel
{
    protected string $table = 'rankings';

    public function getGlobalTop(int $limit = 100): array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT r.*, u.first_name, u.last_name, u.profile_image, reg.name as region_name 
                              FROM rankings r 
                              JOIN users u ON r.user_id = u.id 
                              LEFT JOIN regions reg ON r.region_id = reg.id 
                              WHERE u.status = 'active' AND r.global_rank > 0 
                              ORDER BY r.global_rank ASC LIMIT ?");
        $stmt->execute([$limit]);
        return $stmt->fetchAll();
    }

    public function getRegionalTop(int $regionId, int $limit = 100): array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT r.*, u.first_name, u.last_name, u.profile_image, reg.name as region_name 
                              FROM rankings r 
                              JOIN users u ON r.user_id = u.id 
                              LEFT JOIN regions reg ON r.region_id = reg.id 
                              WHERE r.region_id = ? AND u.status = 'active' AND r.regional_rank > 0 
                              ORDER BY r.regional_rank ASC LIMIT ?");
        $stmt->execute([$regionId, $limit]);
        return $stmt->fetchAll();
    }

    public function updateRankings(): void
    {
        $db = \App\Core\Database::getInstance();

        // Mettre à jour classement global
        $db->query("SET @rank := 0");
        $db->query("
            UPDATE rankings r
            JOIN (
                SELECT user_id, total_xp, completed_lessons, quiz_average,
                       (@rank := @rank + 1) as new_rank
                FROM rankings
                ORDER BY total_xp DESC, completed_lessons DESC, quiz_average DESC
            ) t ON r.user_id = t.user_id
            SET r.global_rank = t.new_rank
        ");

        // Mettre à jour classement régional
        $regions = $db->query("SELECT DISTINCT region_id FROM rankings WHERE region_id IS NOT NULL")->fetchAll();
        foreach ($regions as $region) {
            $db->query("SET @rank := 0");
            $stmt = $db->prepare("
                UPDATE rankings r
                JOIN (
                    SELECT user_id, total_xp, completed_lessons, quiz_average,
                           (@rank := @rank + 1) as new_rank
                    FROM rankings
                    WHERE region_id = ?
                    ORDER BY total_xp DESC, completed_lessons DESC, quiz_average DESC
                ) t ON r.user_id = t.user_id
                SET r.regional_rank = t.new_rank
                WHERE r.region_id = ?
            ");
            $stmt->execute([$region['region_id'], $region['region_id']]);
        }
    }

    public function getUserRank(int $userId): ?array
    {
        return $this->findBy('user_id', $userId);
    }
}

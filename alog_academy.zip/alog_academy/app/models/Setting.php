<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Setting extends BaseModel
{
    protected string $table = 'settings';

    public function get(string $key, string $default = ''): string
    {
        $setting = $this->findBy('setting_key', $key);
        return $setting['setting_value'] ?? $default;
    }

    public function set(string $key, string $value): void
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$key, $value, $value]);
    }

    public function getAllByGroup(string $group): array
    {
        return $this->findWhere(['setting_group' => $group]);
    }
}

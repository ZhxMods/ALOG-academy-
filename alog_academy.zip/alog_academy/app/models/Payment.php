<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Payment extends BaseModel
{
    protected string $table = 'payments';

    public function getPending(): array
    {
        return $this->findWhere(['status' => 'pending'], ['created_at' => 'DESC']);
    }

    public function getByUser(int $userId): array
    {
        return $this->findWhere(['user_id' => $userId], ['created_at' => 'DESC']);
    }

    public function approve(int $paymentId, int $adminId): void
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("UPDATE payments SET status = 'approved', validated_by = ?, validated_at = NOW() WHERE id = ?");
        $stmt->execute([$adminId, $paymentId]);
    }

    public function reject(int $paymentId, int $adminId, string $notes = ''): void
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("UPDATE payments SET status = 'rejected', validated_by = ?, admin_notes = ?, validated_at = NOW() WHERE id = ?");
        $stmt->execute([$adminId, $notes, $paymentId]);
    }
}

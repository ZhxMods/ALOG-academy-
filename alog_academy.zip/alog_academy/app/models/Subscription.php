<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Subscription extends BaseModel
{
    protected string $table = 'subscriptions';

    public function getActiveByUser(int $userId): ?array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM subscriptions WHERE user_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
        $stmt->execute([$userId]);
        return $stmt->fetch() ?: null;
    }

    public function getByUser(int $userId): array
    {
        return $this->findWhere(['user_id' => $userId], ['created_at' => 'DESC']);
    }

    public function activate(int $subscriptionId, string $planType, int $days = 30): void
    {
        $this->update($subscriptionId, [
            'plan_type' => $planType,
            'status' => 'active',
            'started_at' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', strtotime("+{$days} days"))
        ]);
    }

    public function cancel(int $subscriptionId): void
    {
        $this->update($subscriptionId, ['status' => 'cancelled']);
    }

    public function hasAccess(int $userId, string $requiredPlan): bool
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT plan_type FROM subscriptions WHERE user_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
        $stmt->execute([$userId]);
        $currentPlan = $stmt->fetchColumn() ?: 'free';

        $hierarchy = ['free' => 1, 'pro' => 2, 'ultra' => 3];
        return ($hierarchy[$currentPlan] ?? 1) >= ($hierarchy[$requiredPlan] ?? 1);
    }
}

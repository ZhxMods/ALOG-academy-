<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Booking extends BaseModel
{
    protected string $table = 'bookings';

    public function getByUser(int $userId): array
    {
        return $this->findWhere(['user_id' => $userId], ['created_at' => 'DESC']);
    }

    public function getPending(): array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT b.*, u.first_name, u.last_name, u.email FROM bookings b JOIN users u ON b.user_id = u.id WHERE b.status = 'pending' ORDER BY b.preferred_date ASC");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function updateStatus(int $id, string $status, string $notes = ''): void
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("UPDATE bookings SET status = ?, admin_notes = ? WHERE id = ?");
        $stmt->execute([$status, $notes, $id]);
    }
}

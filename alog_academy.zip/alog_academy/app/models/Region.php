<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Region extends BaseModel
{
    protected string $table = 'regions';

    public function getActive(): array
    {
        return $this->findWhere(['status' => 'active']);
    }
}

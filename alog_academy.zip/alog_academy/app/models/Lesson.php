<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Lesson extends BaseModel
{
    protected string $table = 'lessons';

    public function getBySubject(int $subjectId): array
    {
        return $this->findWhere(['subject_id' => $subjectId, 'status' => 'active'], ['order_position' => 'ASC']);
    }

    public function getBySlug(string $slug): ?array
    {
        return $this->findBy('slug', $slug);
    }

    public function getWithProgress(int $lessonId, int $userId): ?array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT l.*, lp.is_completed, lp.is_skipped, lp.progress_percent, lp.completed_at 
                              FROM lessons l 
                              LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ? 
                              WHERE l.id = ? LIMIT 1");
        $stmt->execute([$userId, $lessonId]);
        return $stmt->fetch() ?: null;
    }

    public function markComplete(int $lessonId, int $userId, bool $skipped = false): bool
    {
        $db = \App\Core\Database::getInstance();

        $stmt = $db->prepare("SELECT id FROM lesson_progress WHERE user_id = ? AND lesson_id = ?");
        $stmt->execute([$userId, $lessonId]);
        $exists = $stmt->fetch();

        if ($exists) {
            $stmt = $db->prepare("UPDATE lesson_progress SET is_completed = 1, is_skipped = ?, progress_percent = 100, completed_at = NOW() WHERE user_id = ? AND lesson_id = ?");
            return $stmt->execute([$skipped ? 1 : 0, $userId, $lessonId]);
        } else {
            $stmt = $db->prepare("INSERT INTO lesson_progress (user_id, lesson_id, is_completed, is_skipped, progress_percent, completed_at) VALUES (?, ?, 1, ?, 100, NOW())");
            return $stmt->execute([$userId, $lessonId, $skipped ? 1 : 0]);
        }
    }

    public function getAllActive(int $limit = 0, int $offset = 0): array
    {
        return $this->findWhere(['status' => 'active'], ['created_at' => 'DESC'], $limit ?: 100);
    }
}

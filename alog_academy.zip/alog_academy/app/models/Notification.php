<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Notification extends BaseModel
{
    protected string $table = 'notifications';

    public function getUnread(int $userId, int $limit = 20): array
    {
        return $this->findWhere(['user_id' => $userId, 'is_read' => 0], ['created_at' => 'DESC'], $limit);
    }

    public function getAll(int $userId, int $limit = 50): array
    {
        return $this->findWhere(['user_id' => $userId], ['created_at' => 'DESC'], $limit);
    }

    public function markRead(int $id): void
    {
        $this->update($id, ['is_read' => 1]);
    }

    public function markAllRead(int $userId): void
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
        $stmt->execute([$userId]);
    }

    public function send(int $userId, string $type, string $title, string $message, ?int $refId = null): void
    {
        $this->create([
            'user_id' => $userId,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'reference_id' => $refId
        ]);
    }
}

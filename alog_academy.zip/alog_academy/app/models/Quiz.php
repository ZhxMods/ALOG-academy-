<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Quiz extends BaseModel
{
    protected string $table = 'quizzes';

    public function getByLesson(int $lessonId): ?array
    {
        $quizzes = $this->findWhere(['lesson_id' => $lessonId, 'status' => 'active']);
        return $quizzes[0] ?? null;
    }

    public function getBySubject(int $subjectId): array
    {
        return $this->findWhere(['subject_id' => $subjectId, 'status' => 'active']);
    }

    public function getQuestions(int $quizId, bool $randomize = true): array
    {
        $db = \App\Core\Database::getInstance();
        $order = $randomize ? 'RAND()' : 'order_position ASC';
        $stmt = $db->prepare("SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY {$order}");
        $stmt->execute([$quizId]);
        $questions = $stmt->fetchAll();

        foreach ($questions as &$question) {
            $stmt = $db->prepare("SELECT * FROM quiz_answers WHERE question_id = ? ORDER BY RAND()");
            $stmt->execute([$question['id']]);
            $question['answers'] = $stmt->fetchAll();
        }

        return $questions;
    }

    public function getCorrectAnswers(int $quizId): array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT qq.id, qq.correct_answer, qq.explanation, qq.xp_value, qa.answer_text as correct_text 
                              FROM quiz_questions qq 
                              LEFT JOIN quiz_answers qa ON qq.correct_answer = qa.id 
                              WHERE qq.quiz_id = ?");
        $stmt->execute([$quizId]);
        return $stmt->fetchAll();
    }

    public function getAttemptsCount(int $quizId, int $userId): int
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT COUNT(*) FROM quiz_results WHERE quiz_id = ? AND user_id = ?");
        $stmt->execute([$quizId, $userId]);
        return (int)$stmt->fetchColumn();
    }

    public function canRetry(int $quizId, int $userId, int $cooldownHours): bool
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT completed_at FROM quiz_results WHERE quiz_id = ? AND user_id = ? ORDER BY completed_at DESC LIMIT 1");
        $stmt->execute([$quizId, $userId]);
        $lastAttempt = $stmt->fetch();

        if (!$lastAttempt) return true;

        $lastTime = strtotime($lastAttempt['completed_at']);
        return (time() - $lastTime) >= ($cooldownHours * 3600);
    }

    public function saveResult(int $userId, int $quizId, array $data): int
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("INSERT INTO quiz_results (user_id, quiz_id, score, total_questions, correct_answers, xp_earned, is_passed, attempt_number, answers_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $userId, $quizId, $data['score'], $data['total'], $data['correct'], 
            $data['xp_earned'], $data['passed'] ? 1 : 0, $data['attempt'], json_encode($data['answers'])
        ]);
        return (int)$db->lastInsertId();
    }
}

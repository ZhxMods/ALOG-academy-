<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class SchoolLevel extends BaseModel
{
    protected string $table = 'school_levels';

    public function getActive(): array
    {
        return $this->findWhere(['status' => 'active'], ['order_position' => 'ASC']);
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class BlogPost extends BaseModel
{
    protected string $table = 'blog_posts';

    public function getPublished(int $limit = 10, int $offset = 0, ?string $category = null): array
    {
        $db = \App\Core\Database::getInstance();
        $sql = "SELECT bp.*, a.first_name as author_name, a.last_name as author_lastname FROM blog_posts bp JOIN admins a ON bp.author_id = a.id WHERE bp.status = 'published' AND (bp.published_at IS NULL OR bp.published_at <= NOW())";
        $params = [];
        if ($category) {
            $sql .= " AND bp.category = ?";
            $params[] = $category;
        }
        $sql .= " ORDER BY bp.published_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getBySlug(string $slug): ?array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT bp.*, a.first_name as author_name, a.last_name as author_lastname FROM blog_posts bp JOIN admins a ON bp.author_id = a.id WHERE bp.slug = ? AND bp.status = 'published' LIMIT 1");
        $stmt->execute([$slug]);
        return $stmt->fetch() ?: null;
    }

    public function incrementViews(int $id): void
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("UPDATE blog_posts SET views_count = views_count + 1 WHERE id = ?");
        $stmt->execute([$id]);
    }

    public function getCategories(): array
    {
        $db = \App\Core\Database::getInstance();
        return $db->query("SELECT DISTINCT category FROM blog_posts WHERE status = 'published' AND category IS NOT NULL ORDER BY category")->fetchAll(\PDO::FETCH_COLUMN);
    }

    public function getRelated(int $postId, string $category, int $limit = 3): array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT id, title, slug, featured_image, excerpt FROM blog_posts WHERE id != ? AND category = ? AND status = 'published' ORDER BY published_at DESC LIMIT ?");
        $stmt->execute([$postId, $category, $limit]);
        return $stmt->fetchAll();
    }
}

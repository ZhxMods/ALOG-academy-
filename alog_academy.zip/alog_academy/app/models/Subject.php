<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Subject extends BaseModel
{
    protected string $table = 'subjects';

    public function getByLevel(int $levelId, ?int $branchId = null): array
    {
        $db = \App\Core\Database::getInstance();
        if ($branchId) {
            $stmt = $db->prepare("SELECT * FROM subjects WHERE level_id = ? AND (branch_id = ? OR branch_id IS NULL) AND status = 'active' ORDER BY order_position ASC");
            $stmt->execute([$levelId, $branchId]);
        } else {
            $stmt = $db->prepare("SELECT * FROM subjects WHERE level_id = ? AND branch_id IS NULL AND status = 'active' ORDER BY order_position ASC");
            $stmt->execute([$levelId]);
        }
        return $stmt->fetchAll();
    }
}

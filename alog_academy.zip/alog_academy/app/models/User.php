<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class User extends BaseModel
{
    protected string $table = 'users';

    public function findByEmail(string $email): ?array
    {
        return $this->findBy('email', $email);
    }

    public function createUser(array $data): int
    {
        $userId = $this->create($data);
        // Créer l'entrée user_levels
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("INSERT INTO user_levels (user_id, current_level, total_xp, xp_to_next_level) VALUES (?, 1, 0, ?)");
        $stmt->execute([$userId, XP_BASE_LEVEL]);
        // Créer l'entrée subscription free
        $stmt = $db->prepare("INSERT INTO subscriptions (user_id, plan_type, status, started_at) VALUES (?, 'free', 'active', NOW())");
        $stmt->execute([$userId]);
        return $userId;
    }

    public function updateLastLogin(int $id): void
    {
        $this->update($id, ['last_login' => date('Y-m-d H:i:s'), 'login_attempts' => 0, 'locked_until' => null]);
    }

    public function incrementLoginAttempts(int $id): void
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("UPDATE users SET login_attempts = login_attempts + 1, locked_until = CASE WHEN login_attempts >= ? THEN DATE_ADD(NOW(), INTERVAL ? MINUTE) ELSE locked_until END WHERE id = ?");
        $stmt->execute([MAX_LOGIN_ATTEMPTS - 1, LOGIN_LOCKOUT_TIME / 60, $id]);
    }

    public function getDashboardStats(int $userId): array
    {
        $db = \App\Core\Database::getInstance();

        $stmt = $db->prepare("SELECT current_level, total_xp, xp_to_next_level FROM user_levels WHERE user_id = ?");
        $stmt->execute([$userId]);
        $levelData = $stmt->fetch() ?: ['current_level' => 1, 'total_xp' => 0, 'xp_to_next_level' => XP_BASE_LEVEL];

        $stmt = $db->prepare("SELECT COUNT(*) FROM lesson_progress WHERE user_id = ? AND is_completed = 1");
        $stmt->execute([$userId]);
        $completedLessons = (int)$stmt->fetchColumn();

        $stmt = $db->prepare("SELECT COUNT(*), COALESCE(AVG(score), 0) FROM quiz_results WHERE user_id = ?");
        $stmt->execute([$userId]);
        $quizStats = $stmt->fetch();

        $stmt = $db->prepare("SELECT plan_type, status, expires_at FROM subscriptions WHERE user_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
        $stmt->execute([$userId]);
        $subscription = $stmt->fetch() ?: ['plan_type' => 'free', 'status' => 'active', 'expires_at' => null];

        $stmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$userId]);
        $unreadNotifications = (int)$stmt->fetchColumn();

        return [
            'level' => $levelData,
            'completed_lessons' => $completedLessons,
            'quizzes_taken' => (int)$quizStats[0],
            'average_score' => round((float)$quizStats[1], 1),
            'subscription' => $subscription,
            'unread_notifications' => $unreadNotifications
        ];
    }

    public function getRecentActivity(int $userId, int $limit = 10): array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM xp_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->execute([$userId, $limit]);
        return $stmt->fetchAll();
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class UserLevel extends BaseModel
{
    protected string $table = 'user_levels';

    public function addXP(int $userId, int $amount): array
    {
        $db = \App\Core\Database::getInstance();

        // Récupérer niveau actuel
        $stmt = $db->prepare("SELECT * FROM user_levels WHERE user_id = ?");
        $stmt->execute([$userId]);
        $levelData = $stmt->fetch();

        if (!$levelData) {
            $xpNeeded = XP_BASE_LEVEL;
            $stmt = $db->prepare("INSERT INTO user_levels (user_id, current_level, total_xp, xp_to_next_level) VALUES (?, 1, ?, ?)");
            $stmt->execute([$userId, $amount, $xpNeeded]);
            return ['leveled_up' => false, 'new_level' => 1, 'total_xp' => $amount];
        }

        $newTotal = $levelData['total_xp'] + $amount;
        $currentLevel = $levelData['current_level'];
        $leveledUp = false;

        // Calcul XP nécessaire pour niveau suivant
        $xpNeeded = $this->xpForLevel($currentLevel + 1);

        while ($newTotal >= $xpNeeded) {
            $currentLevel++;
            $leveledUp = true;
            $xpNeeded = $this->xpForLevel($currentLevel + 1);
        }

        $stmt = $db->prepare("UPDATE user_levels SET current_level = ?, total_xp = ?, xp_to_next_level = ? WHERE user_id = ?");
        $stmt->execute([$currentLevel, $newTotal, $xpNeeded - $newTotal, $userId]);

        return [
            'leveled_up' => $leveledUp,
            'new_level' => $currentLevel,
            'previous_level' => $levelData['current_level'],
            'total_xp' => $newTotal,
            'xp_needed' => $xpNeeded - $newTotal
        ];
    }

    public function xpForLevel(int $level): int
    {
        return (int)(XP_BASE_LEVEL * pow(XP_LEVEL_MULTIPLIER, $level - 1));
    }
}

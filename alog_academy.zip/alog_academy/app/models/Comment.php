<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\BaseModel;

class Comment extends BaseModel
{
    protected string $table = 'comments';

    public function getForContent(string $type, int $contentId, int $limit = 50): array
    {
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT c.*, u.first_name, u.last_name, u.profile_image FROM comments c JOIN users u ON c.user_id = u.id WHERE c.content_type = ? AND c.content_id = ? AND c.status = 'approved' ORDER BY c.created_at DESC LIMIT ?");
        $stmt->execute([$type, $contentId, $limit]);
        return $stmt->fetchAll();
    }

    public function getPending(): array
    {
        return $this->findWhere(['status' => 'pending'], ['created_at' => 'DESC']);
    }
}

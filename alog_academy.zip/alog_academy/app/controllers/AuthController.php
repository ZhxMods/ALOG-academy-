<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\BaseController;
use App\Models\User;
use App\Models\Region;
use App\Models\SchoolLevel;
use App\Models\Branch;

class AuthController extends BaseController
{
    private User $userModel;
    private Region $regionModel;
    private SchoolLevel $levelModel;
    private Branch $branchModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = new User();
        $this->regionModel = new Region();
        $this->levelModel = new SchoolLevel();
        $this->branchModel = new Branch();
    }

    public function login(array $params = []): void
    {
        if ($this->isLoggedIn()) {
            $this->redirect('/dashboard');
        }

        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = sanitizeInput($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $remember = isset($_POST['remember_me']);
            $csrf = $_POST['csrf_token'] ?? '';

            if (!$this->verifyCsrfToken($csrf)) {
                $error = "Jeton de securite invalide.";
            } else {
                $user = $this->userModel->findByEmail($email);

                if ($user && $user['status'] === 'active') {
                    if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
                        $error = "Compte temporairement verrouille. Reessayez plus tard.";
                    } elseif (checkRateLimit('login_' . $user['id'], MAX_LOGIN_ATTEMPTS, LOGIN_LOCKOUT_TIME)) {
                        if (verifyPassword($password, $user['password_hash'])) {
                            $_SESSION['user_id'] = $user['id'];
                            regenerateSession();
                            $this->userModel->updateLastLogin($user['id']);

                            if ($remember) {
                                setRememberMeCookie($user['id']);
                            }

                            $this->setFlash('success', 'Bienvenue, ' . $user['first_name'] . ' !');
                            $this->redirect('/dashboard');
                        } else {
                            $this->userModel->incrementLoginAttempts($user['id']);
                            $error = "Email ou mot de passe incorrect.";
                        }
                    } else {
                        $error = "Trop de tentatives. Veuillez patienter.";
                    }
                } else {
                    $error = "Email ou mot de passe incorrect.";
                }
            }
        }

        cleanOldRateLimits();
        $this->view('auth/login', ['error' => $error, 'meta_title' => 'Connexion - ' . SITE_NAME]);
    }

    public function register(array $params = []): void
    {
        if ($this->isLoggedIn()) {
            $this->redirect('/dashboard');
        }

        $errors = [];
        $old = [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $csrf = $_POST['csrf_token'] ?? '';
            if (!$this->verifyCsrfToken($csrf)) {
                $errors[] = "Jeton de securite invalide.";
            } else {
                $data = [
                    'first_name' => sanitizeInput($_POST['first_name'] ?? ''),
                    'last_name' => sanitizeInput($_POST['last_name'] ?? ''),
                    'email' => strtolower(trim($_POST['email'] ?? '')),
                    'phone' => $_POST['phone'] ?? '',
                    'password' => $_POST['password'] ?? '',
                    'confirm_password' => $_POST['confirm_password'] ?? '',
                    'birth_date' => $_POST['birth_date'] ?? '',
                    'region_id' => (int)($_POST['region_id'] ?? 0),
                    'school_level_id' => (int)($_POST['school_level_id'] ?? 0),
                    'branch_id' => !empty($_POST['branch_id']) ? (int)$_POST['branch_id'] : null,
                ];
                $old = $data;

                if (empty($data['first_name']) || empty($data['last_name'])) {
                    $errors[] = "Le prenom et le nom sont requis.";
                }
                if (!validateEmail($data['email'])) {
                    $errors[] = "Adresse email invalide.";
                }
                if ($this->userModel->findByEmail($data['email'])) {
                    $errors[] = "Cet email est deja utilise.";
                }
                if (!empty($data['phone']) && !validatePhone($data['phone'])) {
                    $errors[] = "Numero de telephone marocain invalide.";
                }
                $passErrors = validatePassword($data['password']);
                if (!empty($passErrors)) {
                    $errors = array_merge($errors, $passErrors);
                }
                if ($data['password'] !== $data['confirm_password']) {
                    $errors[] = "Les mots de passe ne correspondent pas.";
                }
                if (empty($data['region_id'])) {
                    $errors[] = "Veuillez selectionner votre region.";
                }
                if (empty($data['school_level_id'])) {
                    $errors[] = "Veuillez selectionner votre niveau scolaire.";
                }

                if (empty($errors)) {
                    $userData = [
                        'first_name' => $data['first_name'],
                        'last_name' => $data['last_name'],
                        'email' => $data['email'],
                        'phone' => $data['phone'],
                        'password_hash' => hashPassword($data['password']),
                        'birth_date' => $data['birth_date'] ?: null,
                        'region_id' => $data['region_id'],
                        'school_level_id' => $data['school_level_id'],
                        'branch_id' => $data['branch_id'],
                        'role_id' => 1,
                        'status' => 'active'
                    ];

                    $userId = $this->userModel->createUser($userData);

                    $xpLog = new \App\Models\XPLog();
                    $xpLog->add($userId, XP_LOGIN_DAILY, 'daily_login', null, 'Premiere connexion');

                    $userLevel = new \App\Models\UserLevel();
                    $userLevel->addXP($userId, XP_LOGIN_DAILY);

                    $_SESSION['user_id'] = $userId;
                    regenerateSession();

                    $this->setFlash('success', 'Inscription reussie ! Bienvenue sur ALOG ACADEMY.');
                    $this->redirect('/dashboard');
                }
            }
        }

        $this->view('auth/register', [
            'errors' => $errors,
            'old' => $old,
            'regions' => $this->regionModel->getActive(),
            'levels' => $this->levelModel->getActive(),
            'meta_title' => 'Inscription - ' . SITE_NAME
        ]);
    }

    public function forgotPassword(array $params = []): void
    {
        $message = '';
        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = strtolower(trim($_POST['email'] ?? ''));
            $csrf = $_POST['csrf_token'] ?? '';

            if (!$this->verifyCsrfToken($csrf)) {
                $error = "Jeton de securite invalide.";
            } elseif (!validateEmail($email)) {
                $error = "Adresse email invalide.";
            } else {
                $user = $this->userModel->findByEmail($email);
                if ($user) {
                    $token = generateToken();
                    $db = \App\Core\Database::getInstance();
                    $stmt = $db->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))");
                    $stmt->execute([$email, hash('sha256', $token)]);

                    $message = "Si ce compte existe, un lien de reinitialisation a ete genere.";
                } else {
                    $message = "Si ce compte existe, un lien de reinitialisation a ete genere.";
                }
            }
        }

        $this->view('auth/forgot_password', [
            'message' => $message,
            'error' => $error,
            'meta_title' => 'Mot de passe oublie - ' . SITE_NAME
        ]);
    }

    public function logout(array $params = []): void
    {
        clearRememberMeCookie();
        destroySession();
        $this->redirect('/');
    }
}

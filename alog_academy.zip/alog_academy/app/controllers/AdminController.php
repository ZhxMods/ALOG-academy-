<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\BaseController;
use App\Models\Admin;
use App\Models\User;
use App\Models\SchoolLevel;
use App\Models\Branch;
use App\Models\Subject;
use App\Models\Lesson;
use App\Models\Quiz;
use App\Models\Payment;
use App\Models\Subscription;
use App\Models\Booking;
use App\Models\BlogPost;
use App\Models\Comment;
use App\Models\Setting;
use App\Models\Ranking;

class AdminController extends BaseController
{
    private Admin $adminModel;

    public function __construct()
    {
        parent::__construct();
        $this->adminModel = new Admin();
    }

    public function login(array $params = []): void
    {
        if ($this->isAdmin()) {
            $this->redirect('/admin/dashboard');
        }

        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = sanitizeInput($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $csrf = $_POST['csrf_token'] ?? '';

            if (!$this->verifyCsrfToken($csrf)) {
                $error = "Jeton de securite invalide.";
            } else {
                $admin = $this->adminModel->findByEmail($email);

                if ($admin && $admin['status'] === 'active' && verifyPassword($password, $admin['password_hash'])) {
                    $_SESSION['admin_id'] = $admin['id'];
                    regenerateSession();
                    $this->adminModel->updateLastLogin($admin['id']);
                    $this->redirect('/admin/dashboard');
                } else {
                    $error = "Email ou mot de passe incorrect.";
                }
            }
        }

        require APP_PATH . '/views/auth/admin_login.php';
    }

    public function logout(array $params = []): void
    {
        unset($_SESSION['admin_id']);
        $this->redirect('/admin/login');
    }

    public function dashboard(array $params = []): void
    {
        $this->requireAdmin();

        $stats = $this->adminModel->getStats();

        $db = \App\Core\Database::getInstance();

        // Recent registrations
        $stmt = $db->prepare("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
        $stmt->execute();
        $recentUsers = $stmt->fetchAll();

        // Pending payments
        $stmt = $db->prepare("SELECT p.*, u.first_name, u.last_name FROM payments p JOIN users u ON p.user_id = u.id WHERE p.status = 'pending' ORDER BY p.created_at DESC LIMIT 5");
        $stmt->execute();
        $pendingPayments = $stmt->fetchAll();

        // Recent bookings
        $stmt = $db->prepare("SELECT b.*, u.first_name, u.last_name FROM bookings b JOIN users u ON b.user_id = u.id WHERE b.status = 'pending' ORDER BY b.created_at DESC LIMIT 5");
        $stmt->execute();
        $pendingBookings = $stmt->fetchAll();

        $this->adminView('admin/dashboard', [
            'stats' => $stats,
            'recent_users' => $recentUsers,
            'pending_payments' => $pendingPayments,
            'pending_bookings' => $pendingBookings,
            'meta_title' => 'Admin Dashboard - ' . SITE_NAME
        ]);
    }

    public function users(array $params = []): void
    {
        $this->requireAdmin();

        $page = (int)($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;
        $search = $_GET['search'] ?? '';

        $userModel = new User();

        if ($search) {
            $db = \App\Core\Database::getInstance();
            $stmt = $db->prepare("SELECT * FROM users WHERE first_name LIKE ? OR last_name LIKE ? OR email LIKE ? ORDER BY created_at DESC LIMIT ? OFFSET ?");
            $like = "%{$search}%";
            $stmt->execute([$like, $like, $like, $limit, $offset]);
            $users = $stmt->fetchAll();
            $total = $db->prepare("SELECT COUNT(*) FROM users WHERE first_name LIKE ? OR last_name LIKE ? OR email LIKE ?");
            $total->execute([$like, $like, $like]);
            $totalCount = (int)$total->fetchColumn();
        } else {
            $users = $userModel->findAll(['created_at' => 'DESC'], $limit, $offset);
            $totalCount = $userModel->count();
        }

        $this->adminView('admin/users', [
            'users' => $users,
            'page' => $page,
            'total_pages' => ceil($totalCount / $limit),
            'search' => $search,
            'meta_title' => 'Gestion Utilisateurs - Admin'
        ]);
    }

    public function updateUserStatus(array $params = []): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/admin/users');
        }

        $userId = (int)($_POST['user_id'] ?? 0);
        $status = $_POST['status'] ?? 'active';
        $csrf = $_POST['csrf_token'] ?? '';

        if (!$this->verifyCsrfToken($csrf)) {
            $this->setFlash('error', 'Jeton de securite invalide.');
            $this->redirect('/admin/users');
        }

        $userModel = new User();
        $userModel->update($userId, ['status' => $status]);

        $this->setFlash('success', 'Statut utilisateur mis a jour.');
        $this->redirect('/admin/users');
    }

    public function payments(array $params = []): void
    {
        $this->requireAdmin();

        $paymentModel = new Payment();
        $payments = $paymentModel->getPending();

        $this->adminView('admin/payments', [
            'payments' => $payments,
            'meta_title' => 'Validation Paiements - Admin'
        ]);
    }

    public function approvePayment(array $params = []): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/admin/payments');
        }

        $paymentId = (int)($_POST['payment_id'] ?? 0);
        $csrf = $_POST['csrf_token'] ?? '';

        if (!$this->verifyCsrfToken($csrf)) {
            $this->setFlash('error', 'Jeton de securite invalide.');
            $this->redirect('/admin/payments');
        }

        $adminId = (int)$this->admin['id'];
        $paymentModel = new Payment();
        $payment = $paymentModel->find($paymentId);

        if ($payment) {
            $paymentModel->approve($paymentId, $adminId);

            // Activer abonnement
            $subscriptionModel = new Subscription();
            $subscriptionModel->activate($payment['subscription_id'], $payment['plan_type']);

            // Notification
            $notif = new \App\Models\Notification();
            $notif->send($payment['user_id'], 'payment_approved', 'Paiement approuve !', 
                'Votre abonnement ' . strtoupper($payment['plan_type']) . ' a ete active.');

            $this->setFlash('success', 'Paiement approuve et abonnement active.');
        }

        $this->redirect('/admin/payments');
    }

    public function rejectPayment(array $params = []): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/admin/payments');
        }

        $paymentId = (int)($_POST['payment_id'] ?? 0);
        $notes = sanitizeInput($_POST['notes'] ?? '');
        $csrf = $_POST['csrf_token'] ?? '';

        if (!$this->verifyCsrfToken($csrf)) {
            $this->setFlash('error', 'Jeton de securite invalide.');
            $this->redirect('/admin/payments');
        }

        $adminId = (int)$this->admin['id'];
        $paymentModel = new Payment();
        $paymentModel->reject($paymentId, $adminId, $notes);

        $this->setFlash('info', 'Paiement refuse.');
        $this->redirect('/admin/payments');
    }

    public function levels(array $params = []): void
    {
        $this->requireAdmin();

        $levelModel = new SchoolLevel();
        $levels = $levelModel->getActive();

        $this->adminView('admin/levels', [
            'levels' => $levels,
            'meta_title' => 'Gestion Niveaux - Admin'
        ]);
    }

    public function saveLevel(array $params = []): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/admin/levels');
        }

        $id = (int)($_POST['id'] ?? 0);
        $name = sanitizeInput($_POST['name'] ?? '');
        $slug = generateSlug($name);
        $description = sanitizeInput($_POST['description'] ?? '');
        $order = (int)($_POST['order_position'] ?? 0);
        $status = $_POST['status'] ?? 'active';

        $levelModel = new SchoolLevel();
        $data = ['name' => $name, 'slug' => $slug, 'description' => $description, 'order_position' => $order, 'status' => $status];

        if ($id) {
            $levelModel->update($id, $data);
        } else {
            $levelModel->create($data);
        }

        $this->setFlash('success', 'Niveau enregistre avec succes.');
        $this->redirect('/admin/levels');
    }

    public function subjects(array $params = []): void
    {
        $this->requireAdmin();

        $subjectModel = new Subject();
        $levelModel = new SchoolLevel();

        $subjects = $subjectModel->findAll(['name' => 'ASC']);
        $levels = $levelModel->getActive();

        $this->adminView('admin/subjects', [
            'subjects' => $subjects,
            'levels' => $levels,
            'meta_title' => 'Gestion Matieres - Admin'
        ]);
    }

    public function lessons(array $params = []): void
    {
        $this->requireAdmin();

        $lessonModel = new Lesson();
        $subjectModel = new Subject();

        $lessons = $lessonModel->findAll(['created_at' => 'DESC']);
        $subjects = $subjectModel->findAll(['name' => 'ASC']);

        $this->adminView('admin/lessons', [
            'lessons' => $lessons,
            'subjects' => $subjects,
            'meta_title' => 'Gestion Lecons - Admin'
        ]);
    }

    public function saveLesson(array $params = []): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/admin/lessons');
        }

        $id = (int)($_POST['id'] ?? 0);
        $title = sanitizeInput($_POST['title'] ?? '');
        $slug = generateSlug($title);
        $data = [
            'subject_id' => (int)($_POST['subject_id'] ?? 0),
            'title' => $title,
            'slug' => $slug . ($id ? '' : '-' . time()),
            'description' => sanitizeInput($_POST['description'] ?? ''),
            'thumbnail_url' => sanitizeInput($_POST['thumbnail_url'] ?? ''),
            'video_url' => sanitizeInput($_POST['video_url'] ?? ''),
            'pdf_url' => sanitizeInput($_POST['pdf_url'] ?? ''),
            'exercise_pdf_url' => sanitizeInput($_POST['exercise_pdf_url'] ?? ''),
            'xp_reward' => (int)($_POST['xp_reward'] ?? 50),
            'order_position' => (int)($_POST['order_position'] ?? 0),
            'access_type' => $_POST['access_type'] ?? 'free',
            'xp_price' => (int)($_POST['xp_price'] ?? 0),
            'status' => $_POST['status'] ?? 'draft'
        ];

        $lessonModel = new Lesson();
        if ($id) {
            unset($data['slug']);
            $lessonModel->update($id, $data);
        } else {
            $lessonModel->create($data);
        }

        $this->setFlash('success', 'Lecon enregistree avec succes.');
        $this->redirect('/admin/lessons');
    }

    public function quizzes(array $params = []): void
    {
        $this->requireAdmin();

        $quizModel = new Quiz();
        $quizzes = $quizModel->findAll(['created_at' => 'DESC']);

        $this->adminView('admin/quizzes', [
            'quizzes' => $quizzes,
            'meta_title' => 'Gestion Quiz - Admin'
        ]);
    }

    public function bookings(array $params = []): void
    {
        $this->requireAdmin();

        $bookingModel = new Booking();
        $bookings = $bookingModel->getPending();

        $this->adminView('admin/bookings', [
            'bookings' => $bookings,
            'meta_title' => 'Gestion Reservations - Admin'
        ]);
    }

    public function updateBooking(array $params = []): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/admin/bookings');
        }

        $id = (int)($_POST['booking_id'] ?? 0);
        $status = $_POST['status'] ?? 'pending';
        $notes = sanitizeInput($_POST['admin_notes'] ?? '');

        $bookingModel = new Booking();
        $bookingModel->updateStatus($id, $status, $notes);

        $this->setFlash('success', 'Reservation mise a jour.');
        $this->redirect('/admin/bookings');
    }

    public function blog(array $params = []): void
    {
        $this->requireAdmin();

        $blogModel = new BlogPost();
        $posts = $blogModel->findAll(['created_at' => 'DESC']);

        $this->adminView('admin/blog', [
            'posts' => $posts,
            'meta_title' => 'Gestion Blog - Admin'
        ]);
    }

    public function saveBlogPost(array $params = []): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/admin/blog');
        }

        $id = (int)($_POST['id'] ?? 0);
        $title = sanitizeInput($_POST['title'] ?? '');
        $slug = generateSlug($title);

        $data = [
            'author_id' => (int)$this->admin['id'],
            'title' => $title,
            'slug' => $slug . ($id ? '' : '-' . time()),
            'excerpt' => sanitizeInput($_POST['excerpt'] ?? ''),
            'content' => $_POST['content'] ?? '',
            'featured_image' => sanitizeInput($_POST['featured_image'] ?? ''),
            'category' => $_POST['category'] ?? '',
            'meta_title' => sanitizeInput($_POST['meta_title'] ?? $title),
            'meta_description' => sanitizeInput($_POST['meta_description'] ?? ''),
            'reading_time' => (int)($_POST['reading_time'] ?? 5),
            'status' => $_POST['status'] ?? 'draft'
        ];

        if ($data['status'] === 'published' && empty($_POST['published_at'])) {
            $data['published_at'] = date('Y-m-d H:i:s');
        }

        $blogModel = new BlogPost();
        if ($id) {
            unset($data['slug']);
            $blogModel->update($id, $data);
        } else {
            $blogModel->create($data);
        }

        $this->setFlash('success', 'Article enregistre avec succes.');
        $this->redirect('/admin/blog');
    }

    public function settings(array $params = []): void
    {
        $this->requireAdmin();

        $settingModel = new Setting();
        $settings = $settingModel->findAll();

        $this->adminView('admin/settings', [
            'settings' => $settings,
            'meta_title' => 'Parametres - Admin'
        ]);
    }

    public function saveSettings(array $params = []): void
    {
        $this->requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/admin/settings');
        }

        $settingModel = new Setting();
        foreach ($_POST['settings'] ?? [] as $key => $value) {
            $settingModel->set($key, sanitizeInput($value));
        }

        $this->setFlash('success', 'Parametres enregistres.');
        $this->redirect('/admin/settings');
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\BaseController;
use App\Models\BlogPost;
use App\Models\SchoolLevel;
use App\Models\Subject;
use App\Models\Lesson;

class PublicController extends BaseController
{
    public function home(array $params = []): void
    {
        $blogModel = new BlogPost();
        $levelModel = new SchoolLevel();
        $lessonModel = new Lesson();

        $recentPosts = $blogModel->getPublished(3);
        $levels = $levelModel->getActive();
        $featuredLessons = $lessonModel->getAllActive(6);

        $this->view('public/home', [
            'recent_posts' => $recentPosts,
            'levels' => $levels,
            'featured_lessons' => $featuredLessons,
            'meta_title' => SITE_NAME . ' - ' . SITE_TAGLINE,
            'meta_desc' => DEFAULT_META_DESC
        ]);
    }

    public function about(array $params = []): void
    {
        $this->view('public/about', [
            'meta_title' => 'A Propos - ' . SITE_NAME,
            'meta_desc' => 'Decouvrez ALOG ACADEMY, la plateforme educative pour les etudiants marocains.'
        ]);
    }

    public function services(array $params = []): void
    {
        $this->view('public/services', [
            'meta_title' => 'Nos Services - ' . SITE_NAME
        ]);
    }

    public function pricing(array $params = []): void
    {
        $this->view('public/pricing', [
            'price_pro' => PRICE_PRO,
            'price_ultra' => PRICE_ULTRA,
            'meta_title' => 'Tarifs - ' . SITE_NAME
        ]);
    }

    public function blog(array $params = []): void
    {
        $page = (int)($_GET['page'] ?? 1);
        $limit = 9;
        $offset = ($page - 1) * $limit;
        $category = $_GET['category'] ?? null;

        $blogModel = new BlogPost();
        $posts = $blogModel->getPublished($limit, $offset, $category);
        $categories = $blogModel->getCategories();

        $totalCount = count($posts) < $limit && $page === 1 ? count($posts) : 999; // Simplifie

        $this->view('public/blog', [
            'posts' => $posts,
            'categories' => $categories,
            'current_category' => $category,
            'page' => $page,
            'total_pages' => max(1, ceil($totalCount / $limit)),
            'meta_title' => 'Blog - ' . SITE_NAME
        ]);
    }

    public function blogPost(array $params = []): void
    {
        $slug = $params['slug'] ?? '';

        $blogModel = new BlogPost();
        $post = $blogModel->getBySlug($slug);

        if (!$post) {
            $this->send404();
            return;
        }

        $blogModel->incrementViews($post['id']);
        $related = $blogModel->getRelated($post['id'], $post['category'] ?? '');

        $this->view('public/blog_post', [
            'post' => $post,
            'related' => $related,
            'meta_title' => $post['title'] . ' - ' . SITE_NAME,
            'meta_desc' => $post['meta_description'] ?? substr(strip_tags($post['excerpt'] ?? ''), 0, 160)
        ]);
    }

    public function faq(array $params = []): void
    {
        $this->view('public/faq', [
            'meta_title' => 'FAQ - ' . SITE_NAME
        ]);
    }

    public function contact(array $params = []): void
    {
        $success = '';
        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = sanitizeInput($_POST['name'] ?? '');
            $email = sanitizeInput($_POST['email'] ?? '');
            $message = sanitizeInput($_POST['message'] ?? '');
            $csrf = $_POST['csrf_token'] ?? '';

            if (!$this->verifyCsrfToken($csrf)) {
                $error = "Jeton de securite invalide.";
            } elseif (empty($name) || empty($email) || empty($message)) {
                $error = "Tous les champs sont requis.";
            } elseif (!validateEmail($email)) {
                $error = "Email invalide.";
            } else {
                // Enregistrer dans la base ou envoyer email
                $success = "Message envoye avec succes !";
            }
        }

        $this->view('public/contact', [
            'success' => $success,
            'error' => $error,
            'meta_title' => 'Contact - ' . SITE_NAME
        ]);
    }

    public function toggleDarkMode(array $params = []): void
    {
        $_SESSION['dark_mode'] = !($_SESSION['dark_mode'] ?? false);
        $referer = $_SERVER['HTTP_REFERER'] ?? BASE_URL;
        header("Location: " . $referer);
        exit;
    }
}

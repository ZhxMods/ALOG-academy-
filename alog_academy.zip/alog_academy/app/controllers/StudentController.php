<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\BaseController;
use App\Models\User;
use App\Models\Lesson;
use App\Models\Quiz;
use App\Models\XPLog;
use App\Models\UserLevel;
use App\Models\Ranking;
use App\Models\Subscription;
use App\Models\Payment;
use App\Models\Booking;
use App\Models\Notification;
use App\Models\SchoolLevel;
use App\Models\Subject;

class StudentController extends BaseController
{
    public function dashboard(array $params = []): void
    {
        $this->requireAuth();
        $userId = (int)$this->user['id'];

        $userModel = new User();
        $lessonModel = new Lesson();
        $notificationModel = new Notification();

        $stats = $userModel->getDashboardStats($userId);
        $recentActivity = $userModel->getRecentActivity($userId, 5);
        $latestLessons = $lessonModel->getAllActive(4);
        $notifications = $notificationModel->getUnread($userId, 5);

        // Continuer l'apprentissage
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("SELECT l.*, s.name as subject_name, sl.name as level_name 
                              FROM lessons l 
                              JOIN subjects s ON l.subject_id = s.id 
                              JOIN school_levels sl ON s.level_id = sl.id
                              LEFT JOIN lesson_progress lp ON l.id = lp.lesson_id AND lp.user_id = ?
                              WHERE l.status = 'active' AND (lp.is_completed IS NULL OR lp.is_completed = 0)
                              ORDER BY l.created_at DESC LIMIT 1");
        $stmt->execute([$userId]);
        $continueLesson = $stmt->fetch() ?: null;

        // Classement apercu
        $rankingModel = new Ranking();
        $globalTop = $rankingModel->getGlobalTop(5);

        $this->view('student/dashboard', [
            'stats' => $stats,
            'recent_activity' => $recentActivity,
            'latest_lessons' => $latestLessons,
            'continue_lesson' => $continueLesson,
            'global_top' => $globalTop,
            'notifications' => $notifications,
            'meta_title' => 'Tableau de bord - ' . SITE_NAME
        ]);
    }

    public function lessons(array $params = []): void
    {
        $this->requireAuth();
        $userId = (int)$this->user['id'];
        $levelId = (int)$this->user['school_level_id'];

        $levelModel = new SchoolLevel();
        $subjectModel = new Subject();
        $lessonModel = new Lesson();

        $level = $levelModel->find($levelId);
        $subjects = $subjectModel->getByLevel($levelId, $this->user['branch_id'] ?? null);

        $lessonsBySubject = [];
        foreach ($subjects as $subject) {
            $lessons = $lessonModel->getBySubject($subject['id']);
            // Ajouter progression
            foreach ($lessons as &$lesson) {
                $progress = $lessonModel->getWithProgress($lesson['id'], $userId);
                $lesson['is_completed'] = $progress['is_completed'] ?? 0;
                $lesson['is_skipped'] = $progress['is_skipped'] ?? 0;
            }
            $lessonsBySubject[$subject['id']] = [
                'subject' => $subject,
                'lessons' => $lessons
            ];
        }

        $this->view('student/lessons', [
            'level' => $level,
            'subjects' => $subjects,
            'lessons_by_subject' => $lessonsBySubject,
            'meta_title' => 'Mes Cours - ' . SITE_NAME
        ]);
    }

    public function lessonDetail(array $params = []): void
    {
        $this->requireAuth();
        $slug = $params['slug'] ?? '';
        $userId = (int)$this->user['id'];

        $lessonModel = new Lesson();
        $lesson = $lessonModel->getBySlug($slug);

        if (!$lesson) {
            $this->send404();
            return;
        }

        // Verification acces
        if ($lesson['access_type'] !== 'free') {
            $subscriptionModel = new Subscription();
            if (!$subscriptionModel->hasAccess($userId, $lesson['access_type'])) {
                $this->setFlash('error', 'Cette lecon necessite un abonnement ' . strtoupper($lesson['access_type']) . '.');
                $this->redirect('/abonnements');
            }
        }

        $progress = $lessonModel->getWithProgress($lesson['id'], $userId);

        // Quiz associe
        $quizModel = new Quiz();
        $quiz = $quizModel->getByLesson($lesson['id']);

        $this->view('student/lesson_detail', [
            'lesson' => $lesson,
            'progress' => $progress,
            'quiz' => $quiz,
            'meta_title' => $lesson['title'] . ' - ' . SITE_NAME
        ]);
    }

    public function completeLesson(array $params = []): void
    {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/dashboard');
        }

        $userId = (int)$this->user['id'];
        $lessonId = (int)($_POST['lesson_id'] ?? 0);
        $skipped = isset($_POST['skipped']);
        $csrf = $_POST['csrf_token'] ?? '';

        if (!$this->verifyCsrfToken($csrf)) {
            $this->setFlash('error', 'Jeton de securite invalide.');
            $this->redirect('/dashboard');
        }

        $lessonModel = new Lesson();
        $lesson = $lessonModel->find($lessonId);

        if (!$lesson) {
            $this->setFlash('error', 'Lecon introuvable.');
            $this->redirect('/dashboard');
        }

        $progress = $lessonModel->getWithProgress($lessonId, $userId);
        if ($progress && $progress['is_completed']) {
            $this->setFlash('info', 'Cette lecon est deja terminee.');
            $this->redirect('/cours');
        }

        $lessonModel->markComplete($lessonId, $userId, $skipped);

        if (!$skipped) {
            $xpLog = new XPLog();
            $xpLog->add($userId, $lesson['xp_reward'], 'lesson_complete', $lessonId, 'Lecon terminee: ' . $lesson['title']);

            $userLevel = new UserLevel();
            $levelResult = $userLevel->addXP($userId, $lesson['xp_reward']);

            if ($levelResult['leveled_up']) {
                $notif = new Notification();
                $notif->send($userId, 'level_up', 'Niveau superieur !', 
                    'Felicitations ! Vous avez atteint le niveau ' . $levelResult['new_level'] . ' !');
            }
        }

        $this->setFlash('success', $skipped ? 'Lecon passee.' : 'Lecon terminee ! +' . $lesson['xp_reward'] . ' XP');
        $this->redirect('/cours');
    }

    public function quiz(array $params = []): void
    {
        $this->requireAuth();
        $quizId = (int)($params['id'] ?? 0);
        $userId = (int)$this->user['id'];

        $quizModel = new Quiz();
        $quiz = $quizModel->find($quizId);

        if (!$quiz) {
            $this->send404();
            return;
        }

        // Verifier tentatives
        $attempts = $quizModel->getAttemptsCount($quizId, $userId);
        if ($quiz['max_attempts'] > 0 && $attempts >= $quiz['max_attempts']) {
            $this->setFlash('error', 'Nombre maximum de tentatives atteint.');
            $this->redirect('/dashboard');
        }

        // Verifier cooldown
        if (!$quizModel->canRetry($quizId, $userId, $quiz['retry_cooldown_hours'])) {
            $this->setFlash('error', 'Veuillez attendre avant de rejouer ce quiz.');
            $this->redirect('/dashboard');
        }

        $questions = $quizModel->getQuestions($quizId, true);

        $this->view('student/quiz', [
            'quiz' => $quiz,
            'questions' => $questions,
            'attempts' => $attempts,
            'meta_title' => 'Quiz: ' . $quiz['title'] . ' - ' . SITE_NAME
        ]);
    }

    public function submitQuiz(array $params = []): void
    {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/dashboard');
        }

        $userId = (int)$this->user['id'];
        $quizId = (int)($_POST['quiz_id'] ?? 0);
        $csrf = $_POST['csrf_token'] ?? '';

        if (!$this->verifyCsrfToken($csrf)) {
            $this->setFlash('error', 'Jeton de securite invalide.');
            $this->redirect('/dashboard');
        }

        $quizModel = new Quiz();
        $quiz = $quizModel->find($quizId);

        if (!$quiz) {
            $this->setFlash('error', 'Quiz introuvable.');
            $this->redirect('/dashboard');
        }

        $answers = $_POST['answers'] ?? [];
        $correctAnswers = $quizModel->getCorrectAnswers($quizId);

        $score = 0;
        $correct = 0;
        $total = count($correctAnswers);
        $resultDetails = [];

        foreach ($correctAnswers as $qa) {
            $userAnswer = $answers[$qa['id']] ?? null;
            $isCorrect = $userAnswer && (int)$userAnswer === (int)$qa['correct_answer'];
            if ($isCorrect) {
                $score += $qa['xp_value'];
                $correct++;
            }
            $resultDetails[] = [
                'question_id' => $qa['id'],
                'correct' => $isCorrect,
                'explanation' => $qa['explanation']
            ];
        }

        $percentage = $total > 0 ? round(($correct / $total) * 100) : 0;
        $passed = $percentage >= $quiz['passing_score'];

        $attempts = $quizModel->getAttemptsCount($quizId, $userId);
        $xpEarned = 0;

        if ($passed) {
            $xpEarned = $quiz['xp_reward'];
            if ($percentage === 100) {
                $xpEarned += $quiz['xp_perfect_bonus'];
            }

            $xpLog = new XPLog();
            $xpLog->add($userId, $xpEarned, 'quiz_pass', $quizId, 'Quiz reussi: ' . $quiz['title']);

            $userLevel = new UserLevel();
            $userLevel->addXP($userId, $xpEarned);
        }

        $quizModel->saveResult($userId, $quizId, [
            'score' => $percentage,
            'total' => $total,
            'correct' => $correct,
            'xp_earned' => $xpEarned,
            'passed' => $passed,
            'attempt' => $attempts + 1,
            'answers' => $answers
        ]);

        $this->view('student/quiz_result', [
            'quiz' => $quiz,
            'score' => $percentage,
            'correct' => $correct,
            'total' => $total,
            'passed' => $passed,
            'xp_earned' => $xpEarned,
            'details' => $resultDetails,
            'meta_title' => 'Resultat Quiz - ' . SITE_NAME
        ]);
    }

    public function rankings(array $params = []): void
    {
        $this->requireAuth();

        $rankingModel = new Ranking();
        $globalTop = $rankingModel->getGlobalTop(100);

        $regionalTop = [];
        if ($this->user['region_id']) {
            $regionalTop = $rankingModel->getRegionalTop($this->user['region_id'], 100);
        }

        $this->view('student/rankings', [
            'global_top' => $globalTop,
            'regional_top' => $regionalTop,
            'meta_title' => 'Classement - ' . SITE_NAME
        ]);
    }

    public function profile(array $params = []): void
    {
        $this->requireAuth();
        $userId = (int)$this->user['id'];

        $userModel = new User();
        $stats = $userModel->getDashboardStats($userId);

        $this->view('student/profile', [
            'user' => $this->user,
            'stats' => $stats,
            'meta_title' => 'Mon Profil - ' . SITE_NAME
        ]);
    }

    public function updateProfile(array $params = []): void
    {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/profil');
        }

        $userId = (int)$this->user['id'];
        $csrf = $_POST['csrf_token'] ?? '';

        if (!$this->verifyCsrfToken($csrf)) {
            $this->setFlash('error', 'Jeton de securite invalide.');
            $this->redirect('/profil');
        }

        $data = [
            'first_name' => sanitizeInput($_POST['first_name'] ?? ''),
            'last_name' => sanitizeInput($_POST['last_name'] ?? ''),
            'phone' => $_POST['phone'] ?? '',
            'bio' => sanitizeInput($_POST['bio'] ?? '')
        ];

        $userModel = new User();
        $userModel->update($userId, $data);

        $this->setFlash('success', 'Profil mis a jour avec succes.');
        $this->redirect('/profil');
    }

    public function subscriptions(array $params = []): void
    {
        $this->requireAuth();
        $userId = (int)$this->user['id'];

        $subscriptionModel = new Subscription();
        $paymentModel = new Payment();

        $activeSubscription = $subscriptionModel->getActiveByUser($userId);
        $history = $subscriptionModel->getByUser($userId);
        $payments = $paymentModel->getByUser($userId);

        $this->view('student/subscriptions', [
            'active' => $activeSubscription,
            'history' => $history,
            'payments' => $payments,
            'price_pro' => PRICE_PRO,
            'price_ultra' => PRICE_ULTRA,
            'meta_title' => 'Mes Abonnements - ' . SITE_NAME
        ]);
    }

    public function subscribe(array $params = []): void
    {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/abonnements');
        }

        $userId = (int)$this->user['id'];
        $plan = $_POST['plan_type'] ?? '';
        $csrf = $_POST['csrf_token'] ?? '';

        if (!$this->verifyCsrfToken($csrf) || !in_array($plan, ['pro', 'ultra'])) {
            $this->setFlash('error', 'Requete invalide.');
            $this->redirect('/abonnements');
        }

        $amount = $plan === 'pro' ? PRICE_PRO : PRICE_ULTRA;

        // Creer paiement en attente
        $subscriptionModel = new Subscription();
        $subId = $subscriptionModel->create([
            'user_id' => $userId,
            'plan_type' => $plan,
            'status' => 'pending'
        ]);

        $paymentModel = new Payment();
        $paymentModel->create([
            'user_id' => $userId,
            'subscription_id' => $subId,
            'amount' => $amount,
            'plan_type' => $plan,
            'status' => 'pending',
            'whatsapp_number' => $this->user['phone'] ?? ''
        ]);

        $this->setFlash('info', 'Veuillez effectuer le paiement via WhatsApp et telecharger la preuve.');
        $this->redirect('/abonnements');
    }

    public function uploadPaymentProof(array $params = []): void
    {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['proof'])) {
            $this->redirect('/abonnements');
        }

        $paymentId = (int)($_POST['payment_id'] ?? 0);
        $upload = uploadFile($_FILES['proof'], 'payments', ALLOWED_IMAGE_TYPES, MAX_UPLOAD_SIZE);

        if ($upload['success']) {
            $paymentModel = new Payment();
            $paymentModel->update($paymentId, ['proof_image' => $upload['path']]);
            $this->setFlash('success', 'Preuve de paiement telechargee. En attente de validation.');
        } else {
            $this->setFlash('error', $upload['error']);
        }

        $this->redirect('/abonnements');
    }

    public function bookings(array $params = []): void
    {
        $this->requireAuth();
        $userId = (int)$this->user['id'];

        $bookingModel = new Booking();
        $bookings = $bookingModel->getByUser($userId);

        $this->view('student/bookings', [
            'bookings' => $bookings,
            'meta_title' => 'Mes Reservations - ' . SITE_NAME
        ]);
    }

    public function createBooking(array $params = []): void
    {
        $this->requireAuth();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/reservations');
        }

        $userId = (int)$this->user['id'];
        $csrf = $_POST['csrf_token'] ?? '';

        if (!$this->verifyCsrfToken($csrf)) {
            $this->setFlash('error', 'Jeton de securite invalide.');
            $this->redirect('/reservations');
        }

        $bookingModel = new Booking();
        $bookingModel->create([
            'user_id' => $userId,
            'booking_type' => $_POST['booking_type'] ?? 'tutoring',
            'preferred_date' => $_POST['preferred_date'] ?? date('Y-m-d'),
            'preferred_time' => $_POST['preferred_time'] ?? '',
            'notes' => sanitizeInput($_POST['notes'] ?? ''),
            'whatsapp' => $_POST['whatsapp'] ?? $this->user['phone'] ?? ''
        ]);

        $this->setFlash('success', 'Demande de reservation envoyee avec succes.');
        $this->redirect('/reservations');
    }

    public function notifications(array $params = []): void
    {
        $this->requireAuth();
        $userId = (int)$this->user['id'];

        $notificationModel = new Notification();
        $notifications = $notificationModel->getAll($userId);

        // Marquer comme lues
        $notificationModel->markAllRead($userId);

        $this->view('student/notifications', [
            'notifications' => $notifications,
            'meta_title' => 'Notifications - ' . SITE_NAME
        ]);
    }
}

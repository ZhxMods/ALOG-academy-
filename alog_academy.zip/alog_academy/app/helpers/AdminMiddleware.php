<?php
declare(strict_types=1);

namespace App\Helpers;

use App\Core\BaseController;

/**
 * Middleware Admin - Protection routes admin
 */
class AdminMiddleware extends BaseController
{
    public function handle(): void
    {
        if (!$this->isAdmin()) {
            http_response_code(403);
            require APP_PATH . '/views/errors/403.php';
            exit;
        }
    }
}

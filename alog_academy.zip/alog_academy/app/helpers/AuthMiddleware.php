<?php
declare(strict_types=1);

namespace App\Helpers;

use App\Core\BaseController;

/**
 * Middleware Auth - Protection routes étudiants
 */
class AuthMiddleware extends BaseController
{
    public function handle(): void
    {
        if (!$this->isLoggedIn()) {
            $this->setFlash('error', 'Veuillez vous connecter pour accéder à cette page.');
            $this->redirect('/login');
        }
    }
}

<?php
declare(strict_types=1);

namespace App\Helpers;

use App\Core\BaseController;

/**
 * Middleware SuperAdmin - Protection routes super admin
 */
class SuperAdminMiddleware extends BaseController
{
    public function handle(): void
    {
        if (!$this->isAdmin() || $this->admin['role_name'] !== 'super_admin') {
            http_response_code(403);
            require APP_PATH . '/views/errors/403.php';
            exit;
        }
    }
}

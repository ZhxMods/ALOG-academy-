<?php
declare(strict_types=1);

/**
 * ALOG ACADEMY - Configuration Principale
 * Plateforme éducative marocaine optimisée pour hébergement gratuit
 */

// Environnement
define('ENVIRONMENT', 'production'); // production | development

define('BASE_URL', 'https://your-domain.aeonfree.com'); // <-- CHANGE THIS
define('SITE_NAME', 'ALOG ACADEMY');
define('SITE_TAGLINE', 'La plateforme éducative des étudiants marocains');

// Chemins
define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH', ROOT_PATH . '/app');
define('PUBLIC_PATH', ROOT_PATH);
define('CONFIG_PATH', ROOT_PATH . '/config');
define('STORAGE_PATH', ROOT_PATH . '/storage');

// Base de données (à configurer selon votre hébergeur AeonFree)
define('DB_HOST', 'localhost'); // <-- CHANGE THIS (AeonFree provides this)
define('DB_NAME', 'your_db_name'); // <-- CHANGE THIS (AeonFree provides this)
define('DB_USER', 'your_db_user'); // <-- CHANGE THIS (AeonFree provides this)
define('DB_PASS', 'your_db_password'); // <-- CHANGE THIS (AeonFree provides this)
define('DB_CHARSET', 'utf8mb4');

// Sécurité
define('SESSION_NAME', 'alog_session');
define('SESSION_LIFETIME', 7200); // 2 heures
define('CSRF_TOKEN_NAME', 'alog_csrf_token');
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes
define('PASSWORD_MIN_LENGTH', 8);

// Abonnements
define('PLAN_FREE', 'free');
define('PLAN_PRO', 'pro');
define('PLAN_ULTRA', 'ultra');
define('PRICE_PRO', 49);
define('PRICE_ULTRA', 99);
define('CURRENCY', 'MAD');

// XP Configuration
define('XP_LOGIN_DAILY', 10);
define('XP_LESSON_COMPLETE', 50);
define('XP_QUIZ_PASS', 30);
define('XP_QUIZ_PERFECT', 50);
define('XP_BASE_LEVEL', 100);
define('XP_LEVEL_MULTIPLIER', 1.5);

// WhatsApp contact pour paiements
define('WHATSAPP_NUMBER', '+212600000000');

// Uploads
define('MAX_UPLOAD_SIZE', 2 * 1024 * 1024); // 2MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);

// SEO
define('DEFAULT_META_TITLE', 'ALOG ACADEMY - Cours en ligne pour étudiants marocains');
define('DEFAULT_META_DESC', 'Plateforme éducative avec cours vidéo, quiz, et suivi de progression pour les étudiants du Maroc.');

// Maintenance
define('MAINTENANCE_MODE', false);

// Timezone
date_default_timezone_set('Africa/Casablanca');

// Affichage des erreurs en développement uniquement
if (ENVIRONMENT === 'development') {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
    error_reporting(0);
}

// Lancement de la session avec sécurité
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    // Only force secure cookies if HTTPS is actually available
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        ini_set('session.cookie_secure', '1');
    }
    ini_set('session.cookie_samesite', 'Strict');
    ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
    ini_set('session.use_strict_mode', '1');
    session_name(SESSION_NAME);
    session_start();
}

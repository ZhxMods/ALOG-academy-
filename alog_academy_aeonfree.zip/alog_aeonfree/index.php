<?php
/**
 * ALOG ACADEMY - Point d'entree
 */

declare(strict_types=1);

require __DIR__ . '/config/config.php';
require __DIR__ . '/config/autoload.php';
require APP_PATH . '/helpers/session_helper.php';
require APP_PATH . '/helpers/validation_helper.php';
require APP_PATH . '/helpers/security_helper.php';

if (MAINTENANCE_MODE && !isset($_SESSION['admin_id'])) {
    require APP_PATH . '/views/errors/maintenance.php';
    exit;
}

$router = require ROOT_PATH . '/routes/web.php';
$router->dispatch();

-- ALOG ACADEMY - Schéma de base de données complet
-- Optimisé pour hébergement gratuit (Fixed for Restricted Permissions)

-- ============================================
-- TABLE: roles
-- ============================================
CREATE TABLE IF NOT EXISTS roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO roles (name, display_name, description) VALUES
('student', 'Étudiant', 'Utilisateur étudiant standard'),
('admin', 'Administrateur', 'Administrateur avec accès limité'),
('super_admin', 'Super Administrateur', 'Contrôle total de la plateforme');

-- ============================================
-- TABLE: regions
-- ============================================
CREATE TABLE IF NOT EXISTS regions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(10) NOT NULL UNIQUE,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO regions (name, code) VALUES
('Casablanca-Settat', 'CS'),
('Rabat-Salé-Kénitra', 'RSK'),
('Marrakech-Safi', 'MS'),
('Tanger-Tétouan-Al Hoceïma', 'TTA'),
('Fès-Meknès', 'FM'),
('Béni Mellal-Khénifra', 'BMK'),
('Oriental', 'OR'),
('Souss-Massa', 'SM'),
('Drâa-Tafilalet', 'DT'),
('Guelmim-Oued Noun', 'GON'),
('Laâyoune-Sakia El Hamra', 'LS'),
('Dakhla-Oued Ed-Dahab', 'DO');

-- ============================================
-- TABLE: school_levels
-- ============================================
CREATE TABLE IF NOT EXISTS school_levels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    order_position INT DEFAULT 0,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- TABLE: branches
-- ============================================
CREATE TABLE IF NOT EXISTS branches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    level_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL,
    description TEXT,
    order_position INT DEFAULT 0,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (level_id) REFERENCES school_levels(id) ON DELETE CASCADE,
    UNIQUE KEY unique_branch_slug (level_id, slug)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: subjects
-- ============================================
CREATE TABLE IF NOT EXISTS subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    level_id INT NOT NULL,
    branch_id INT NULL,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'book',
    color VARCHAR(20) DEFAULT '#2563eb',
    order_position INT DEFAULT 0,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (level_id) REFERENCES school_levels(id) ON DELETE CASCADE,
    FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE SET NULL,
    UNIQUE KEY unique_subject_slug (level_id, branch_id, slug)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: lessons
-- ============================================
CREATE TABLE IF NOT EXISTS lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(200) NOT NULL,
    description TEXT,
    thumbnail_url VARCHAR(500),
    video_url VARCHAR(500),
    pdf_url VARCHAR(500),
    exercise_pdf_url VARCHAR(500),
    xp_reward INT DEFAULT 50,
    order_position INT DEFAULT 0,
    access_type ENUM('free','pro','ultra','xp_purchase') DEFAULT 'free',
    xp_price INT DEFAULT 0,
    duration_minutes INT DEFAULT 0,
    status ENUM('active','inactive','draft') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    INDEX idx_subject_order (subject_id, order_position),
    INDEX idx_access_type (access_type),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: lesson_progress
-- ============================================
CREATE TABLE IF NOT EXISTS lesson_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lesson_id INT NOT NULL,
    is_completed TINYINT(1) DEFAULT 0,
    is_skipped TINYINT(1) DEFAULT 0,
    progress_percent INT DEFAULT 0,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE,
    UNIQUE KEY unique_progress (user_id, lesson_id)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: quizzes
-- ============================================
CREATE TABLE IF NOT EXISTS quizzes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id INT NULL,
    subject_id INT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    passing_score INT DEFAULT 60,
    xp_reward INT DEFAULT 30,
    xp_perfect_bonus INT DEFAULT 20,
    time_limit_minutes INT DEFAULT 0,
    max_attempts INT DEFAULT 3,
    retry_cooldown_hours INT DEFAULT 24,
    status ENUM('active','inactive','draft') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE SET NULL,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================
-- TABLE: quiz_questions
-- ============================================
CREATE TABLE IF NOT EXISTS quiz_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT NOT NULL,
    question_text TEXT NOT NULL,
    question_type ENUM('multiple_choice','true_false') DEFAULT 'multiple_choice',
    correct_answer VARCHAR(255) NOT NULL,
    explanation TEXT,
    xp_value INT DEFAULT 10,
    order_position INT DEFAULT 0,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABLE: quiz_answers
-- ============================================
CREATE TABLE IF NOT EXISTS quiz_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT NOT NULL,
    answer_text VARCHAR(255) NOT NULL,
    is_correct TINYINT(1) DEFAULT 0,
    order_position INT DEFAULT 0,
    FOREIGN KEY (question_id) REFERENCES quiz_questions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABLE: quiz_results
-- ============================================
CREATE TABLE IF NOT EXISTS quiz_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    quiz_id INT NOT NULL,
    score INT DEFAULT 0,
    total_questions INT DEFAULT 0,
    correct_answers INT DEFAULT 0,
    xp_earned INT DEFAULT 0,
    is_passed TINYINT(1) DEFAULT 0,
    attempt_number INT DEFAULT 1,
    answers_json JSON,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABLE: users
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT DEFAULT 1,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20),
    password_hash VARCHAR(255) NOT NULL,
    birth_date DATE NULL,
    region_id INT NULL,
    school_level_id INT NULL,
    branch_id INT NULL,
    profile_image VARCHAR(255),
    bio TEXT,
    status ENUM('active','inactive','banned') DEFAULT 'active',
    email_verified TINYINT(1) DEFAULT 0,
    last_login TIMESTAMP NULL,
    login_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE SET DEFAULT,
    FOREIGN KEY (region_id) REFERENCES regions(id) ON DELETE SET NULL,
    FOREIGN KEY (school_level_id) REFERENCES school_levels(id) ON DELETE SET NULL,
    FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE SET NULL,
    INDEX idx_email (email),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: password_resets
-- ============================================
CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email_token (email, token)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: user_levels
-- ============================================
CREATE TABLE IF NOT EXISTS user_levels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    current_level INT DEFAULT 1,
    total_xp INT DEFAULT 0,
    xp_to_next_level INT DEFAULT 100,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABLE: xp_logs
-- ============================================
CREATE TABLE IF NOT EXISTS xp_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    xp_amount INT NOT NULL,
    action_type VARCHAR(50) NOT NULL,
    reference_id INT NULL,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_created (user_id, created_at)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: user_remember_tokens
-- ============================================
CREATE TABLE IF NOT EXISTS user_remember_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    selector VARCHAR(24) NOT NULL,
    hashed_validator VARCHAR(64) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABLE: rate_limits
-- ============================================
CREATE TABLE IF NOT EXISTS rate_limits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: subscriptions
-- ============================================
CREATE TABLE IF NOT EXISTS subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    plan_type ENUM('free','pro','ultra') DEFAULT 'free',
    status ENUM('active','expired','cancelled','pending') DEFAULT 'pending',
    started_at TIMESTAMP NULL,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_plan (user_id, plan_type)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: admins
-- ============================================
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT DEFAULT 2,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    avatar VARCHAR(255),
    last_login TIMESTAMP NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE SET DEFAULT
) ENGINE=InnoDB;

-- ============================================
-- TABLE: blog_posts
-- ============================================
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    author_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(200) NOT NULL UNIQUE,
    excerpt TEXT,
    content TEXT NOT NULL,
    featured_image VARCHAR(500),
    category VARCHAR(100),
    meta_title VARCHAR(200),
    meta_description VARCHAR(300),
    reading_time INT DEFAULT 5,
    status ENUM('draft','published','archived') DEFAULT 'draft',
    published_at TIMESTAMP NULL,
    views_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES admins(id) ON DELETE CASCADE,
    INDEX idx_slug (slug),
    INDEX idx_status_published (status, published_at),
    INDEX idx_category (category)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: payments
-- ============================================
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subscription_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'MAD',
    plan_type ENUM('pro','ultra') NOT NULL,
    proof_image VARCHAR(255),
    transaction_id VARCHAR(100),
    whatsapp_number VARCHAR(20),
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    admin_notes TEXT,
    validated_by INT NULL,
    validated_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABLE: rankings
-- ============================================
CREATE TABLE IF NOT EXISTS rankings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    region_id INT NULL,
    global_rank INT DEFAULT 0,
    regional_rank INT DEFAULT 0,
    total_xp INT DEFAULT 0,
    completed_lessons INT DEFAULT 0,
    quiz_average DECIMAL(5,2) DEFAULT 0.00,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (region_id) REFERENCES regions(id) ON DELETE SET NULL,
    UNIQUE KEY unique_user_region (user_id, region_id),
    INDEX idx_global_rank (global_rank),
    INDEX idx_regional_rank (regional_rank)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: comments
-- ============================================
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    content_type ENUM('lesson','blog') NOT NULL,
    content_id INT NOT NULL,
    comment TEXT NOT NULL,
    status ENUM('approved','pending','spam') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_content (content_type, content_id)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: bookings
-- ============================================
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    booking_type ENUM('tutoring','orientation','coaching') NOT NULL,
    preferred_date DATE NOT NULL,
    preferred_time VARCHAR(20),
    notes TEXT,
    whatsapp VARCHAR(20),
    status ENUM('pending','approved','rejected','completed') DEFAULT 'pending',
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABLE: notifications
-- ============================================
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT,
    is_read TINYINT(1) DEFAULT 0,
    reference_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_read (user_id, is_read, created_at)
) ENGINE=InnoDB;

-- ============================================
-- TABLE: settings
-- ============================================
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    setting_group VARCHAR(50) DEFAULT 'general',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES
('site_name', 'ALOG ACADEMY', 'general'),
('site_tagline', 'La plateforme éducative des étudiants marocains', 'general'),
('maintenance_mode', '0', 'general'),
('whatsapp_number', '+212600000000', 'contact'),
('contact_email', 'contact@alogacademy.ma', 'contact'),
('seo_title', 'ALOG ACADEMY - Cours en ligne pour étudiants marocains', 'seo'),
('seo_description', 'Plateforme éducative avec cours vidéo, quiz, et suivi de progression pour les étudiants du Maroc.', 'seo'),
('xp_login_daily', '10', 'xp'),
('xp_lesson_complete', '50', 'xp'),
('xp_quiz_pass', '30', 'xp'),
('xp_quiz_perfect', '50', 'xp'),
('price_pro', '49', 'subscription'),
('price_ultra', '99', 'subscription'),
('ad_enabled', '1', 'ads'),
('ad_banner_top', '', 'ads'),
('ad_banner_bottom', '', 'ads');

-- ============================================
-- TABLE: ads
-- ============================================
CREATE TABLE IF NOT EXISTS ads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    image_url VARCHAR(500),
    link_url VARCHAR(500),
    position ENUM('top','bottom','sidebar') DEFAULT 'top',
    status ENUM('active','inactive') DEFAULT 'active',
    start_date DATE NULL,
    end_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- TABLE: announcements
-- ============================================
CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    target_audience ENUM('all','students','admins') DEFAULT 'all',
    is_active TINYINT(1) DEFAULT 1,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- VUES POUR STATISTIQUES (Note: Views might need manual drop if re-running)
-- ============================================

DROP VIEW IF EXISTS v_user_stats;
CREATE VIEW v_user_stats AS
SELECT 
    u.id,
    u.first_name,
    u.last_name,
    u.email,
    COALESCE(ul.current_level, 1) as current_level,
    COALESCE(ul.total_xp, 0) as total_xp,
    COALESCE(s.plan_type, 'free') as plan_type,
    COALESCE(s.status, 'expired') as subscription_status,
    COUNT(DISTINCT lp.lesson_id) as completed_lessons,
    COUNT(DISTINCT qr.id) as quizzes_taken,
    COALESCE(AVG(qr.score), 0) as average_score,
    u.status,
    u.created_at
FROM users u
LEFT JOIN user_levels ul ON u.id = ul.user_id
LEFT JOIN subscriptions s ON u.id = s.user_id AND s.status = 'active'
LEFT JOIN lesson_progress lp ON u.id = lp.user_id AND lp.is_completed = 1
LEFT JOIN quiz_results qr ON u.id = qr.user_id
GROUP BY u.id;

DROP VIEW IF EXISTS v_leaderboard_global;
CREATE VIEW v_leaderboard_global AS
SELECT 
    u.id,
    u.first_name,
    u.last_name,
    u.profile_image,
    r.name as region_name,
    COALESCE(ul.total_xp, 0) as total_xp,
    COALESCE(ul.current_level, 1) as current_level,
    COUNT(DISTINCT lp.lesson_id) as completed_lessons,
    (SELECT COUNT(DISTINCT u2.id) + 1
     FROM users u2
     LEFT JOIN user_levels ul2 ON u2.id = ul2.user_id
     WHERE u2.status = 'active' AND COALESCE(ul2.total_xp, 0) > COALESCE(ul.total_xp, 0)
    ) as global_rank
FROM users u
LEFT JOIN user_levels ul ON u.id = ul.user_id
LEFT JOIN regions r ON u.region_id = r.id
LEFT JOIN lesson_progress lp ON u.id = lp.user_id AND lp.is_completed = 1
WHERE u.status = 'active'
GROUP BY u.id
ORDER BY total_xp DESC;

DROP VIEW IF EXISTS v_leaderboard_regional;
CREATE VIEW v_leaderboard_regional AS
SELECT 
    u.id,
    u.first_name,
    u.last_name,
    u.profile_image,
    r.name as region_name,
    u.region_id,
    COALESCE(ul.total_xp, 0) as total_xp,
    COALESCE(ul.current_level, 1) as current_level,
    COUNT(DISTINCT lp.lesson_id) as completed_lessons,
    (SELECT COUNT(DISTINCT u2.id) + 1
     FROM users u2
     LEFT JOIN user_levels ul2 ON u2.id = ul2.user_id
     WHERE u2.status = 'active' 
       AND u2.region_id = u.region_id 
       AND COALESCE(ul2.total_xp, 0) > COALESCE(ul.total_xp, 0)
    ) as regional_rank
FROM users u
LEFT JOIN user_levels ul ON u.id = ul.user_id
LEFT JOIN regions r ON u.region_id = r.id
LEFT JOIN lesson_progress lp ON u.id = lp.user_id AND lp.is_completed = 1
WHERE u.status = 'active'
GROUP BY u.id, u.region_id
ORDER BY u.region_id, total_xp DESC;

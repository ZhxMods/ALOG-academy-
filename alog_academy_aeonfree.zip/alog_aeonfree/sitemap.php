<?php
require __DIR__ . '/config/config.php';
/**
 * Sitemap XML dynamique - ALOG ACADEMY
 * Sitemap dynamique - place a la racine htdocs
 */

header('Content-Type: application/xml; charset=utf-8');

echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?= BASE_URL ?>/</loc>
        <priority>1.0</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?= BASE_URL ?>/a-propos</loc>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?= BASE_URL ?>/services</loc>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?= BASE_URL ?>/tarifs</loc>
        <priority>0.9</priority>
    </url>
    <url>
        <loc><?= BASE_URL ?>/blog</loc>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?= BASE_URL ?>/faq</loc>
        <priority>0.7</priority>
    </url>
    <url>
        <loc><?= BASE_URL ?>/contact</loc>
        <priority>0.7</priority>
    </url>
    <url>
        <loc><?= BASE_URL ?>/login</loc>
        <priority>0.5</priority>
    </url>
    <url>
        <loc><?= BASE_URL ?>/inscription</loc>
        <priority>0.5</priority>
    </url>
</urlset>

# ALOG ACADEMY - AeonFree Ready

## Structure adaptee pour hebergement gratuit AeonFree

Tous les fichiers publics sont a la racine `htdocs/`. Les dossiers internes (`app/`, `config/`, `routes/`, `storage/`) sont proteges par `.htaccess`.

## Instructions d'installation AeonFree

### 1. Base de donnees MySQL
- Connectez-vous au panel AeonFree
- Allez dans "MySQL Databases" et creez une base de donnees + utilisateur
- Notez l'hote (souvent `sqlXXX.byetcluster.com` ou `localhost`), le nom de la DB, l'utilisateur et le mot de passe
- Importez le fichier `storage/alog_academy_schema.sql` via phpMyAdmin

### 2. Configuration
Ouvrez `config/config.php` et modifiez :
```php
define('BASE_URL', 'https://votre-domaine.aeonfree.com');  // Votre URL AeonFree
define('DB_HOST', 'localhost');                             // Hote MySQL AeonFree
define('DB_NAME', 'votre_db_name');                         // Nom de la base
define('DB_USER', 'votre_db_user');                         // Utilisateur
define('DB_PASS', 'votre_db_password');                     // Mot de passe
```

### 3. Upload des fichiers
- Compressez tous les fichiers de ce dossier en ZIP
- Utilisez le gestionnaire de fichiers AeonFree (File Manager) ou FTP
- Uploadez dans `public_html/` ou `htdocs/` (decompressez a la racine)

### 4. Creation du compte admin
- Accedez a `https://votre-domaine.aeonfree.com/install.php` via votre navigateur
- Le script cree automatiquement le compte admin par defaut
- **SUPPRIMEZ IMMEDIATEMENT `install.php` apres utilisation !**
- Compte par defaut : `admin@alog.ma` / `Admin@2024!`

### 5. Dossier uploads (optionnel)
Le dossier `uploads/` est deja cree. Assurez-vous qu'il est accessible en ecriture (chmod 755).

## Compatibilite AeonFree Free Plan

- [x] Pas de `public/` folder separe (tout est a la racine htdocs)
- [x] MySQL 5.7 / MariaDB compatible (pas de fonctions de fenetre)
- [x] Pas de `php_value` dans .htaccess
- [x] Pas de redirection forcee HTTPS
- [x] Cookies de session compatibles HTTP/HTTPS
- [x] Argon2id avec fallback BCRYPT
- [x] PDO avec erreurs silencieuses en production
- [x] Taille d'upload 2MB (compatible free hosting)

## Securite

- Supprimez `install.php` apres installation
- Changez le mot de passe admin apres la premiere connexion
- Ne partagez jamais vos identifiants de base de donnees

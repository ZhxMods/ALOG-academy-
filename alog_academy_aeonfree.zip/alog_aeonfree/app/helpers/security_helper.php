<?php
/**
 * Helper Security - Fonctions de sécurité
 */

function generateToken(): string
{
    return bin2hex(random_bytes(32));
}

function hashPassword(string $password): string
{
    // AeonFree compatibility: fallback if Argon2id is not available
    if (defined('PASSWORD_ARGON2ID')) {
        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 3
        ]);
    }
    return password_hash($password, PASSWORD_DEFAULT);
}

function verifyPassword(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}

function checkRateLimit(string $key, int $maxAttempts, int $window): bool
{
    $db = \App\Core\Database::getInstance();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $identifier = $ip . '_' . $key;
    $windowStart = time() - $window;

    $stmt = $db->prepare("SELECT COUNT(*) FROM rate_limits WHERE identifier = ? AND created_at > FROM_UNIXTIME(?)");
    $stmt->execute([$identifier, $windowStart]);
    $attempts = (int)$stmt->fetchColumn();

    if ($attempts >= $maxAttempts) {
        return false;
    }

    $stmt = $db->prepare("INSERT INTO rate_limits (identifier, created_at) VALUES (?, NOW())");
    $stmt->execute([$identifier]);
    return true;
}

function cleanOldRateLimits(): void
{
    $db = \App\Core\Database::getInstance();
    $db->query("DELETE FROM rate_limits WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)");
}

function xssClean(string $data): string
{
    return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function uploadFile(array $file, string $directory, array $allowedTypes, int $maxSize): array
{
    $result = ['success' => false, 'path' => '', 'error' => ''];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $result['error'] = "Erreur lors du téléchargement du fichier.";
        return $result;
    }

    if ($file['size'] > $maxSize) {
        $result['error'] = "Le fichier est trop volumineux.";
        return $result;
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);

    if (!in_array($mimeType, $allowedTypes)) {
        $result['error'] = "Type de fichier non autorisé.";
        return $result;
    }

    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = bin2hex(random_bytes(16)) . '.' . $extension;
    $uploadPath = PUBLIC_PATH . '/uploads/' . $directory . '/' . $filename;

    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        $result['success'] = true;
        $result['path'] = 'uploads/' . $directory . '/' . $filename;
    } else {
        $result['error'] = "Erreur lors de l'enregistrement du fichier.";
    }

    return $result;
}

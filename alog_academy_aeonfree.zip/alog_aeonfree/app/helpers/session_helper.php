<?php
/**
 * Helper Session - Gestion des sessions sécurisées
 */

function regenerateSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }
}

function destroySession(): void
{
    $_SESSION = [];
    if (isset($_COOKIE[session_name()])) {
        $cookieOpts = [
            'expires' => time() - 3600,
            'path' => '/',
            'httponly' => true,
            'samesite' => 'Strict'
        ];
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            $cookieOpts['secure'] = true;
        }
        setcookie(session_name(), '', $cookieOpts);
    }
    session_destroy();
}

function setRememberMeCookie(int $userId): void
{
    $selector = bin2hex(random_bytes(12));
    $validator = bin2hex(random_bytes(32));
    $hashedValidator = hash('sha256', $validator);
    $expires = time() + (30 * 24 * 60 * 60); // 30 jours

    $db = \App\Core\Database::getInstance();
    $stmt = $db->prepare("INSERT INTO user_remember_tokens (user_id, selector, hashed_validator, expires_at) VALUES (?, ?, ?, FROM_UNIXTIME(?))");
    $stmt->execute([$userId, $selector, $hashedValidator, $expires]);

    $token = $selector . ':' . $validator;
    $cookieOpts = [
        'expires' => $expires,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Strict'
    ];
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        $cookieOpts['secure'] = true;
    }
    setcookie('remember_me', $token, $cookieOpts);
}

function clearRememberMeCookie(): void
{
    if (isset($_COOKIE['remember_me'])) {
        list($selector) = explode(':', $_COOKIE['remember_me']);
        $db = \App\Core\Database::getInstance();
        $stmt = $db->prepare("DELETE FROM user_remember_tokens WHERE selector = ?");
        $stmt->execute([$selector]);
    }
    $cookieOpts = [
        'expires' => time() - 3600,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Strict'
    ];
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        $cookieOpts['secure'] = true;
    }
    setcookie('remember_me', '', $cookieOpts);
}
